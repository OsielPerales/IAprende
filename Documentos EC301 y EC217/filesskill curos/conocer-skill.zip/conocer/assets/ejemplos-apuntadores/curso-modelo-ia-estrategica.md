---
tipo: apuntador_curso_modelo
curso: IA Estratégica y Diseño de Instrucciones Proactivas · v2.0
duración: 120 min
estándar: EC0301 · certificado B Smarter
uso: ground truth estructural para toda producción nueva de cursos
---

# Apuntador · Curso Modelo "IA Estratégica y Diseño de Instrucciones Proactivas"

> **Propósito de este archivo.** No es el curso. Son los apuntadores (IDs, rutas, características clave) al corpus de referencia que la skill usa como ground truth estructural para producir cursos nuevos. Cuando un agente necesite "ver cómo se ve un curso completo", este archivo le dice dónde buscar.

---

## Ubicación de los artefactos en Google Drive

| Artefacto | Drive file ID | Observaciones |
|---|---|---|
| Manual del Participante | `1AgAluyVXho6A27M-NGW4aic4eQk8CF1CiNrHT4aWwik` | 32-40 pp, 18 secciones completas |
| Manual del Instructor | `1n8C6nRq72Wx0BBRvLxog-NIqhPDf4n32mlmYLzVT5Bc` | 45-50 pp, tabla 7 columnas incluida |
| Documento de Planeación v4 | `1WhpNuHLbivAqB6EkJTEVpnyeXWkdN4BA` | canon vigente — usar éste |
| Documento de Planeación v3 (referencia secundaria) | `1ZAlQna_4kf-Yu8gx70bKm-GMy7kRQab4c4c9vVOF3RA` | útil para comparar iteraciones |
| VERIFICACION_CURSO_IAPRENDE_N1_v2.md | vault local Obsidian | 35 bloques, 14 tipos, schema Firestore |

**Cómo acceder:** desde Claude.ai con conector Google Drive activo → tool `Google Drive:read_file_content` con el fileId correspondiente. En Antigravity/Claude Code → descargar primero a local y leer con `view`.

---

## Estructura de referencia que este curso instancia

```
Duración:    120 min (Apertura 35 / Desarrollo 65 / Cierre 25)
Modalidad:   Presencial grupal · 4 a 12 participantes
Instructor:  Osiel Alejandro Perales Jiménez
Caso ancla:  "Soy dueño de una panadería, recibo quejas de clientes"
Producto:    Asistente de IA construido por el alumno durante el taller

Módulos:
  M-I · Encuadre y Fundamentos (15 min · Expositiva dialogada)
    1.1 Apertura y Alineación Estratégica
    1.2 De Buscadores a Motores de Razonamiento
    1.3 Evaluación Diagnóstica y Casos de Uso
  M-II · Estructura Maestra del Prompt (22 min · Demostrativa)
    2.1 El Rol y la Arquitectura MoE
    2.2 La Ventana de Contexto
    2.3 Instrucción y Formato
    2.4 Restricciones y Tokens
  Energizante · "El Prompt Rápido" (3 min)
  M-III · Análisis de Sesgos y Alucinaciones (15 min · Diálogo-Discusión)
    3.1 Del Concepto a la Implementación Real
    3.2 Aplicación de la Estructura Maestra
    3.3 Taller de Refinamiento: Sesgos y Alucinaciones
    3.4 Intercambio y Evaluación por Pares
  Sumativa · Desafío Asistente Empresarial (10 min)

Cierre:
  - Técnica grupal: "Mi Asistente del Futuro"
  - Resumen personalizado (datos del alumno en Firestore)
  - Compromisos 72 h
  - Mapa ecosistema iAprende (3 Pilares)
```

---

## Objetivos Mager completos del curso modelo

**Objetivo general:**

> El participante, desde el inicio y durante el taller de manera asistida por el instructor así como en su interacción diaria con la IA, aprenderá a diseñar y aplicar prompts estratégicos utilizando la Estructura Maestra (Rol, Contexto, Instrucción, Restricciones, Formato) para automatizar procesos personales y empresariales.

**Objetivos particulares:**

1. El participante comprenderá el cambio de paradigma de buscadores a motores de razonamiento e identificará procesos repetitivos susceptibles de automatización.
2. El participante aprenderá y aplicará la Estructura Maestra del Prompt (Rol, Contexto, Instrucción, Restricciones, Formato) mediante ejercicios prácticos en parejas.
3. El participante desarrollará actitudes de colaboración activa y compartirá conocimientos con sus compañeros desarrollando técnicas para corregir prompts y evitar sesgos.
4. **Saber Convivir** · El participante atenderá a los puntos de vista y experiencias expresados por sus compañeros permitiendo la libre participación y expresión, a lo largo del curso, para fomentar un ambiente de aprendizaje óptimo.

---

## Adaptación iAprende · 35 bloques

Ver archivo de verificación completo en el vault:

```
Obsidian Vault → VERIFICACION_CURSO_IAPRENDE_N1_v2.md
```

Distribución de bloques:
- Preámbulo: 1 (infografía 3 Pilares)
- Encuadre: 5 (E.1 a E.5)
- Módulo I: 7 (M1.0 a M1.6)
- Módulo II: 10 (M2.0 a M2.9)
- Módulo III: 5 (M3.0 a M3.4)
- Sumativa: 4 (S.0 a S.3)
- Cierre: 3 (C.1 a C.3)
- **Total: 35 bloques · 9 tipos usados de los 14 disponibles**

---

## Componentes React identificados en este curso

```
Existentes o triviales (base iAprende):
  BloquePortada, BloqueTextoRico, BloqueComparador, BloqueChecklist,
  BloqueCuestionario, BloqueCampoLibre, BloqueSimuladorHtml

Nuevos/específicos (implementar):
  BloqueInfografia         — zonas expandibles con tap
  BloqueTarjetasFlip       — flip cards
  BloqueTablaEditable      — tabla con campos + escritura Firestore
  BloqueSimuladorPrompt ★  — editor de prompt con evaluación vía Claude API
  BloqueCasoEtico          — respuestas colaborativas
  BloqueResumenPersonal    — resumen dinámico
```

★ `BloqueSimuladorPrompt` es el componente estrella: único componente que consume Claude API directamente desde el frontend (Cloud Function proxy para proteger API key).

---

## Bibliografía viva (vigente abril 2026)

1. OpenAI (2024). *GPT-4 Technical Report*. arXiv:2303.08774. Estados Unidos.
2. Google DeepMind (2024). *Gemini: A Family of Highly Capable Multimodal Models*. DeepMind Publications. Reino Unido.
3. Brown, T. et al. (2020). *Language Models are Few-Shot Learners*. NeurIPS 2020. Estados Unidos.
4. CONOCER (2012, vigente 2026). *EC0301: Diseño de cursos de formación del capital humano*. Diario Oficial de la Federación. México.
5. Díaz, E. (2012). *Estilos de aprendizaje*. Revista Eídos. Ecuador.

Cuando se produzca un curso nuevo, la skill debe **sustituir estas fuentes por las pertinentes del nuevo tema** vía web_search en fase 3 (T4). Las fuentes CONOCER permanecen.

---

## Qué es transferible de este modelo a cursos nuevos

- **Estructura 3 módulos × técnicas canónicas** → siempre.
- **Reparto 35/65/25** → siempre (cursos 120 min).
- **Caso ancla transversal** → siempre, pero se adapta al sector del grupo.
- **Saber Convivir objetivo 4** → siempre.
- **Auto-auditoría ética en Sumativa** → siempre, adaptada al tema (si el tema no tiene dimensión ética obvia, incluirla como uso responsable de la herramienta).
- **Cierre con mapa ecosistema iAprende** → siempre.
- **18 secciones del Manual Participante** → siempre.
- **14 secciones del Manual Instructor** → siempre.
- **35-40 bloques iAprende** → siempre.

---

## Qué NO es transferible (cuidado al clonar)

- El **simulador_prompt** específico de este curso es para IA. Otro curso tendrá un simulador distinto (o ninguno, según el dominio).
- Los **objetivos Mager literales** son de este curso; hay que redactarlos nuevos.
- La **bibliografía** es de IA, otro curso tendrá la suya.
- El **caso ancla "panadería"** se puede reutilizar pero es mejor adaptarlo al sector del grupo real.

---

*Este archivo se actualiza cada vez que el curso modelo tenga un cambio de versión mayor.*
