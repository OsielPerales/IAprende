---
tipo: apuntador_curso_ejemplo_ece
curso: Estilos de Aprendizaje y su aplicación en las empresas
autor: Iván Téllez López (evaluador B Smarter EC0301)
duración: 120 min
uso: referencia cruzada de cómo se ve un curso validado por el propio ECE
---

# Apuntador · Curso Ejemplo B Smarter "Estilos de Aprendizaje"

> **Propósito.** Este es el ejemplo que B Smarter envía a todo candidato EC0301 como modelo de referencia. Lo produjo Iván Téllez (evaluador acreditado), por lo que cumple exactamente los criterios que B Smarter evalúa. Útil para comparar contra el curso modelo iAprende y verificar que ambos siguen el mismo patrón estructural.

---

## Origen del archivo

- **Fuente:** correo de `revisiones@bsmarter.org.mx` a Osiel el 16 abril 2026
- **Autor:** Iván Téllez López · `ivan.tellez@bsmarter.org.mx` · cel. 2221143527
- **Copia local:** `/mnt/user-data/uploads/Ejemplo_doc_de_planeacion.pdf` (sesión abril 2026) y `/mnt/user-data/uploads/2Documento_de_planeacio_n_del_curso.docx`

---

## Ficha técnica

```
Nombre:           Estilos de Aprendizaje y su aplicación en las empresas
Facilitador:      Iván Téllez López
Lugar:            Soluciones Empresariales BSMARTER
Duración:         120 min
Participantes:    4
Perfil:           Personas con personal a cargo o relaciones bilaterales en empresa
Dominio:          Comunicación organizacional / formación de adultos
Marco teórico:    Bandler y Grinder · V-A-K (Visual · Auditivo · Kinestésico)
```

---

## Estructura (para comparar con curso modelo iAprende)

```
Apertura (30 min):
  1. Presentación instructor (1 min)
  2. Rompe Hielo "El Juego de las Posibilidades" (6 min)
  3. Objetivo general (1 min)
  4. Objetivos particulares (2 min)
  5. Descripción general del curso (1 min)
  6. Temario (1 min)
  7. Beneficios (1 min)
  8. Fomentar participación (3 min)
  9. Tipos de evaluaciones (2 min)
  10. Acuerdos / expectativas (3 min)
  11. Reglas de operación (1 min)
  12. Contrato de aprendizaje (2 min)
  13. Evaluación diagnóstica (6 min)

Desarrollo (70 min):
  - Tema 1: Estilos de aprendizaje (Visual, Auditivo, Kinestésico) — Expositiva (15 min)
  - Tema 2: Características y perfiles por estilo — Demostrativa "emparejamiento" (20 min)
  - Evaluación formativa — Lista de cotejo (5 min)
  - Técnica Energizante "Estiramientos" (5 min)
  - Tema 3: Utilidad grupal de los estilos — Diálogo-Discusión (15 min)
  - Evaluación sumativa — Cuestionario (10 min)

Cierre (20 min):
  1. Conclusiones "Balance del día" (5 min)
  2. Resumen (4 min)
  3. Logro de expectativas (1 min)
  4. Logro de objetivos (1 min)
  5. Sugerencias de continuidad (1 min)
  6. Referencias bibliográficas (1 min)
  7. Compromisos de aplicación (1 min)
  8. Evaluación de satisfacción (5 min)
  9. Cierre (1 min)
```

**Total: 120 min (30 / 70 / 20)** — ligeramente distinto del canónico 35/65/25 que adoptamos. Ambos son válidos para EC0301; adoptamos 35/65/25 por consistencia interna.

---

## Diferencias clave con curso modelo iAprende

| Dimensión | Curso Iván (BSmarter) | Curso Modelo iAprende | Adopción en skill |
|---|---|---|---|
| Reparto de tiempos | 30/70/20 | 35/65/25 | **35/65/25** |
| N participantes | 4 (pequeño) | 4-12 | **4-12** |
| Marco teórico | Bandler-Grinder V-A-K | Estructura Maestra + MoE | depende del curso |
| Rompe Hielo | "Juego de las Posibilidades" | "Mapa de Expectativas" | cualquiera válida |
| Energizante | "Estiramientos" físico | "Prompt Rápido" cognitivo | cualquiera válida |
| Cierre | "Balance del día" | "Mi Asistente del Futuro" | cualquiera válida |
| Marca/branding | B Smarter (formativo genérico) | iAprende / DE (diferenciado) | **iAprende / DE** |
| Adaptación digital | — | 35 bloques iAprende | **obligatorio** |
| Caso ancla transversal | — (ejemplos sueltos) | Panadería recorre 3 módulos | **obligatorio** |
| Auto-auditoría ética | — | 3 items en Sumativa | **obligatorio** |
| Cierre con ecosistema | — | Mapa 3 Pilares | **obligatorio** |

---

## Patrones universales entre ambos modelos (= invariantes confiables)

Ambos cursos, a pesar de sus diferencias, comparten:

1. **Apertura con 3 bloques fijos:** Presentación + Rompe Hielo + Diagnóstica.
2. **Objetivos Mager** con Sujeto-Acción-Condición-Beneficio.
3. **3 técnicas instruccionales** (Expositiva, Demostrativa, Diálogo-Discusión) en M-I, M-II, M-III respectivamente.
4. **Técnica Energizante entre M-II y M-III.**
5. **Evaluación Formativa 50 % + Sumativa 50 %**, diagnóstica referencial.
6. **Contrato de aprendizaje** en Apertura.
7. **Cierre con:** conclusiones grupales, resumen, verificación de expectativas/objetivos, compromisos, satisfacción.
8. **Bibliografía con formato APA-like** (autor, año, título, editorial/URL, país).

Estos son los patrones que `references/patrones-estructurales.md` codifica como invariantes.

---

## Objetivos Mager del curso de Iván (texto real como referencia de estilo)

**Objetivo general:**
> El participante, al concluir el curso/taller, conocerá los estilos de aprendizaje existentes, identificará las características de cada uno de ellos y tomará conciencia de la utilidad de identificar los rasgos característicos, de acuerdo con la teoría de Bandler y Grinder sobre los estilos de aprendizaje, para ubicar las características, rasgos y comportamientos que nos permitan diseñar acciones en pro de mejorar la productividad en nuestras empresas.

**Nótese:** aunque el texto es correcto para EC0301, usa verbos de menor precisión ("conocerá", "tomará conciencia"). El curso modelo iAprende usa verbos más fuertes ("aprenderá a diseñar", "aplicará"). **La skill prefiere verbos fuertes** (ver `references/redaccion-objetivos-mager.md`).

---

## Bibliografía de referencia (del curso de Iván)

1. Díaz, E. (2012). *Estilos de aprendizaje*. Revista Eídos. http://www.ute.edu.ec/posgrados/eidos5.pdf. Ecuador.
2. Castro, S. y Guzmán, B. (2005). *Los estilos de aprendizaje en la enseñanza y el aprendizaje*. Revista de Investigación, (58), 83-102. ISSN 0798-0329. Venezuela.
3. Chavarría, S. et al. (2013). *El modelo Bandler-Grinder de aprendizaje y la enseñanza de genética mendeliana*. UNED Research Journal, 4(2), 213-221. ISSN 1659-4266. Costa Rica.

---

*Archivo de referencia cruzada. No modificar sin actualizar también `references/patrones-estructurales.md`.*
