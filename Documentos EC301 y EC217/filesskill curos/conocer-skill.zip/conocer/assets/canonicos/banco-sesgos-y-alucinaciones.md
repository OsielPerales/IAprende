---
título: Banco de Casos · Sesgos y Alucinaciones
tipo: asset_canonico
tags: [sesgos, alucinaciones, etica, casos-discusion]
---

# Banco de Casos · Sesgos y Alucinaciones

Casos preparados para las Dialogó-Discusiones del Módulo III. Específicos de cursos sobre IA, pero el patrón aplica a cualquier curso con dimensión ética.

---

## Tipos de sesgo y alucinación

### 1. Alucinación (invención de hechos)

La IA inventa datos que no existen: estadísticas, autores, citas, URLs, normas, estudios científicos.

### 2. Sesgo de confirmación

La IA refuerza la opinión de quien pregunta en lugar de dar una visión equilibrada.

### 3. Sesgo implícito

La IA trae supuestos demográficos, culturales o ideológicos del corpus de entrenamiento sin que el usuario los haya pedido.

### 4. Sesgo de autoridad

La IA presenta opiniones débiles como si vinieran de un experto.

---

## Casos para discutir en M-III

### Caso α — La estadística inventada

Un contador pregunta a la IA: "¿Qué porcentaje de PyMEs mexicanas usa IA?" La IA responde: "El 47.3 % de las PyMEs en México usaron IA durante 2025, según un estudio de la AMITI." El contador incluye ese dato en una presentación a inversores.

**Preguntas para el grupo:**

- ¿Qué hay de malo con este escenario?
- ¿De quién es la responsabilidad si el dato es falso?
- ¿Qué debió hacer el contador antes de incluirlo?
- ¿Cómo habría formulado el prompt para evitar este riesgo?

### Caso β — La respuesta "perfecta" genérica

Una pequeña empresaria automatiza respuestas de WhatsApp con IA. Los clientes empiezan a notar que las respuestas son "demasiado perfectas" y sospechan que es un bot. Las ventas bajan 20 %.

**Preguntas:**

- ¿Se debe declarar el uso de IA a los clientes?
- ¿Hay una línea entre "eficiencia" y "calidez perdida"?
- ¿Qué ajustes al prompt mantendrían la automatización pero conservarían la humanidad?

### Caso γ — El sesgo que no vimos

Un RH pregunta a la IA: "Dame un prompt para filtrar candidatos para puesto de liderazgo." La IA responde con criterios que, aunque no lo dicen explícitamente, terminan excluyendo desproporcionadamente a mujeres con historial de maternidad.

**Preguntas:**

- ¿Cómo detectar un sesgo así en una respuesta de IA?
- ¿Quién es responsable? ¿El diseñador del prompt? ¿La IA? ¿RH?
- ¿Qué revisión humana es indispensable antes de aplicar un filtro generado por IA?

### Caso δ — La cita que nunca existió

Un estudiante de posgrado usa IA para redactar su tesis. La IA cita a un autor con un libro que nunca existió. El comité detecta la cita falsa.

**Preguntas:**

- ¿Por qué es tentador confiar en citas que "suenan creíbles"?
- ¿Cómo validar las referencias de IA antes de incluirlas en trabajo serio?
- ¿Qué cambio de flujo evitaría esto por default?

### Caso ε — El consejo médico que no debía darse

Una persona pregunta a un asistente generalista de IA sobre síntomas médicos preocupantes. La IA da un diagnóstico probable y sugiere tratamiento casero. La persona no va al médico y la condición empeora.

**Preguntas:**

- ¿Qué dominios son de alto riesgo para consultas directas a IA?
- ¿Cómo diseñar un asistente que DERIVE al experto humano cuando corresponda?
- ¿Qué responsabilidad tiene el creador del asistente?

---

## Patrones a observar en la discusión

El facilitador busca que los subgrupos arriben a estas conclusiones:

1. **La responsabilidad final es siempre del humano.**
2. **Verificar antes de publicar** (especialmente datos, citas, diagnósticos).
3. **Declarar el uso de IA** cuando el contexto lo exige.
4. **Diseñar puntos de ruptura** en el flujo: pasos donde el humano DEBE intervenir.
5. **Los criterios éticos son técnicos**, no solo filosóficos: se expresan en el diseño del prompt.

---

## Regla para la skill

Al producir un curso nuevo en T2-T5, la skill selecciona **1-2 casos de este banco** (o propone variantes adaptadas al dominio) para alimentar el Diálogo-Discusión del Módulo III.

---

*Banco vivo — agregar nuevos casos cuando surjan en cursos reales.*
