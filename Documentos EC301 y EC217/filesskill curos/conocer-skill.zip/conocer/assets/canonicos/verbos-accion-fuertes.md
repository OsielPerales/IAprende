---
título: Banco de Verbos de Acción Fuertes
tipo: asset_canonico
tags: [verbos, bloom, objetivos, redaccion]
---

# Banco de Verbos de Acción Fuertes

Referencia rápida de verbos observables para redactar objetivos Mager. Organizado por dominio y nivel Bloom.

Complementa [[../../references/redaccion-objetivos-mager]].

---

## Dominio Cognitivo (Saber)

### Nivel 1 · Recordar
identificar · listar · definir · reconocer · nombrar · repetir · enumerar · señalar · localizar · citar · clasificar (memorístico) · recordar · recitar · marcar · subrayar

### Nivel 2 · Comprender
explicar · describir · resumir · interpretar · parafrasear · ejemplificar · ilustrar · contrastar · comparar · diferenciar · relacionar · traducir · inferir · predecir

### Nivel 3 · Aplicar
aplicar · utilizar · ejecutar · implementar · resolver · calcular · operar · demostrar · llevar a cabo · usar · realizar · poner en práctica · desarrollar · construir

### Nivel 4 · Analizar
analizar · examinar · descomponer · identificar causas · detectar patrones · categorizar · organizar · atribuir · estructurar · integrar · deconstruir · comparar críticamente

### Nivel 5 · Evaluar
evaluar · juzgar · criticar · valorar · justificar · argumentar · defender · fundamentar · priorizar · seleccionar con criterio · medir · auditar · validar · recomendar · dictaminar

### Nivel 6 · Crear
diseñar · construir · generar · formular · planear · producir · elaborar · inventar · componer · idear · proponer · crear · integrar en producto nuevo · sintetizar

---

## Dominio Psicomotor (Saber Hacer)

### Nivel 1 · Imitar
copiar · replicar · seguir · imitar · observar y reproducir

### Nivel 2 · Manipular
operar · manejar · ensamblar · ajustar · manipular · calibrar

### Nivel 3 · Precisión
construir con precisión · medir · cortar · soldar · ejecutar con exactitud · afinar

### Nivel 4 · Articulación
coordinar · secuenciar · integrar operaciones · orquestar

### Nivel 5 · Naturalización
ejecutar con maestría · dominar · perfeccionar · automatizar movimiento

---

## Dominio Afectivo (Saber Ser / Saber Convivir)

### Nivel 1 · Recibir
escuchará · atenderá · percibirá · prestará atención · se interesará por

### Nivel 2 · Responder
responderá · participará · cumplirá · acatará · se involucrará · discutirá · colaborará puntualmente

### Nivel 3 · Valorar
valorará · apreciará · respetará · preferirá · defenderá · se comprometerá · adoptará actitud de

### Nivel 4 · Organizar valores
integrará · articulará · sintetizará valores · priorizará ética · comparará valores

### Nivel 5 · Caracterizar (internalizar)
actuará consistentemente con · practicará cotidianamente · internalizará · manifestará (actitud permanente)

---

## Verbos PROHIBIDOS (débiles o no observables)

| Verbo débil | Reemplazar por |
|---|---|
| conocer | identificar, describir, explicar |
| saber | demostrar que sabe mediante... |
| entender | explicar con sus palabras, interpretar |
| aprender | aplicar, demostrar dominio |
| familiarizarse | identificar 5 ejemplos, describir |
| acercarse a | explorar mediante X actividad (con criterio medible) |
| tener conciencia de | nombrar y explicar 3 aspectos de... |
| apreciar | describir 3 beneficios, preferir con justificación |
| disfrutar | evaluar positivamente |
| estar al tanto de | listar, mencionar |

---

## Por módulo típico

| Módulo | Verbos recomendados |
|---|---|
| M-I (Fundamentos) | comprender, identificar, describir, comparar, diferenciar |
| M-II (Aplicación) | aplicar, construir, diseñar, elaborar, demostrar, ejecutar |
| M-III (Reflexión/ética) | analizar, evaluar, criticar, justificar, valorar, juzgar |
| Transversal (Saber Convivir) | colaborar, compartir, respetará, se comprometerá, desarrollará actitud de |

---

*Referencia rápida para el diseño de objetivos.*
