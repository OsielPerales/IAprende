---
título: Caso Ancla · Plantilla "Pan de Casa" (Panadería)
tipo: asset_canonico
origen: curso modelo IA Estratégica v2.0
tags: [caso-ancla, panaderia, ejemplo]
---

# Caso Ancla · "Pan de Casa"

Caso canónico del curso modelo, replicable con adaptaciones para cualquier curso sobre PyMEs / atención al cliente / servicios locales.

---

## Ficha del caso

```
Nombre del negocio:     Pan de Casa
Sector:                 Panadería artesanal
Ubicación:              Tlalpan, CDMX (o adaptar)
Tamaño:                 PyME con 4-6 empleados
Dueña:                  María (edad ~45, primera generación emprendedora)
Producto principal:     Pan artesanal tradicional mexicano
Canales de venta:       Tienda física + redes sociales + WhatsApp
Desafío principal:      Escalar atención al cliente sin perder la calidez del trato familiar
```

---

## Por qué este caso funciona como ancla

1. **Universal:** cualquier participante se identifica con una panadería cercana.
2. **Concreto:** medidas, productos, clientes son tangibles (no abstractos).
3. **Escalable:** presenta desafíos de una PyME real sin ser trivial.
4. **Empático:** María como persona evita el tecnicismo corporativo.
5. **Ético:** las decisiones tienen implicaciones humanas (calidez vs automatización).

---

## Cómo se aplica en los 3 módulos

### Módulo I · Identificación de puntos de dolor

Ejemplos de procesos repetitivos en Pan de Casa que el participante podría detectar:

- María contesta 30-50 mensajes de WhatsApp al día con las mismas preguntas (horario, disponibilidad de un pan específico, dirección).
- Responder quejas ocasionales sobre productos le toma 20-30 min por cada una.
- Cada lunes, escribir el menú semanal para redes sociales le toma 45 min.

Actividad: el participante identifica procesos equivalentes en **su propio negocio/vida** usando Pan de Casa como espejo.

### Módulo II · Construcción del producto (en este caso, un prompt)

El instructor demuestra en vivo, con caso Pan de Casa:

```
ROL:         "Actúa como gerente de servicio al cliente con 10 años
             de experiencia en pequeños comercios de alimentos"
CONTEXTO:    "Mi negocio es Pan de Casa, panadería artesanal en Tlalpan.
             Mis clientes son familias locales que nos conocen por nombre.
             Nuestro valor diferenciador es la calidez del trato."
INSTRUCCIÓN: "Redacta una respuesta empática para un cliente que escribe
             quejándose de que el pan llegó frío en su entrega a domicilio."
RESTRICC.:   "No uses tecnicismos. No excedas 100 palabras. Mantén el
             tono cálido y personal, no corporativo."
FORMATO:     "Responde en 3 párrafos cortos: (1) disculpa sincera,
             (2) solución concreta, (3) invitación a regresar."
```

Participante luego aplica la misma estructura **a su propio negocio**.

### Módulo III · Análisis ético / sesgos

Casos de dilema con Pan de Casa:

- ¿Qué pasa si el prompt genera una respuesta tan perfecta que el cliente siente que no es humana?
- Si María automatiza 80 % de las respuestas, ¿qué pasa con la "calidez" que es su diferenciador?
- ¿Cuándo es necesario que María conteste personalmente?

Participante analiza su propio caso aplicando los mismos criterios.

---

## Variantes del caso para otros dominios

### Para cursos de ventas

Sustituir "Pan de Casa" por "Taller de Reparación Jiménez" (taller mecánico familiar). Mismos atributos: dueño cercano, clientes recurrentes, dilema crecimiento vs calidez.

### Para cursos de gestión de equipos

Sustituir por "Clínica Dental Salud" (clínica pequeña con 3 odontólogos asociados). Dilemas: coordinar turnos, comunicación interna, unificar criterios sin jerarquía rígida.

### Para cursos técnicos

Sustituir por "Corte y Diseño CNC" (CYD) directamente. Caso propio del autor, ventaja de Skin in the Game total.

### Para cursos generales

Mantener "Pan de Casa" y adaptar los ejemplos al dominio del curso.

---

## Regla para la skill

Cuando se proponga un caso ancla en T2-T3, siempre:

1. Ofrecer este caso canónico como Opción A.
2. Ofrecer una variante adaptada al sector del grupo como Opción B.
3. Dejar espacio a Opción C (custom del usuario).

---

*Caso extraído de la Planeación v4 del curso "IA Estratégica y Diseño de Instrucciones Proactivas" · DE 2026.*
