---
título: Paleta y Tipografía · DE + iAprende
tipo: asset_branding
tags: [branding, paleta, tipografia]
---

# Paleta y Tipografía · Desarrollos Elaborados + iAprende

Sistema de marca aplicable a todos los artefactos producidos por la skill.

---

## Paleta completa

| Rol | Color | Hex | Uso |
|---|---|---|---|
| Fondo principal | Blanco puro | `#FFFFFF` | Fondos de páginas y slides |
| Fondo secundario | Blanco cálido | `#F9F9F7` | Recuadros destacados, zonas alternas |
| Texto principal | Carbón suave | `#333333` | Cuerpo de texto, no puro negro |
| Titulares / Headers | Cobalt Blue | `#2A4B7C` | Títulos, bordes de tablas, acentos navegación |
| CTA / Acento cálido | Burnt Orange | `#E07A5F` | Botones de acción, links importantes, resaltados |
| Chips / Badges mint | Mint | `#D4E5DF` | Etiquetas de categoría, estados positivos |
| Chips / Badges lavender | Lavender | `#E6E1F0` | Etiquetas secundarias, estados neutros |

---

## Tipografía

| Rol | Fuente | Peso | Tamaño (doc / slide) |
|---|---|---|---|
| Titular 1 (portadas) | Libre Baskerville | Bold | 28 pt / 54 pt |
| Titular 2 (secciones) | Libre Baskerville | Bold | 20 pt / 40 pt |
| Titular 3 (subsecciones) | Libre Baskerville | Bold | 16 pt / 28 pt |
| Cuerpo / UI | Inter | Regular | 11 pt / 18-20 pt |
| Énfasis | Inter | Medium | — |
| Datos técnicos / código | JetBrains Mono | Regular | 10 pt / 16 pt |
| Notas al pie / disclaimers | Inter | Regular 8 pt | — |

**Fallback jerárquico** si las fuentes no están embebidas:
1. Georgia (en lugar de Libre Baskerville)
2. Arial / Helvetica (en lugar de Inter)
3. Consolas / Courier New (en lugar de JetBrains Mono)

---

## Reglas de composición

- **Modo claro siempre** (sin dark mode)
- **Espaciado generoso** (márgenes 2.5 cm en documentos, padding 40 px en slides)
- **Sombras suaves y difusas** (no hard shadows)
- **Radios:** 12 px tarjetas, 8 px botones, 100 px chips
- **Dirección de ilustraciones:** flat design editorial, sin personas fotorrealistas
- **Uso de iconografía:** lineart fino de 2 px stroke en cobalt

## Voz y tono

- **Humanismo tecnológico:** técnico pero empático
- **Skin in the Game:** no teórico, validado en operación real
- **Activo y directo:** verbos fuertes, oraciones cortas
- **Sin jerga innecesaria:** el lector debe entender sin diccionario

## No:

- Ilustraciones fotorrealistas de personas
- Dark mode
- Estadísticas sin fuente verificada
- Stock photos genéricos (mejor sin imagen que genérica)
- Sombras duras
- Animaciones llamativas en slides (solo fade/push sobrio)

---

*Aplica a los 12 artefactos de la skill sin excepción.*
