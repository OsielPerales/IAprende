---
título: Portadas y Firmas · Especificaciones
tipo: asset_branding
tags: [branding, portadas, firmas]
---

# Portadas y Firmas

Reglas de composición de la portada de cada artefacto y de la firma institucional.

---

## Portada canónica · Manuales

```
┌─────────────────────────────────────────┐
│                                         │
│   [ilustración flat editorial           │
│    grande, relacionada al dominio       │
│    del curso, sin personas]             │
│                                         │
│                                         │
│   MANUAL DEL {PARTICIPANTE/INSTRUCTOR}  │   ← Libre Baskerville Bold 28pt
│                                         │
│   {Nombre del curso completo}           │   ← Libre Baskerville Bold 20pt
│                                         │
│   Versión {n}                           │   ← Inter Regular 11pt
│                                         │
│   Diseñador Instruccional:              │   ← Inter Medium 11pt
│   Osiel Alejandro Perales Jiménez       │   ← Inter Regular 11pt
│                                         │
│   Desarrollos Elaborados · iAprende     │   ← Inter Regular 11pt cobalt
│   {mes año}                             │
│                                         │
└─────────────────────────────────────────┘
```

**Reglas duras de la portada:**

- NO aparece el logo de B Smarter en la portada
- NO aparece el número de la certificación CONOCER en la portada
- El logo de iAprende / DE va como firma al pie, no como header
- La ilustración es flat editorial, nunca fotorrealista de personas

---

## Portada canónica · Planeación / Carta Descriptiva

Documento técnico, portada simplificada:

```
DOCUMENTO DE PLANEACIÓN DEL CURSO
{Nombre del curso}
EC0301 · versión {n}
{fecha}
Diseñador: Osiel Alejandro Perales Jiménez
Desarrollos Elaborados · iAprende
```

---

## Portada canónica · Slides

Slide 1 es portada visual:

- Imagen de fondo flat editorial (puede ser un degradado cobalt → blanco)
- Título en Libre Baskerville Bold 72 pt blanco o cobalt
- Subtítulo en Libre Baskerville Regular 32 pt
- Logo iAprende esquina inferior izquierda
- Fecha + versión esquina inferior derecha

---

## Firma institucional · pie de página de artefactos largos

Aparece en pie de cada página de manuales y planeaciones:

```
— Desarrollos Elaborados · iAprende —
Página {n} de {total}   ·   {nombre_del_curso}
```

---

## Bloque de créditos · última página

Aparece como último elemento de cada manual / planeación:

```
╔═══════════════════════════════════════════════════╗
║                                                   ║
║   Desarrollos Elaborados · iAprende               ║
║                                                   ║
║   Documento diseñado por                          ║
║   Osiel Alejandro Perales Jiménez                 ║
║                                                   ║
║   Curso diseñado bajo estándar CONOCER EC0301     ║
║   Certificación emitida a través del ECE          ║
║   B Smarter — Capacitación y Certificación        ║
║   Profesional                                     ║
║                                                   ║
║   Contacto:                                       ║
║   osiel.perales@desarrolloselaborados.com         ║
║   WhatsApp 866-116-0704                           ║
║   iaprende-desarrollos.web.app                    ║
║                                                   ║
║   © {año} · Todos los derechos reservados         ║
║                                                   ║
╚═══════════════════════════════════════════════════╝
```

---

## Regla crítica

**B Smarter solo aparece en:**
1. El bloque de créditos final (como ECE certificador)
2. El pie legal interior (página 2 o 3)

**B Smarter NO aparece en:**
1. La portada
2. El encabezado de páginas
3. Los slides (excepto última de créditos opcional)

Esto protege la identidad de marca DE/iAprende mientras reconoce correctamente a la ECE certificadora.

---

*Aplicable a los 12 artefactos.*
