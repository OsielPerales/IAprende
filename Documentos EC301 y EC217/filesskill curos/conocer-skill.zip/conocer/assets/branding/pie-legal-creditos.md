---
título: Pies Legales y Créditos
tipo: asset_branding
tags: [branding, legal, creditos]
---

# Pies Legales y Créditos

Textos legales normalizados. Usar literal en los artefactos.

---

## Pie legal corto (interior página 2 o 3 de Manuales)

> Curso diseñado bajo estándar CONOCER EC0301 · Certificación emitida a través del ECE B Smarter.

---

## Pie legal extendido (última página de Manuales / Planeación)

> Este documento es propiedad de Desarrollos Elaborados.  
> Puede compartirse libremente en contextos académicos.  
> Su uso comercial requiere autorización escrita del autor.
>
> El curso fue diseñado siguiendo el Estándar de Competencia CONOCER EC0301 "Diseño de cursos de formación del capital humano de manera presencial grupal". La certificación del diseñador fue emitida a través del Entidad de Certificación y Evaluación (ECE) B Smarter · Capacitación y Certificación Profesional.
>
> El contenido, ejemplos y casos de estudio presentados en este documento son producto del trabajo original del autor, salvo cuando se cita explícitamente una fuente en la bibliografía.

---

## Crédito del diseñador

Aparece en:
- Carta Descriptiva · sección INFORMACIÓN GENERAL
- Manuales · portada + créditos finales
- Slides · última slide

```
Diseñador Instruccional:
Osiel Alejandro Perales Jiménez

Desarrollos Elaborados · iAprende
{mes año}
```

---

## Crédito de revisión / acreditación externa

Solo cuando el curso haya sido formalmente revisado por B Smarter y aprobado. **No usar sin aprobación explícita del evaluador.**

```
Documento revisado por:
Iván Téllez López
Coordinador Académico · B Smarter
{fecha revisión}
```

---

## Declaración de producción asistida por IA

Opcional, recomendable incluir en la página de créditos:

> Este documento fue producido con asistencia de herramientas de Inteligencia Artificial bajo la dirección humana del autor, siguiendo el principio Skin in the Game de Desarrollos Elaborados: cada recurso, técnica y caso aquí presentado ha sido validado previamente en la operación propia del autor antes de enseñarse.

---

## Contacto institucional

Aparece en última página y última slide:

```
Contacto:
Osiel Alejandro Perales Jiménez
osiel.perales@desarrolloselaborados.com
WhatsApp 866-116-0704
Monclova, Coahuila, México

Plataforma iAprende:
iaprende-desarrollos.web.app

Desarrollos Elaborados:
{URL institucional}
```

---

*Textos revisados y aprobados. No modificar sin consulta al autor.*
