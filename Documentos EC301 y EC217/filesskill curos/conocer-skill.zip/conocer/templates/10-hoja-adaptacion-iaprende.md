---
título: Template · Hoja de Adaptación iAprende
tipo: template
artefacto: 10 de 12
tags: [template, iaprende, bloques, firestore, adaptacion]
---

# Template · Hoja de Adaptación iAprende

Documento que traduce el curso diseñado a 35–40 bloques implementables en la plataforma iAprende. Patrón extraído de `VERIFICACION_CURSO_IAPRENDE_N1_v2.md`.

Schema completo en [[../references/firestore-iaprende-schema]].

---

## Encabezado

```
# DOCUMENTO DE VERIFICACIÓN DE CUMPLIMIENTO
## Curso: {curso_nombre} — v{version}

**Plataforma:**     iAprende · `iaprende-desarrollos.web.app`
**Firebase Project:** `iaprende-1415d`
**Stack:**          React + TypeScript + Vite + Firebase (Auth + Firestore + Hosting)
**Versión:**        1.0 · {mes año}
**Autor:**          Osiel Alejandro Perales Jiménez · Desarrollos Elaborados
**Estándar:**       EC0301 · Certificado por B Smarter

---
```

---

## Instrucciones de uso (copiar literal)

```
Este documento es la referencia maestra de transcripción e implementación
del curso en la plataforma iAprende. Para cada bloque se especifica:

- `FUENTE` — de dónde proviene el contenido
- `MÓDULO` — id del módulo
- `ORDEN` — orden secuencial dentro del curso
- `TIPO` — tipo de bloque en el schema Firestore
- `DURACIÓN` — minutos estimados
- `ESTADO` — `[ ]` pendiente · `[x]` completado
- `CONTENIDO A IMPLEMENTAR` — texto exacto o descripción
- `INTERACTIVO` — descripción técnica del simulador
- `ALMACENAMIENTO` — (si aplica) ruta Firestore donde se persiste
```

---

## Arquitectura de almacenamiento (copiar literal)

Ver [[../references/firestore-iaprende-schema]] — sección "Colecciones Firestore" y "Tipos de Bloque".

Estructura de documento en este curso:

```
cursos/
  └── c-{slug}/
        titulo:       "{curso_nombre}"
        version:      "{version}"
        duracion_min: {total_min}
        modulos:      ["preambulo", "encuadre", "modulo-1", "modulo-2",
                       "modulo-3", "sumativa", "cierre"]
        activo:       true
        created_at:   timestamp
```

Alojamiento de assets:

```
Firebase Hosting / assets / curso-{slug} /
  ├── infografias/
  ├── iconos/
  ├── imagenes/
  └── slides-recicladas/
```

---

## BLOQUES — Especificación completa

### ▸ PREÁMBULO (opcional, 1 bloque)

#### BLOQUE P.1 — {título del preámbulo — ej. "La Nueva Economía Cognitiva"}

```
FUENTE:       {nuevo / reciclado}
MÓDULO:       preambulo
ORDEN:        1
TIPO:         infografia
DURACIÓN:     5 min
ESTADO:       [ ]
```

**CONTENIDO A IMPLEMENTAR:**

{descripción del contenido visual + textual}

**INTERACTIVO:**

{descripción de zonas expandibles, animaciones, badges}

---

### ▸ ENCUADRE (5 bloques)

#### BLOQUE E.1 — Bienvenida

```
FUENTE:       Slide 2 + Manual Participante sección 3
MÓDULO:       encuadre
ORDEN:        2
TIPO:         texto_rico
DURACIÓN:     3 min
ESTADO:       [ ]
```

**CONTENIDO:** bienvenida + filosofía Skin in the Game + anuncio de producto real.

#### BLOQUE E.2 — Objetivo General

```
MÓDULO:       encuadre
ORDEN:        3
TIPO:         texto_rico
DURACIÓN:     2 min
```

**CONTENIDO:** el Objetivo General del curso en formato Mager, presentado en recuadro destacado.

#### BLOQUE E.3 — Mapa del Curso

```
MÓDULO:       encuadre
ORDEN:        4
TIPO:         infografia
DURACIÓN:     3 min
```

**CONTENIDO:** diagrama visual de los 3 módulos con duración de cada uno.

#### BLOQUE E.4 — Expectativas

```
MÓDULO:       encuadre
ORDEN:        5
TIPO:         tabla_editable
DURACIÓN:     5 min
```

**ALMACENAMIENTO:** `progreso_alumno/{userId}_{cursoId}.compromisos_encuadre`

#### BLOQUE E.5 — Diagnóstica

```
MÓDULO:       encuadre
ORDEN:        6
TIPO:         cuestionario
DURACIÓN:     5 min
```

**CONTENIDO:** 5 preguntas abiertas de diagnóstico. **ALMACENAMIENTO:** `progreso_alumno/{userId}_{cursoId}.respuestas_diagnostica`

---

### ▸ MÓDULO I · {M1_titulo} (7 bloques típicos)

#### BLOQUE M1.0 — Portada Módulo I

```
TIPO:         portada
ORDEN:        7
DURACIÓN:     1 min
```

#### BLOQUE M1.1 — {lección 1}

```
TIPO:         {comparador / texto_rico / infografia — según contenido}
ORDEN:        8
DURACIÓN:     3 min
```

[continuar con M1.2 a M1.N según el curso — típicamente 5-7 bloques]

---

### ▸ MÓDULO II · {M2_titulo} (9 bloques típicos)

Estructura típica:

- `M2.0` Portada
- `M2.1` Estructura del producto (infografia)
- `M2.2` a `M2.5` lecciones por componente (campo_libre / texto_rico / simulador_html)
- `M2.6` Demo completa (simulador_html)
- `M2.7` Simulador del producto del alumno ★ (simulador_prompt — **clave**)
- `M2.8` Formativa 50 % (checklist)

**ALMACENAMIENTO de simulador_prompt:** `progreso_alumno/{userId}_{cursoId}.prompt_maestro`

---

### ▸ MÓDULO III · {M3_titulo} (5 bloques típicos)

- `M3.0` Portada
- `M3.1` Problema o dilema central (simulador_html / texto_rico)
- `M3.2` Conceptos clave (texto_rico)
- `M3.3` Criterios de corrección (checklist)
- `M3.4` Caso ético colaborativo (caso_etico)

---

### ▸ SUMATIVA (4 bloques)

- `S.0` Portada Sumativa
- `S.1` Desafío aplicado (simulador_prompt)
- `S.2` Teoría 3 preguntas (cuestionario)
- `S.3` Auto-auditoría ética (checklist)

---

### ▸ CIERRE (3 bloques)

- `C.1` Lo Que Te Llevas Hoy (resumen_personal, con datos dinámicos del alumno)
- `C.2` Siguientes Pasos 72 h (checklist persistente)
- `C.3` Ecosistema iAprende (mapa_ecosistema)

---

## RESUMEN DE ESTADO DE IMPLEMENTACIÓN

| Bloque | Tipo | Fuente | Estado |
|---|---|---|---|
| P.1 | infografia | {fuente} | [ ] |
| E.1 | texto_rico | Slide 2 | [ ] |
| E.2 | texto_rico | Slide 3 | [ ] |
| E.3 | infografia | Slide 4 | [ ] |
| E.4 | tabla_editable | Slide 5 | [ ] |
| E.5 | cuestionario | Slide 6 | [ ] |
| M1.0 | portada | Slide 7 | [ ] |
| M1.1 | ... | ... | [ ] |
| ... | ... | ... | [ ] |
| C.3 | mapa_ecosistema | Slide 34 + NUEVO | [ ] |

**Total: {n_bloques} bloques · {n_tipos} tipos distintos · {n_nuevos} bloques completamente nuevos.**

---

## COMPONENTES REACT A CREAR / REGISTRAR

```typescript
// src/components/bloques/
// Existentes (reutilizables)
├── BloquePortada.tsx
├── BloqueTextoRico.tsx
├── BloqueComparador.tsx
├── BloqueChecklist.tsx
├── BloqueCuestionario.tsx
├── BloqueCampoLibre.tsx
├── BloqueSimuladorHtml.tsx
├── BloqueInfografia.tsx
├── BloqueTarjetasFlip.tsx
├── BloqueTablaEditable.tsx
├── BloqueSimuladorPrompt.tsx   ← crucial para cursos con producto prompt-based
├── BloqueCasoEtico.tsx
├── BloqueResumenPersonal.tsx
└── BloqueMapaEcosistema.tsx
```

Marcar cuáles son nuevos a crear para este curso específico.

---

## Metadata del documento

- **Título:** `VERIFICACION_CURSO_{slug}_v{n}.md`
- **Ubicación:** vault Obsidian en `_skills/conocer/entregas/` o en la carpeta del curso
- **Propósito:** guiar a Antigravity / Claude Code en la implementación técnica en iAprende
- **Actualización:** cambiar `[ ]` a `[x]` conforme se implementa cada bloque

---

*Template generado por la skill. Rellenado por `agent-iaprende-bloques` en T6 usando Planeación + Manual Participante como input.*
