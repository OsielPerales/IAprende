---
título: Template · Evaluación Sumativa / Final · Proyecto + Rúbrica
tipo: template
estandar: EC0301 (E1024) + EC0217.01
artefacto: 5 de 12
tags: [template, evaluacion-sumativa, proyecto, rubrica, auto-auditoria-etica]
---

# Template · Evaluación Sumativa / Final

Instrumento de cierre. Combina **Parte I** (Proyecto aplicado 20 pts) + **Parte II** (Teoría 3 preguntas 3 pts) + **Parte III** (Auto-auditoría ética obligatoria). Valor: 50 % del total. 

Total: 23 pts convertidos a escala del 50 %.

---

## Encabezado común

```
EVALUACIÓN SUMATIVA / FINAL

Nombre del curso:     {curso_nombre}
Instructor:           ____________________________
Lugar de Impartición: ____________________________
Duración del curso:   120 min · Horario: ______ · Fecha: _______
Nombre del Participante: ________________________________

Objetivo:     Evaluar la capacidad práctica de crear {producto_aplicable}
              + comprensión de principios teóricos y éticos de {dominio}
Valor:        50 % del total del curso
```

---

## Instrucciones generales

```
Parte I  — Construye tu {producto_principal} Final para el {caso_real}
           que identificaste en tu bitácora del Módulo I.
Parte II — Selecciona la mejor opción para cada pregunta de teoría.
Parte III — Responde la Auto-auditoría ética antes de entregar.

Condiciones: Individual
Tiempo:      10 min
```

---

## Parte I · El Desafío / Proyecto Aplicado

### Contexto

> Vas a "contratar" a {herramienta_IA} para resolver un problema concreto de tu día a día. El proyecto debe ser **usable mañana**, no teórico.

### Entregable

```
1. Título del proceso / problema a resolver:
   _____________________________________________________________
```

### Estructura de tu {producto_principal} Final

| Componente | Tu contenido |
|---|---|
| **{Componente_1}** — {descripción corta} |  |
| **{Componente_2}** — {descripción corta} |  |
| **{Componente_3}** — {descripción corta} |  |
| **{Componente_4}** — {descripción corta} |  |
| **{Componente_5}** — {descripción corta} |  |

---

## Parte II · Validación de Conceptos (Teoría)

Selecciona la mejor opción para cada pregunta.

### 1. {Pregunta_teoria_1 — sobre mecanismo interno}

a) {opcion_a}  
b) {opcion_b}  
c) {opcion_c}

### 2. {Pregunta_teoria_2 — sobre error o fallo}

a) {opcion_a}  
b) {opcion_b}  
c) {opcion_c}

### 3. {Pregunta_teoria_3 — sobre responsabilidad / ética}

a) {opcion_a}  
b) {opcion_b}  
c) {opcion_c}

---

## Parte III · Auto-auditoría Ética (obligatoria)

Marca antes de entregar:

```
¿Este producto pide generar información falsa o engañosa?        [ ] Sí  [ ] No
¿Incluí datos confidenciales reales (cuentas, nombres, RFCs)?    [ ] Sí  [ ] No
                                                 (Si es Sí, corrígelo AHORA antes de entregar.)
¿El uso que daré a esta salida respeta los derechos de terceros? [ ] Sí  [ ] No
```

Si alguna respuesta te alerta, corrige antes de entregar.

---

## RÚBRICA DE EVALUACIÓN · Uso exclusivo del instructor

### Clave de respuestas · Parte II (Teoría)

**1 — ({letra})**  
**2 — ({letra})**  
**3 — ({letra})**

Cada respuesta correcta: 1 pt · Total Parte II: 3 pts

### Rúbrica · Parte I (5 criterios × 4 niveles = 20 pts máx)

| Criterio | Excelente (4) | Satisfactorio (3) | En Desarrollo (2) | Requiere Apoyo (1) |
|---|---|---|---|---|
| **{Criterio_1}** | {descripcion_excelente_1} | {descripcion_satisfactorio_1} | {descripcion_desarrollo_1} | Ausente |
| **{Criterio_2}** | {descripcion_excelente_2} | {descripcion_satisfactorio_2} | {descripcion_desarrollo_2} | Ausente o con riesgo |
| **{Criterio_3}** | {descripcion_excelente_3} | {descripcion_satisfactorio_3} | {descripcion_desarrollo_3} | Ausente |
| **{Criterio_4}** | {descripcion_excelente_4} | {descripcion_satisfactorio_4} | {descripcion_desarrollo_4} | Ausente |
| **Aplicabilidad** | Lista para usar mañana en su {contexto real} | Requiere edición menor para ser útil | Ejercicio teórico difícil de aplicar | No resuelve el problema planteado |

### Escala de calificación

```
Parte I (Proyecto): ______ / 20 pts
Parte II (Teoría):  ______ / 3 pts
Parte III (Ética):  (obligatoria, sin puntos, pero bloquea certificación si hay riesgo grave)

TOTAL: ______ / 23 pts

Escala final:
  18–20 pts → Dominio Avanzado (Certificado con Mención)
  14–17 pts → Competente (Aprobado, ≥80 %)
  < 14 pts  → Requiere refuerzo en {módulo_donde_fallo_lo_indique}
```

---

## Comentario de aplicabilidad del instructor (obligatorio)

```
Cómo mejorar el producto para el negocio real del participante:

______________________________________________________________________

______________________________________________________________________

Nota: No solo dar el puntaje. Escribir un comentario concreto que
el participante pueda aplicar al regresar a su trabajo.

Firma del instructor: ______________________   Fecha: __________
```

---

## Metadata del documento

- **Título:** `Evaluacion_Sumativa_{slug}.docx`
- **Se imprime:** 1 copia por participante
- **Entregable EC0301:** documento 4 de 6 · **EC0217.01:** documento 5 de 7
- **Criterios EC0301 E1024 cubiertos:** P1 (instrumento) + P2 (instrucciones) + P3 (reactivos medibles, con valor) + P4 (claves + rúbrica con puntaje total esperado)

---

*Template generado por la skill. Rellenado por `agent-evaluaciones` en T6 usando los objetivos y caso ancla definidos en T2-T5.*
