---
título: Template · Brief para Generación de .pptx
tipo: template
artefacto: 12 de 12
tags: [template, pptx, slides, brief]
---

# Template · Brief para Generación de Slides .pptx

Instrucciones para invocar la skill `pptx` (o Claude Code / Antigravity con la skill `/mnt/skills/public/pptx/SKILL.md`) a partir del Storyboard aprobado.

Este documento **no** contiene el storyboard — lo toma como input. El storyboard debe estar en estado `✅ APROBADO`.

---

## Comando de invocación

```
"Genera el archivo .pptx del curso {curso_nombre} v{version} a partir del
storyboard aprobado en <ruta_storyboard>. Aplica el sistema de marca de
Desarrollos Elaborados · iAprende. Produce un archivo de {n} slides.
Entrega el archivo en /mnt/user-data/outputs/ con el nombre
Slides_{slug}_v{version}.pptx."
```

---

## Especificaciones visuales obligatorias

### Paleta

| Rol | Color | Hex |
|---|---|---|
| Fondo principal | Blanco | `#FFFFFF` |
| Fondo secundario | Blanco cálido | `#F9F9F7` |
| Texto principal | Carbón suave | `#333333` |
| Titulares | Cobalt Blue | `#2A4B7C` |
| Acentos / CTA | Burnt Orange | `#E07A5F` |
| Chips / Badges | Mint | `#D4E5DF` |
| Chips / Badges alt | Lavender | `#E6E1F0` |

### Tipografía

| Rol | Fuente | Tamaño recomendado |
|---|---|---|
| Título de slide | Libre Baskerville Bold | 40 pt |
| Subtítulo | Libre Baskerville Regular | 24 pt |
| Cuerpo | Inter | 18-20 pt |
| Bullets | Inter Regular | 18 pt |
| Datos técnicos / código | JetBrains Mono | 16 pt |
| Notas presentador (speaker notes) | Inter | 14 pt |

**Fallback:** si las fuentes no están embebidas en la plantilla, usar Georgia (titulares) + Arial (cuerpo) + Consolas (código).

### Layout recomendado

- **Slides de portada:** imagen de fondo a pantalla completa con overlay semitransparente + título grande
- **Slides de sección:** color de fondo mint o lavender + ícono + título grande
- **Slides de contenido:** fondo blanco + barra superior cobalt + título + bullets en carbón
- **Slides de diagrama:** fondo blanco + diagrama centrado + leyenda inferior
- **Slides de cita:** fondo `#F9F9F7` + cita en Libre Baskerville italic grande + autor debajo

### Ratio y dimensiones

- **Aspect ratio:** 16:9 (pantalla moderna)
- **Dimensiones:** 1920 × 1080 px
- **Márgenes de seguridad:** 100 px en cada lado

### Elementos fijos en TODOS los slides

- **Esquina inferior izquierda:** logo iAprende pequeño (~150 px ancho)
- **Esquina inferior derecha:** número de slide + "/" + total
- **Pie central (opcional):** `{curso_nombre} · EC0301`

### Transiciones

- **Entre slides del mismo módulo:** `fade` suave 0.3s
- **Entre módulos:** `push` lateral 0.5s
- **Slides de portada:** `zoom in` 0.8s

---

## Reglas de diseño

1. **Máximo 6 elementos por slide.** Si hay más, dividir en 2 slides.
2. **Sin personas fotorrealistas.** Solo ilustraciones flat editorial o íconos.
3. **Código siempre en recuadro** con fondo `#F9F9F7` y borde mint.
4. **Citas con comillas grandes decorativas** ("❝") en cobalt.
5. **Tablas con filas alternas** en blanco y `#F9F9F7`, encabezados en cobalt.
6. **Diagramas con stroke consistente** (2 px cobalt).
7. **Animaciones sobrias:** solo `appear` en bullets individualmente si aporta al flujo.

---

## Contenido de las notas del presentador

Para cada slide, las speaker notes deben incluir:

- Qué decir al llegar al slide (apertura)
- 1-2 preguntas para el grupo si aplica
- Cuándo avanzar (duración aproximada en vivo)
- Conexión al slide siguiente

El storyboard ya contiene este texto. El brief instruye a la skill `pptx` a colocar estas notas en el campo "Notes" nativo de PowerPoint.

---

## Entregable esperado

```
Archivo: Slides_{slug}_v{version}.pptx
Slides:  ~30-35
Tamaño:  < 50 MB (optimizar imágenes)
Notas:   speaker notes en cada slide de contenido
```

**Adicionalmente:**

- Exportar una versión `.pdf` para impresión / entrega
- Si usa fuentes no estándar, embeberlas en el archivo (File > Options > Save > Embed fonts)

---

## Checklist final de slides

- [ ] Número total de slides coincide con el storyboard
- [ ] Branding (paleta + fuentes + logo) consistente en todos los slides
- [ ] Notas del presentador presentes en todos los slides de contenido
- [ ] Ningún slide tiene más de 6 elementos
- [ ] Todos los textos sin errores ortográficos
- [ ] Imágenes tienen alt-text (accesibilidad)
- [ ] Última slide tiene contacto + pie legal EC0301/B Smarter
- [ ] Archivo exportado en .pptx Y en .pdf

---

## Metadata del documento

- **Título:** `Brief_Slides_{slug}.md`
- **Ubicación:** vault Obsidian
- **Prerequisito:** Storyboard aprobado (artefacto 11)
- **Invoca skill:** `/mnt/skills/public/pptx/SKILL.md`
- **Entregable:** `.pptx` + `.pdf` en carpeta del curso

---

*Template generado por la skill. Rellenado y ejecutado por `agent-slides` en T6, tras aprobación del storyboard.*
