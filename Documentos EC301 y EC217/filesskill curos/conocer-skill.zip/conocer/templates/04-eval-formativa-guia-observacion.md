---
título: Template · Evaluación Formativa · Guía de Observación
tipo: template
estandar: EC0301 (E1024) + EC0217.01
artefacto: 4 de 12
tags: [template, evaluacion-formativa, guia-observacion, lista-cotejo]
---

# Template · Evaluación Formativa · Guía de Observación

Instrumento aplicado al final del Módulo II para evaluar la construcción del **producto principal del curso** (el entregable que el participante construye con la estructura enseñada). Valor: 50 % del total. Basado en criterios EC0301 E1024.

---

## Encabezado común

```
EVALUACIÓN FORMATIVA — GUÍA DE OBSERVACIÓN

Nombre del curso:     {curso_nombre}
Instructor:           ____________________________
Lugar de Impartición: ____________________________
Duración del curso:   120 min · Horario: ______ · Fecha: _______
Nombre del Participante: ________________________________
Módulo:               II — {M2_titulo}
Valor:                50 % del total del curso
```

---

## Parte A · Para el Participante (llena al construir su producto)

### Instrucciones

```
1. Elige uno de los {n} ejemplos/casos que aparecen a continuación.
2. Adáptalo completamente a tu propio contexto.
3. Construye tu {producto_principal} aplicando los {m} componentes.
4. Escríbelo en el recuadro de abajo.
5. Marca con ✓ los componentes incluidos antes de entregar.
```

### {n} Opciones de caso (generadas por la skill según el dominio del curso)

| Opción | Nombre del caso | Utilidad práctica |
|:-:|---|---|
| 1 | {caso_1_nombre} | {caso_1_utilidad} |
| 2 | {caso_2_nombre} | {caso_2_utilidad} |
| 3 | {caso_3_nombre} | {caso_3_utilidad} |
| 4 | {caso_4_nombre} | {caso_4_utilidad} |
| 5 | {caso_5_nombre} | {caso_5_utilidad} |

```
Elegí la opción número: ____
Nombre del caso elegido: ____________________________
```

### Construcción del producto

```
Mi {producto_principal} completo (listo para usar en {contexto_real}):

______________________________________________________________________

______________________________________________________________________

______________________________________________________________________

______________________________________________________________________

______________________________________________________________________
```

### Autoevaluación · Componentes incluidos (marca antes de entregar)

- [ ] Componente 1: {nombre_componente_1} — claro y profesional
- [ ] Componente 2: {nombre_componente_2} — específico y detallado
- [ ] Componente 3: {nombre_componente_3} — con verbo/acción fuerte
- [ ] Componente 4: {nombre_componente_4} — restricciones claras
- [ ] Componente 5: {nombre_componente_5} — formato útil

---

## Parte B · Guía de Observación · uso exclusivo del Instructor

### Instrucciones al instructor

```
Observar al participante mientras construye su producto (tras la
demostración en vivo).

Marcar "Sí" o "No" según se observe el desempeño. Cada criterio vale
10 puntos (máximo 60 puntos). La calificación se convierte al 50 %
del total del curso.

Condiciones:         Aplicación individual
Tiempo de observación: 20 min
Retroalimentación:   Inmediata, antes de cerrar calificación.
                     Si falta componente, dar 2 min para corregir.
```

### Criterios (6 × 10 pts = 60 pts = 50 % del curso)

| # | Criterio de observación (desempeño observable) | Sí | No | Puntos | Observaciones / Retroalimentación |
|:-:|---|:-:|:-:|---|---|
| 1 | El participante elaboró el **componente 1** asignando {descripcion_criterio_1} | ☐ | ☐ |  |  |
| 2 | El participante construyó el **componente 2** incluyendo {descripcion_criterio_2} | ☐ | ☐ |  |  |
| 3 | El participante redactó el **componente 3** iniciando con {descripcion_criterio_3} | ☐ | ☐ |  |  |
| 4 | El participante definió el **componente 4** con {descripcion_criterio_4} | ☐ | ☐ |  |  |
| 5 | El participante definió el **componente 5** de manera {descripcion_criterio_5} | ☐ | ☐ |  |  |
| 6 | El participante integró los componentes en un producto **coherente, fluido y listo para usar** en su contexto real | ☐ | ☐ |  |  |

**Regla:** los 5 primeros criterios son partes; el 6° es integración del producto.

### Calificación total

```
Calificación total: _______ / 60 puntos   (equivale al 50 % del curso)

Observaciones y retroalimentación inmediata del instructor:

______________________________________________________________________

______________________________________________________________________

Firma del instructor: ______________________   Fecha: __________
```

---

## Guía de respuestas para el evaluador / instructor

```
Criterios esperados: Todos los 6 ítems deben observarse como SÍ en un
                     producto de calidad.
Valor:               50 % de la calificación final del curso.
Valor de cada ítem:  10 puntos.
Total máximo:        60 puntos = 50 % del curso.

Indicaciones:
- Circular por el salón durante la construcción del producto.
- Retroalimentar EN EL MOMENTO, antes de otorgar la calificación final.
- Señalar el componente faltante y dar 2 minutos adicionales para
  que el participante corrija si es necesario.
- Solo después de la corrección, cerrar la calificación.

Nota: Si el participante elige el caso incorrecto o no adapta el
producto a su contexto real, orientarlo hacia el ejemplo más afín
a su sector.
```

---

## Metadata del documento

- **Título:** `Evaluacion_Formativa_{slug}.docx`
- **Se imprime:** 1 copia por participante (Parte A y Parte B en la misma hoja, doble faz)
- **Entregable EC0301:** documento 3 de 6 · **EC0217.01:** documento 4 de 7
- **Criterios EC0301 E1024 cubiertos:** P1 (instrumento) + P2 (instrucciones) + P3 (reactivos) + P4 (claves de respuestas para el evaluador)

---

*Template generado por la skill. Rellenado por `agent-evaluaciones` en T6.*
