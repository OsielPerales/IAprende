---
título: Template · Manual del Instructor
tipo: template
estandar: EC0301 (E1025 P6-P10)
artefacto: 8 de 12
tags: [template, manual-instructor]
---

# Template · Manual del Instructor

Documento interno del instructor. Incluye la Carta Descriptiva completa, los instrumentos de evaluación con claves, la encuesta de satisfacción, y las sugerencias pedagógicas por tema. Cumple EC0301 E1025 Productos 6-10.

---

## Metadata del documento

- **Título del archivo:** `Manual_Instructor_{slug}_EC0301.docx`
- **Formato:** `.docx` + versión `.md` en vault
- **Confidencialidad:** contiene claves de respuestas → no distribuir a participantes

---

## Estructura del documento

### 1 · Portada

```
{logo_iAprende}

MANUAL DEL INSTRUCTOR

{curso_nombre}

Versión {version}

Diseñador Instruccional: Osiel Alejandro Perales Jiménez
Desarrollos Elaborados · iAprende
{fecha}

Uso Interno · Confidencial
```

### 2 · Índice

Tabla de contenidos.

### 3 · Introducción (EC0301 E1025 P7)

Tres elementos obligatorios:

**3.1 Propósito del manual**
> Guía completa para impartir el curso bajo estándar CONOCER EC0301 + EC0217.01.

**3.2 Estructura del curso**
> Descripción narrativa de los 3 momentos (Apertura 35′ / Desarrollo 65′ / Cierre 25′).

**3.3 Modalidad del curso**
> Presencial grupal · constructivismo · 4–12 participantes · 120 min.

### 4 · Requerimientos del lugar de capacitación (EC0301 E1025 P8)

Tabla de 4 categorías:

| Características del lugar | Material de apoyo | Equipo necesario | Recomendaciones de uso |
|---|---|---|---|
| {lugar_descripcion} | {material_lista} | {equipo_lista} | {recomendaciones_uso} |

### 5 · Carta Descriptiva completa

Embebe el template `01-planeacion-carta-descriptiva.md` en su totalidad.

### 6 · Comprobación de la existencia y funcionamiento de los recursos

Embebe el template `02-lista-verificacion-requerimientos.md` resumido (lista de categorías, sin el formato imprimible).

### 7 · Secuencia Instruccional · Apertura / Encuadre

Tabla de 7 columnas (patrón caso modelo):

| Tiempo | Tema/Etapa | Actividades | Instructor (a-j) | Participantes | Técnica | Material |
|---|---|---|---|---|---|---|
| 3 min | Presentación instructor | {descripcion} | a) {accion_a}<br>b) {accion_b}<br>c) {accion_c} | {accion_participantes} | Exposición | {material} |
| 5 min | Rompe Hielo | ... | ... | ... | Rompe Hielo | ... |
| ... | ... | ... | ... | ... | ... | ... |

Incluye las 12 etapas completas del Encuadre (35 min).

### 8 · Secuencia Instruccional · Desarrollo

Misma tabla 7 columnas con las 5 etapas del Desarrollo (M-I 15′, M-II 22′, Energizante 3′, M-III 15′, Sumativa 10′).

**Importante:** cada técnica instruccional (Expositiva / Demostrativa / Diálogo-Discusión) aparece en la columna "Instructor" con su secuencia de pasos a) a i) según [[../references/tecnicas-instruccionales]].

### 9 · Secuencia Instruccional · Cierre

Misma tabla 7 columnas con las 9 etapas del Cierre (25 min).

### 10 · Sugerencias para el desarrollo de los temas (EC0301 E1025 P9)

Por cada módulo:

**Módulo I · {M1_titulo}**
- Apoyos sugeridos: {lista}
- Técnica canónica: Expositiva dialogada (ver pasos a-i)
- Ejemplos por sector del grupo: {ejemplos}
- Preguntas de verificación sugeridas: {preguntas}
- Ejemplo de síntesis: {sintesis}
- Forma, criterios y tiempos de evaluación: {evaluacion_m1}

**Módulo II · {M2_titulo}**
- Apoyos sugeridos
- Técnica canónica: Demostrativa (pasos a-i)
- Caso ancla para demostración en vivo: {caso_ancla_aplicacion}
- Lista de cotejo para retroalimentación
- Forma, criterios y tiempos

**Módulo III · {M3_titulo}**
- Apoyos sugeridos
- Técnica canónica: Diálogo-Discusión (pasos a-i)
- Casos preparados para la discusión: {casos_3}
- Reglas de moderación
- Forma, criterios y tiempos

### 11 · Cierre del curso (secuencia detallada)

Descripción paso a paso de las 9 etapas del cierre:

- Técnica grupal "{nombre_cierre}" con instrucciones completas
- Resumen ejecutivo sugerido
- Método para verificar logro de expectativas
- Método para autoevaluación de logro de objetivos
- Sugerencias de continuidad que ofrece el instructor
- Cómo compartir la bibliografía
- Cómo inducir compromisos de aplicación
- Aplicación de encuesta de satisfacción
- Entrega de constancias + foto

### 12 · Instrumentos de evaluación con claves

Embebe los 3 instrumentos completos con sus claves y rúbricas:

- Eval Diagnóstica con guía al instructor (del template 03)
- Eval Formativa · Parte B guía observación (del template 04)
- Eval Sumativa con clave Parte II + rúbrica Parte I + notas Parte III (del template 05)

### 13 · Encuesta de satisfacción embebida (EC0301 E1024 P5)

Embebe el template `06-eval-satisfaccion.md` completo + el bloque "Análisis post-evento".

### 14 · Bibliografía (EC0301 E1025 P10)

Formato APA completo. Misma estructura que en Manual Participante + referencias adicionales específicas para instructor:

- Obras de referencia sobre técnicas instruccionales
- Estándar EC0301 y EC0217.01
- Lecturas de profundización para el instructor

### 15 · Pie legal y créditos

```
Documento diseñado por Osiel Alejandro Perales Jiménez
Desarrollos Elaborados · iAprende · {año}

Curso diseñado bajo estándar CONOCER EC0301
Certificación emitida a través del ECE B Smarter.

Uso interno del instructor. No distribuir a participantes.
```

---

## Estilo editorial (igual que Manual Participante)

- Tipografía Libre Baskerville / Inter / JetBrains Mono
- Colores Cobalt / Orange / Mint / Lavender
- Márgenes 2.5 cm, interlineado 1.5
- **Sin errores ortográficos** (criterio EC0301 literal)

---

## Checklist EC0301 E1025 P6-P10 antes de declarar listo

- [ ] Producto 6 — 12 items del Manual Instructor
- [ ] Producto 7 — 3 items de la Introducción
- [ ] Producto 8 — 4 items de Requerimientos del lugar
- [ ] Producto 9 — 4 items de Temas del Manual Instructor
- [ ] Producto 10 — 6 items de las fuentes

---

*Template generado por la skill. Rellenado por `agent-manual-instructor` en T6 usando la Planeación + los instrumentos de evaluación ya producidos.*
