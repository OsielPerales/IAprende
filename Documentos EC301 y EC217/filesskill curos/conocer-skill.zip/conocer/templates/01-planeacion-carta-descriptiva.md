---
título: Template · Planeación del Curso / Carta Descriptiva
tipo: template
estandar: EC0301 (E1023) + EC0217.01
artefacto: 1 de 12
tags: [template, planeacion, carta-descriptiva]
---

# Template · Planeación / Carta Descriptiva

Plantilla canónica alineada con criterios EC0301 E1023 (ver [[../references/ec0301-criterios-evaluacion]]). Produce los 9 Productos requeridos para el Elemento 1.

**Duración canónica:** 120 min · **Distribución:** 35/65/25. Ver [[../references/tiempos-canonicos-120min]].

---

## Estructura del documento

Una sola tabla continua con 12 secciones verticales. El agente productor (`agent-planeacion`) rellena con los datos consolidados del T5 de la skill.

---

### SECCIÓN 1 · INFORMACIÓN GENERAL

```
Nombre del Curso-taller:        {curso_nombre}
Nombre del Facilitador/Instructor: Osiel Alejandro Perales Jiménez
Lugar de Instrucción:           Presencial en salón o aula habilitada
Duración:                       120 minutos
Horario:                        ____________
Fecha(s):                       ____________
Número de participantes:        4 a 12

Perfil del participante: {perfil_objetivo — párrafo detallado}

Habilidades cognoscitivas: {habilidades_cognoscitivas_requeridas}
Habilidades psicomotoras: {habilidades_psicomotoras_requeridas}
Habilidades afectivas: {habilidades_afectivas_requeridas}
```

---

### SECCIÓN 2 · PROPÓSITO/BENEFICIO

Párrafo único de 3–5 oraciones describiendo:
1. Qué problema resuelve el curso.
2. Para quién es (perfil agregado).
3. Qué beneficio central aporta (productividad / ahorro / desarrollo).
4. Criterio diferenciador (Skin in the Game, validado en operación real).

---

### SECCIÓN 3 · OBJETIVO GENERAL

| Sujeto: ¿Quién? | Acción o comportamiento: ¿Cuándo? / ¿Qué? | Condición de operación: ¿Cómo? / ¿Para qué? |
|---|---|---|
| El participante | {objetivo_general_accion — patrón Mager} | ¿Cómo? {metodos}<br>¿Para qué? {proposito} |

Sigue patrón Mager completo (ver [[../references/redaccion-objetivos-mager]]).

---

### SECCIÓN 4 · OBJETIVOS PARTICULARES

| Sujeto | Acción o comportamiento | Condición de operación | Temas | Beneficios |
|---|---|---|---|---|
| El Participante | {obj_M1_accion} | ¿Cómo? {M1_metodo}<br>¿Para qué? {M1_proposito} | **Módulo I: {M1_titulo}**<br>{M1_temas} | {M1_beneficios} |
| El Participante | {obj_M2_accion} | ¿Cómo? {M2_metodo}<br>¿Para qué? {M2_proposito} | **Módulo II: {M2_titulo}**<br>{M2_temas} | {M2_beneficios} |
| El Participante | {obj_M3_accion} | ¿Cómo? {M3_metodo}<br>¿Para qué? {M3_proposito} | **Módulo III: {M3_titulo}**<br>{M3_temas} | {M3_beneficios} |
| El Participante | **A lo largo del curso · Saber Convivir** · {obj_transversal_accion} | ¿Cómo? Mediante trabajo en equipos, intercambio y retroalimentación entre pares<br>¿Para qué? Para fomentar ambiente colaborativo y construir red profesional | Saber Convivir · Trabajo colaborativo · Retroalimentación entre pares | Fortalece habilidades sociales y profesionales, creando redes y promoviendo aprendizaje mutuo |

**Regla dura:** la 4ª fila (Saber Convivir) siempre aparece, idéntica o casi idéntica a la plantilla.

---

### SECCIÓN 5 · REQUERIMIENTOS (tabla 6 columnas)

| Instalaciones, mobiliario y distribución | Equipo de apoyo | Materiales didácticos de apoyo | Requerimientos humanos | Salud/seguridad/higiene/protección civil | Otros requerimientos |
|---|---|---|---|---|---|
| Sala con proyector/pantalla<br>Conexión estable a internet<br>Mesas para equipos de 4–5<br>Sillas para {n} participantes<br>Contactos eléctricos | Computadora/laptop/celular por participante (mín. 1 cada 2)<br>Proyector o monitor<br>Cables, extensiones y regletas<br>Apuntador láser | Manual Participante<br>Manual Instructor<br>Evaluaciones (diag, form, final, satisfacción)<br>Lista de asistencia<br>Lista de verificación de requerimientos<br>Hojas, plumas, marcadores | Instructor especializado en {dominio}<br>Apoyo técnico (opcional) | Botiquín de primeros auxilios<br>Gel antibacterial<br>Señalización rutas evacuación<br>Extintor<br>Espacio ventilado | {recursos_especificos_curso — ej. acceso a plataformas, cuentas de apps, tarjetas con ejemplos} |

---

### SECCIÓN 6 · EVALUACIÓN

| Aspecto | Valor/Porcentaje | Instrumento | Momento |
|---|---|---|---|
| Evaluación Diagnóstica | Referente (0 %) | Cuestionario 5 preguntas abiertas | Al inicio |
| Evaluación Formativa | 50 % | Guía de Observación / Lista de cotejo | Intermedia (fin M-II) |
| Evaluación Sumativa | 50 % | Cuestionario + Proyecto final + Rúbrica 5 criterios | Cierre del Desarrollo |

**Aprobación: 80 % mínimo de la calificación total.**

---

### SECCIÓN 7 · COMPROBACIÓN DE RECURSOS

| Etapa | Actividades | Duración | Técnica | Material |
|---|---|---|---|---|
| Comprobación de la existencia y funcionamiento de los recursos | 1. Aplicar lista de verificación<br>2. Probar equipo<br>3. Verificar mobiliario<br>4. Verificar materiales conforme al número de participantes | 20 min antes del inicio | Verificación sistemática | Lista de verificación de requerimientos |

---

### SECCIÓN 8 · APERTURA O ENCUADRE (tabla 5 col)

| Duración | Etapa del Encuadre | Descripción de Actividades | Técnica | Material |
|---|---|---|---|---|
| 3 min | Presentación del instructor | {descripcion} | Exposición dialogada | Diapositivas, proyector |
| 5 min | Presentación de participantes · Rompe Hielo "{nombre_rompehielo}" | {secuencia_instrucciones_a_f} | Rompe Hielo | {material} |
| 3 min | Presentación del curso · Objetivo general | {instructor_recita_objetivo_general} | Exposición | Diapositivas |
| 2 min | Objetivos Particulares | Presentar los 4 objetivos en detalle | Exposición | Diapositivas |
| 3 min | Descripción general del desarrollo | Presentar los 3 momentos con tiempos | Exposición | Diapositivas |
| 2 min | Temario del curso | Presentar los 3 módulos con sus lecciones | Exposición | Matriz de planificación |
| 3 min | Beneficios del curso | Relacionar beneficios con experiencia del grupo | Discusión grupal | Ejemplos |
| 2 min | Tipos de evaluación, instrumentos y momentos | Explicar 3 evaluaciones y aprobación 80 % | Exposición | Rúbrica en diapositiva |
| 3 min | Acuerdos y compromisos · Expectativas | Lluvia de ideas de expectativas | Lluvia de ideas | Pizarra, rotafolio |
| 2 min | Reglas de operación | Puntualidad, participación, respeto | Discusión grupal | Pizarra |
| 2 min | Contrato de Aprendizaje | Firmar compromisos simbólicos | Técnica grupal | Hoja de contrato |
| 5 min | Evaluación Diagnóstica | Aplicar cuestionario inicial | Cuestionario | Formulario impreso/digital |

**Duración total del Encuadre: 35 min**

---

### SECCIÓN 9 · DESARROLLO (tabla 5 col)

| Duración | Temas / Subtemas | Descripción de Actividades | Técnica | Material |
|---|---|---|---|---|
| 15 min | **Módulo I: {M1_titulo}**<br>– {M1_leccion1}<br>– {M1_leccion2}<br>– {M1_leccion3} | El instructor aplicará TÉCNICA EXPOSITIVA:<br>a) Presentar objetivo del tema<br>b) Introducir con analogía<br>c) Recuperar experiencia previa con 3 preguntas<br>d) Desarrollar contenido con ejemplos del sector<br>e) Usar ejemplos de {sector_grupo}<br>f) Realizar síntesis de puntos clave<br>g) Plantear 2 preguntas de verificación<br>h) Promover comentarios sobre aplicación real<br>i) Mencionar referencias del cuadernillo | TÉCNICA EXPOSITIVA dialogada | Pizarra, diapositivas, {caso_ancla}, hojas de bitácora |
| 22 min | **Módulo II: {M2_titulo}**<br>– {M2_leccion1}<br>– {M2_leccion2}<br>– {M2_leccion3}<br>– {M2_leccion4} | El instructor aplicará TÉCNICA DEMOSTRATIVA:<br>a) Presentar objetivo de la demostración<br>b) Introducir tema con verbo fuerte<br>c) Recuperar experiencia previa<br>d) Desarrollar cada componente del producto<br>e) Demostrar construcción paso a paso en vivo con caso {caso_ancla}<br>f) Resolver dudas sobre la demostración<br>g) Práctica individual (en parejas)<br>h) Retroalimentación con lista de cotejo<br>Aplicar EVALUACIÓN FORMATIVA al cierre | TÉCNICA DEMOSTRATIVA | Diapositivas, handouts, lista de cotejo, computadoras con acceso a {herramienta} |
| 3 min | **Técnica Energizante · "{nombre_energizante}"** | a) Todos de pie<br>b) El instructor lanza 3 temas al azar relacionados con {tema_del_curso}<br>c) Cada participante tiene 15 s para {micro_accion}<br>d) Destacar los más creativos | Energizante grupal | Lista de temas ejemplo |
| 15 min | **Módulo III: {M3_titulo}**<br>– {M3_leccion1}<br>– {M3_leccion2}<br>– {M3_leccion3} | El instructor aplicará TÉCNICA DIÁLOGO-DISCUSIÓN:<br>a) Mencionar tema a discutir<br>b) Dividir en subgrupos de 3–4<br>c) Establecer reglas: escucha activa, turnos, construir sobre ideas, argumentar<br>d) Abrir discusión con caso provocador<br>e) Propiciar compartir casos reales<br>f) Moderar sin tomar partido<br>g) Usar ejemplos de otros sectores<br>h) Subgrupos presentan conclusiones<br>i) Llegar a conclusión grupal | TÉCNICA DIÁLOGO-DISCUSIÓN | Pizarra, ficha de caso de análisis |
| 10 min | **Evaluación Sumativa / Final** | a) Indicar alcances e instrucciones<br>b) Indicar tiempo (10 min)<br>c) Aclarar dudas | Cuestionario + Proyecto | Formato de Evaluación Final |
| — | **RESUMEN DE TÉCNICAS APLICADAS** | TÉCNICA EXPOSITIVA: Módulo I<br>TÉCNICA DEMOSTRATIVA: Módulo II<br>TÉCNICA DIÁLOGO-DISCUSIÓN: Módulo III<br>EVALUACIÓN FORMATIVA: fin M-II<br>TÉCNICA ENERGIZANTE: "{nombre}"<br>EVALUACIÓN SUMATIVA: cierre del desarrollo | Integración de técnicas | — |

**Duración total del Desarrollo: 65 min**

---

### SECCIÓN 10 · CIERRE (tabla 5 col)

| Duración | Etapa del Cierre | Descripción de Actividades | Técnica | Material |
|---|---|---|---|---|
| 4 min | Conclusiones · Técnica "{nombre_cierre_grupal}" | a) Formar círculo al centro<br>b) Cada participante: "Esta semana voy a {compromiso} en mi {contexto}"<br>c) Anotar compromisos en pizarra / post-its<br>d) 30 s por persona<br>e) Destacar acción inmediata | Técnica grupal de cierre | Pizarra, post-its |
| 4 min | Resumen ejecutivo | Repaso de los 3 módulos | Exposición participativa | Diapositivas |
| 2 min | Logro de expectativas | Retomar "Mapa de Expectativas" y verificar | Discusión grupal | Lista de expectativas |
| 3 min | Logro de Objetivos | Autoevaluación 1–5 por objetivo | Autoevaluación | Lista de objetivos |
| 3 min | Sugerencias de continuidad de aprendizaje | Recomendar prácticas post-taller | Exposición | Material de apoyo, recursos |
| 2 min | Referencias Bibliográficas | Compartir lista de referencias | Exposición | Lista impresa |
| 2 min | Compromisos de aplicación | Anotar: 1 acción, 1 fecha, 1 persona con quien compartir | Técnica individual | Hoja de compromisos |
| 2 min | Evaluación de Satisfacción | Aplicar encuesta anónima | Encuesta | Formulario |
| 3 min | Cierre motivacional · entrega de constancias | Felicitación, constancias, foto grupal | Cierre | Constancias, cámara |

**Duración total del Cierre: 25 min**

---

### SECCIÓN 11 · DURACIÓN TOTAL

> **Duración Total del curso: 120 minutos (2 horas)**

---

## Metadata obligatoria del documento

- **Título del archivo:** `Documento_Planeacion_Curso_{slug}_EC0301_v{n}.docx`
- **Ubicación Drive:** carpeta del curso dentro de `Cursos iAprende`
- **Última actualización:** fecha del último merge
- **Versión:** semver simple (v1, v1.1, v2)
- **Estado de revisión EC0301:** [ ] Autorevisión · [ ] Revisado B Smarter · [ ] Aprobado

## Checklist E1023 antes de declarar listo

Ver checklist completo en [[../references/ec0301-criterios-evaluacion]]. Validar los 9 productos antes de entregar.

---

*Template generado por la skill. Rellenado automático por `agent-planeacion` en T6.*
