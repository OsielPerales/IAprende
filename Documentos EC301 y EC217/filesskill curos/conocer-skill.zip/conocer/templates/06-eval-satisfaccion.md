---
título: Template · Evaluación de Satisfacción
tipo: template
estandar: EC0301 (E1024 P5) + EC0217.01
artefacto: 6 de 12
tags: [template, satisfaccion, encuesta]
---

# Template · Evaluación de Satisfacción

Encuesta anónima aplicada al cierre del curso. Cubre las 4 secciones obligatorias de EC0301 E1024 Producto 5. Se aplica en 2–5 min.

**Doble uso:**
- **EC0301:** embebida como sección del Manual del Instructor.
- **EC0217.01:** exportada como documento suelto.

El contenido es idéntico en ambos casos. Cambia solo el envoltorio (portada propia para el documento suelto).

---

## Encabezado

```
EVALUACIÓN DE SATISFACCIÓN · {curso_nombre}

Instructor:  {instructor_nombre}
Lugar:       ____________________
Fecha:       ____________________

Esta encuesta es ANÓNIMA. No escribas tu nombre.
Tus respuestas se usan para mejorar futuras ediciones.
Tiempo:      3–5 minutos.
```

---

## Escala de estimación

```
Para cada afirmación, marca el número que mejor describe tu opinión:

  5 = Excelente    4 = Bueno    3 = Regular    2 = Deficiente    1 = Muy deficiente
```

---

## Sección A · Características del evento

| # | Afirmación | 5 | 4 | 3 | 2 | 1 |
|:-:|---|:-:|:-:|:-:|:-:|:-:|
| 1 | El curso comenzó y terminó en el horario anunciado | ☐ | ☐ | ☐ | ☐ | ☐ |
| 2 | El espacio / aula fue cómodo y adecuado | ☐ | ☐ | ☐ | ☐ | ☐ |
| 3 | El mobiliario (mesas, sillas) fue suficiente | ☐ | ☐ | ☐ | ☐ | ☐ |
| 4 | Los materiales se me entregaron a tiempo y completos | ☐ | ☐ | ☐ | ☐ | ☐ |

## Sección B · Contenido del curso

| # | Afirmación | 5 | 4 | 3 | 2 | 1 |
|:-:|---|:-:|:-:|:-:|:-:|:-:|
| 5 | El contenido es pertinente para mis necesidades reales | ☐ | ☐ | ☐ | ☐ | ☐ |
| 6 | La profundidad de los temas fue adecuada (ni superficial ni abrumadora) | ☐ | ☐ | ☐ | ☐ | ☐ |
| 7 | Los ejemplos usados fueron aplicables a mi contexto | ☐ | ☐ | ☐ | ☐ | ☐ |
| 8 | Aprendí algo que voy a aplicar esta semana | ☐ | ☐ | ☐ | ☐ | ☐ |

## Sección C · Materiales didácticos

| # | Afirmación | 5 | 4 | 3 | 2 | 1 |
|:-:|---|:-:|:-:|:-:|:-:|:-:|
| 9 | El Manual del Participante fue claro y útil | ☐ | ☐ | ☐ | ☐ | ☐ |
| 10 | Los ejercicios y hojas de trabajo me ayudaron a aprender | ☐ | ☐ | ☐ | ☐ | ☐ |
| 11 | Las diapositivas fueron visualmente claras | ☐ | ☐ | ☐ | ☐ | ☐ |
| 12 | Los recursos digitales / plataformas funcionaron sin problemas | ☐ | ☐ | ☐ | ☐ | ☐ |

## Sección D · Desempeño del instructor

| # | Afirmación | 5 | 4 | 3 | 2 | 1 |
|:-:|---|:-:|:-:|:-:|:-:|:-:|
| 13 | El instructor explicó con claridad | ☐ | ☐ | ☐ | ☐ | ☐ |
| 14 | El instructor manejó bien el tiempo | ☐ | ☐ | ☐ | ☐ | ☐ |
| 15 | El instructor respondió mis preguntas con apertura | ☐ | ☐ | ☐ | ☐ | ☐ |
| 16 | El instructor usó ejemplos relevantes para mi sector | ☐ | ☐ | ☐ | ☐ | ☐ |
| 17 | El instructor generó un ambiente de participación | ☐ | ☐ | ☐ | ☐ | ☐ |

---

## Comentarios libres (obligatorio por EC0301)

```
¿Qué fue lo MÁS VALIOSO del curso para ti?

______________________________________________________________________

______________________________________________________________________

¿Qué RECOMENDARÍAS MEJORAR para futuras ediciones?

______________________________________________________________________

______________________________________________________________________

¿Qué TEMA te gustaría PROFUNDIZAR en otro curso?

______________________________________________________________________

______________________________________________________________________

Otros comentarios:

______________________________________________________________________
```

---

## Cierre

```
Gracias por tu retroalimentación honesta.

— Desarrollos Elaborados · iAprende —
```

---

## Análisis · uso del instructor post-evento

Para el Informe Final (EC0217.01), el instructor calcula:

```
Promedios por sección:
  A · Evento:         ____ / 5
  B · Contenido:      ____ / 5
  C · Materiales:     ____ / 5
  D · Instructor:     ____ / 5
Promedio general:     ____ / 5

% de respuestas ≥4 (Bueno o Excelente): ____%

Temas más mencionados en comentarios libres:
  1.
  2.
  3.

Áreas claras de mejora:
  1.
  2.
```

---

## Metadata del documento

- **Título (embebido en Manual Instructor):** sección "Evaluación de Satisfacción"
- **Título (documento suelto EC0217.01):** `Evaluacion_Satisfaccion_{slug}.docx`
- **Se imprime:** 1 copia por participante
- **Entregable EC0217.01:** documento 6 de 7
- **Criterios EC0301 E1024 P5 cubiertos:**
  - [x] Espacio para nombre del curso
  - [x] Espacio para nombre del instructor
  - [x] Instrucciones generales de aplicación
  - [x] Escala de estimación del nivel de satisfacción
  - [x] Reactivos sobre características del evento
  - [x] Reactivos sobre contenido del curso
  - [x] Reactivos sobre materiales didácticos
  - [x] Reactivos sobre desempeño del instructor
  - [x] Espacios para comentarios

---

*Template generado por la skill. Rellenado por `agent-evaluaciones` (y también embebido por `agent-manual-instructor`).*
