---
título: Template · Evaluación Diagnóstica
tipo: template
estandar: EC0301 (E1024) + EC0217.01
artefacto: 3 de 12
tags: [template, evaluacion-diagnostica]
---

# Template · Evaluación Diagnóstica

Instrumento referencial aplicado al inicio del curso. 5 preguntas abiertas · 5 min · sin valor para calificación. Criterio EC0301 E1024 Producto 1.

---

## Encabezado (EC0301 criterio obligatorio)

```
EVALUACIÓN DIAGNÓSTICA

Nombre del curso:     {curso_nombre}
Instructor:           ____________________________
Lugar de Impartición: ____________________________
Duración del curso:   120 min · Horario: ______ · Fecha: _______
Nombre del Participante: ________________________________
```

---

## Instrucciones

```
Responde las siguientes preguntas con honestidad. No hay respuestas
correctas o incorrectas. Su propósito es conocer tu punto de partida
para ajustar el nivel del curso a las necesidades del grupo.

Condiciones:  Aplicación individual
Materiales:   Lápiz o pluma
Tiempo:       5:00 minutos
```

> **Nota importante:** Esta evaluación es solo referencial. No cuenta para tu calificación final. El instructor la utiliza para ajustar la profundidad del curso.

---

## Reactivos (5 preguntas abiertas · sin calificación)

Patrón canónico — ver [[../references/evaluaciones-y-rubricas]]. Adaptar al tema del curso.

| # | Pregunta | Respuesta |
|:-:|---|---|
| 1 | **¿Qué es {concepto_central_del_curso} para ti en este momento?** |  |
| 2 | **¿Has usado {herramienta_o_tecnica_del_curso}? ¿Con qué frecuencia?** |  |
| 3 | **¿Qué diferencia encuentras entre {alternativa_A} y {alternativa_B}?** |  |
| 4 | **¿Qué es «{termino_clave_del_curso}» para ti? Descríbelo con tus propias palabras.** |  |
| 5 | **Nombra al menos un caso de tu trabajo / vida donde crees que {objeto_del_curso} podría ayudarte.** |  |

---

## Guía de respuestas para el instructor (uso exclusivo)

```
Solo referencial. No se contabilizan las respuestas de forma correcta o incorrecta.

Valor: Referencial, sin peso para la aprobación del curso.

Indicaciones al instructor:
- Distribuir el formato junto con pluma/lápiz.
- Leer las instrucciones en voz alta.
- Aclarar dudas si las hay.
- Tomar tiempo (5 minutos).
- Al finalizar, recoger los formatos.
- Hojear rápidamente antes del Módulo I para ajustar el nivel.

Ajustes recomendados según el grupo:
- Si >70 % nunca ha usado {herramienta}: profundizar más en M-I conceptual.
- Si >70 % ya la ha usado: acelerar M-I y profundizar en M-II práctica.
- Si hay términos muy confusos en la P4: aclarar vocabulario antes de M-II.
```

---

## Campo para observaciones del instructor

```
Observaciones del grupo (patrón de respuestas detectado):

________________________________________________________________

________________________________________________________________

Ajustes aplicados al curso esta sesión:

________________________________________________________________

________________________________________________________________

Firma del instructor: ____________________   Fecha: __________
```

---

## Metadata del documento

- **Título:** `Evaluacion_Diagnostica_{slug}.docx`
- **Ubicación:** template dentro del paquete del curso; se imprime una copia por participante
- **Entregable EC0301:** documento 2 de 6 · **EC0217.01:** documento 3 de 7
- **Criterios EC0301 E1024 cubiertos:** P1 (instrumento) + P2 (instrucciones) + P3 (reactivos) + P4 (claves — N/A por ser referencial, la guía al instructor cumple el espíritu)

---

*Template generado por la skill. Rellenado por `agent-evaluaciones` en T6.*
