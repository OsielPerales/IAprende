---
título: Template · Lista de Verificación de Requerimientos
tipo: template
estandar: EC0217.01
artefacto: 2 de 12
tags: [template, lista-verificacion, ec0217]
---

# Template · Lista de Verificación de Requerimientos

Instrumento que el instructor aplica **20–30 minutos antes** del inicio del curso para garantizar que todos los recursos estén listos. Requerido por EC0217.01.

---

## Encabezado

```
LISTA DE VERIFICACIÓN DE REQUERIMIENTOS

Nombre del curso:         {curso_nombre}
Nombre del instructor:    {instructor_nombre}
Lugar de impartición:     {lugar}
Fecha:                    ____________
Hora de inicio del curso: ____________
Hora de verificación:     ____________ (debe ser 20–30 min antes)
Nombre del verificador:   ____________
```

---

## Lista de verificación (por categoría)

### A. Instalaciones y mobiliario

| # | Elemento | Sí | No | Observaciones |
|---|---|:-:|:-:|---|
| 1 | Sala disponible y abierta en la hora convenida | ☐ | ☐ |  |
| 2 | Iluminación adecuada y funcional | ☐ | ☐ |  |
| 3 | Temperatura / ventilación confortable | ☐ | ☐ |  |
| 4 | Mesas dispuestas para trabajo en equipos de 4–5 | ☐ | ☐ |  |
| 5 | Sillas suficientes para el número de participantes inscritos | ☐ | ☐ |  |
| 6 | Contactos eléctricos accesibles y funcionando | ☐ | ☐ |  |
| 7 | Acceso para personas con movilidad reducida | ☐ | ☐ |  |

### B. Equipo de apoyo

| # | Elemento | Sí | No | Observaciones |
|---|---|:-:|:-:|---|
| 8 | Proyector encendido y conectado | ☐ | ☐ |  |
| 9 | Pantalla o pared proyección visible para todos | ☐ | ☐ |  |
| 10 | Computadora del instructor funcionando | ☐ | ☐ |  |
| 11 | Cables HDMI / adaptadores presentes | ☐ | ☐ |  |
| 12 | Extensiones y regletas disponibles | ☐ | ☐ |  |
| 13 | Apuntador láser con batería | ☐ | ☐ |  |
| 14 | Bocinas conectadas y probadas | ☐ | ☐ |  |
| 15 | Internet estable (test de velocidad realizado) | ☐ | ☐ |  |

### C. Materiales didácticos

| # | Elemento | Cantidad requerida | Cantidad verificada | OK |
|---|---|---|---|:-:|
| 16 | Manual del Participante (copias impresas) | {n} | ____ | ☐ |
| 17 | Hoja de evaluación diagnóstica | {n} | ____ | ☐ |
| 18 | Hoja de evaluación formativa | {n} | ____ | ☐ |
| 19 | Hoja de evaluación sumativa | {n} | ____ | ☐ |
| 20 | Hoja de encuesta de satisfacción | {n} | ____ | ☐ |
| 21 | Lista de asistencia | 1 | ____ | ☐ |
| 22 | Hojas blancas | {n+5} | ____ | ☐ |
| 23 | Plumas / lapiceros | {n+2} | ____ | ☐ |
| 24 | Marcadores de pizarra | 3+ | ____ | ☐ |
| 25 | Post-its (varios colores) | 1 block | ____ | ☐ |
| 26 | Constancias firmadas listas para entrega | {n} | ____ | ☐ |

### D. Recursos específicos del curso

| # | Elemento | Sí | No | Observaciones |
|---|---|:-:|:-:|---|
| 27 | {recurso_especifico_1 — ej. acceso probado a ChatGPT/Gemini} | ☐ | ☐ |  |
| 28 | {recurso_especifico_2 — ej. cuenta Google compartida} | ☐ | ☐ |  |
| 29 | {recurso_especifico_3 — ej. tarjetas con casos impresas} | ☐ | ☐ |  |

### E. Salud, seguridad y protección civil

| # | Elemento | Sí | No | Observaciones |
|---|---|:-:|:-:|---|
| 30 | Botiquín de primeros auxilios accesible | ☐ | ☐ |  |
| 31 | Gel antibacterial disponible en entrada y mesas | ☐ | ☐ |  |
| 32 | Señalización de rutas de evacuación visible | ☐ | ☐ |  |
| 33 | Extintor visible y con vigencia | ☐ | ☐ |  |
| 34 | Salida de emergencia despejada | ☐ | ☐ |  |

---

## Resultado general

```
Elementos totales verificados: 34
Elementos en estado "Sí":      ____ / 34
Elementos en estado "No":      ____ / 34

Calificación de aptitud:
☐ APTO PARA INICIAR       (≥32 sí, y 0 "no" en categoría B equipo crítico)
☐ APTO CON OBSERVACIONES  (entre 28 y 31 sí)
☐ NO APTO                 (menos de 28 sí o falla crítica en B)
```

### Si hay elementos "No"

Listar acciones correctivas inmediatas:

```
Acción 1: __________________  Responsable: __________  Tiempo estimado: ____
Acción 2: __________________  Responsable: __________  Tiempo estimado: ____
Acción 3: __________________  Responsable: __________  Tiempo estimado: ____
```

---

## Firmas

```
Instructor / Verificador
Nombre: __________________________
Firma:  __________________________
Fecha:  ____________  Hora: ________

Coordinador de sede (si aplica)
Nombre: __________________________
Firma:  __________________________
```

---

## Metadata del documento

- **Título:** `Lista_Verificacion_Requerimientos_{slug}_{fecha}.docx`
- **Ubicación Drive:** carpeta del curso / subcarpeta "Impartición {fecha}"
- **Entregable EC0217.01:** documento 2 de 7
- **Se aplica:** una vez por impartición (no por curso diseñado)

---

*Template generado por la skill. Rellenado por `agent-planeacion` al producir el curso; el instructor solo marca las casillas el día de la impartición.*
