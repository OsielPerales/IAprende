---
título: Template · Storyboard de Slides (Markdown revisable)
tipo: template
artefacto: 11 de 12
tags: [template, storyboard, slides, markdown]
---

# Template · Storyboard de Slides

Documento Markdown que describe, slide por slide, el contenido de la presentación final. Se revisa y ajusta con el usuario **antes** de producir el .pptx (artefacto 12).

**Cantidad canónica:** 30–35 slides para un curso de 120 min.

---

## Reparto de slides por momento

| Momento | Slides | Rango |
|---|---|---|
| Preámbulo | 1 | 1 |
| Encuadre | 5 | 2–6 |
| Módulo I | 5–6 | 7–12 |
| Módulo II | 8–9 | 13–21 |
| Módulo III | 4–5 | 22–26 |
| Sumativa | 3–4 | 27–30 |
| Cierre | 3 | 31–33 |
| Créditos / Contactos | 1–2 | 34–35 |

---

## Convención de fichas por slide

Cada slide se documenta así:

```markdown
### SLIDE N — {Título visual del slide}

**Tipo:** {portada / sección / contenido / diagrama / tabla / cita / cierre}
**Layout:** {título-contenido / dos-columnas / imagen-completa / cita-grande}
**Duración en vivo:** {X min}
**Técnica del momento:** {Expositiva / Demostrativa / Diálogo-Discusión / etc.}

**Contenido visual:**
- Título: "{título visible}"
- Subtítulo: "{subtítulo}"
- Bullets / elementos:
  - {elemento 1}
  - {elemento 2}
  - {elemento 3}
- Imagen: {descripción o placeholder [img_X]}
- Cita destacada (si aplica): "{cita}"

**Notas del presentador (speaker notes):**
"{lo que el instructor debe decir cuando llega a este slide}"

**Transición:** {cómo se conecta con el slide siguiente}
```

---

## Esqueleto canónico

### SLIDE 1 — Preámbulo / Gancho

**Tipo:** cita-grande  
**Layout:** imagen-completa con overlay  
**Duración en vivo:** 5 min  
**Técnica:** Expositiva

**Contenido:**
- Frase gancho de una línea sobre el cambio de paradigma del dominio
- Logo iAprende en esquina
- Imagen de fondo: flat editorial relacionada con el dominio

**Notas presentador:** "{apertura emocional + frase filosófica}"

---

### SLIDE 2 — Bienvenida

**Tipo:** contenido  
**Layout:** título-contenido

**Contenido:**
- Título: "Bienvenido a {curso_nombre}"
- Subtítulo: "Lo que vas a construir hoy"
- Bullets: 3 entregables concretos
- Frase filosofía: "Skin in the Game — solo enseñamos lo que hemos probado."

---

### SLIDE 3 — Objetivo General

**Tipo:** cita-grande  
**Contenido:** El objetivo general en formato Mager completo, citado textual.

---

### SLIDE 4 — Mapa del Curso (infografía visual)

**Tipo:** diagrama  
**Layout:** imagen-completa

**Contenido:** diagrama radial con los 3 módulos + duración + técnica canónica de cada uno.

---

### SLIDE 5 — Expectativas (actividad)

**Tipo:** contenido  
**Técnica:** Rompe Hielo

**Contenido:** instrucciones del Mapa de Expectativas + tabla vacía.

---

### SLIDE 6 — Diagnóstica (indicación)

**Tipo:** contenido  
**Contenido:** "Vamos a tomar 5 minutos. Responde con honestidad. No cuenta para calificación."

---

### SLIDES 7–12 — Módulo I

- **7** · Portada del Módulo I (título + ícono)
- **8** · Concepto central del M-I (tipo contenido)
- **9** · Diagrama / comparador (tipo diagrama)
- **10** · Cita destacada de autoridad del dominio
- **11** · Actividad del módulo (Bitácora de Procesos o similar)
- **12** · Síntesis del M-I con 3 bullets

---

### SLIDES 13–21 — Módulo II

- **13** · Portada del Módulo II
- **14** · Componentes del producto (infografía con los 5 componentes)
- **15** · Componente 1 (contenido + ejemplo)
- **16** · Componente 2 (contenido + ejemplo)
- **17** · Componente 3 (contenido + ejemplo)
- **18** · Componente 4 (contenido + ejemplo)
- **19** · Componente 5 (contenido + ejemplo)
- **20** · Demo completa con caso ancla (screenshot + explicación)
- **21** · Formativa (indicación de actividad)

---

### SLIDES 22–26 — Módulo III

- **22** · Portada del Módulo III
- **23** · Problema / dilema central (contenido)
- **24** · Casos ejemplo para discusión (3 viñetas)
- **25** · Criterios de corrección / filtro humano (checklist visual)
- **26** · Conclusiones a consensuar (pregunta abierta)

---

### SLIDES 27–30 — Sumativa

- **27** · Portada Sumativa + instrucciones
- **28** · Parte I · Proyecto (descripción)
- **29** · Parte II · Teoría (3 preguntas)
- **30** · Parte III · Auto-auditoría ética

---

### SLIDES 31–33 — Cierre

- **31** · Conclusiones (técnica grupal)
- **32** · Lo que te llevas (resumen personalizado)
- **33** · 72 horas + ecosistema iAprende

---

### SLIDES 34–35 — Créditos y contacto

- **34** · Bibliografía (1 slide, formato compacto con ≥5 referencias)
- **35** · Contacto + agradecimiento + pie legal EC0301/B Smarter

---

## Reglas duras del storyboard

1. **Máximo 6 elementos por slide** (título + 5 bullets o equivalente).
2. **Nada de lorem ipsum:** todo el texto debe ser real y pulido.
3. **Notas del presentador siempre presentes** para todos los slides de contenido.
4. **Un slide = un concepto.** Si dos conceptos entran en un mismo slide, dividir.
5. **Transiciones entre slides** declaradas explícitamente (para que el instructor fluya).
6. **Timing acumulado** revisado: suma total de duraciones debe ≈ 120 min sin contar actividades.
7. **Branding:** paleta cobalt/orange/mint/lavender + Libre Baskerville/Inter en tipografía.

---

## Proceso de revisión antes de .pptx

Antes de invocar la skill `pptx`, el usuario debe:

1. Leer el storyboard completo.
2. Marcar slides que requieren ajuste con comentarios en el markdown.
3. Aprobar el storyboard firmando el final con un `✅ APROBADO POR <nombre> <fecha>`.

Solo con aprobación explícita el `agent-slides` procede a ejecutar la skill `pptx` (ver [[12-slides-pptx-brief]]).

---

## Metadata del documento

- **Título:** `Storyboard_Slides_{slug}.md`
- **Ubicación:** vault Obsidian en carpeta del curso
- **Revisable:** sí, antes de generar .pptx
- **Sucesor:** el .pptx final se genera con el brief `12-slides-pptx-brief.md`

---

*Template generado por la skill. Rellenado por `agent-slides` en T6 usando Manual Participante como input de contenidos.*
