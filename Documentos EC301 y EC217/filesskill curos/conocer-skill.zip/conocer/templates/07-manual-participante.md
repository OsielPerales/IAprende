---
título: Template · Manual del Participante
tipo: template
estandar: EC0301 (E1025 P1-P5)
artefacto: 7 de 12
tags: [template, manual-participante]
---

# Template · Manual del Participante

Documento entregado al participante. Sigue los 5 Productos de EC0301 E1025. Estructura de 18 secciones canónicas extraídas del caso modelo.

---

## Metadata del documento

- **Título del archivo:** `Manual_Participante_{slug}_EC0301.docx`
- **Formato:** `.docx` + versión `.md` en vault
- **Branding:** portada iAprende + Desarrollos Elaborados (ver [[../assets/branding/portadas-firmas]])
- **Pie legal interior:** "Curso diseñado bajo estándar CONOCER EC0301 · Certificación emitida a través del ECE B Smarter"

---

## Estructura del documento

### 1 · Portada

```
{logo_iAprende}

MANUAL DEL PARTICIPANTE

{curso_nombre}

Versión {version}

Diseñador Instruccional: Osiel Alejandro Perales Jiménez
Desarrollos Elaborados · iAprende
{fecha}
```

### 2 · Índice

Tabla de contenidos con página de cada sección (se genera automáticamente al exportar).

### 3 · Presentación del taller (EC0301 E1025 P2)

Tres subsecciones obligatorias:

**3.1 Bienvenida al participante**

> Párrafo de 4-6 líneas cálido, invitando a la apropiación del curso. Mencionar que NO es un curso teórico, que al terminar el participante saldrá con un producto real.

**3.2 Recomendaciones sobre la forma de utilizar el manual**

> Cómo leerlo: como apoyo durante el curso Y como referencia posterior. Los espacios en blanco son para tomar notas. Las evaluaciones impresas se desprenderán al final.

**3.3 Organización del manual**

> Resumen de las secciones principales: objetivos, evaluaciones, 3 módulos, bibliografía.

### 4 · Introducción (EC0301 E1025 P3)

Obligatorio 4 elementos:

- **Resumen de los temas:** qué se verá en cada módulo en 1-2 oraciones.
- **Beneficio que el curso aportará:** concreto, en lenguaje del participante.
- **Enfoque didáctico:** presencial + constructivista + Skin in the Game.
- **Congruencia con el objetivo de aprendizaje:** vincular al objetivo general.

### 5 · Beneficios del curso

Separar en:
- **Beneficios laborales** (3-5 viñetas)
- **Beneficios personales** (3-5 viñetas)

### 6 · Enfoque didáctico del curso

> Párrafo describiendo:
> - Modalidad (presencial en grupo)
> - 3 técnicas instruccionales empleadas (Expositiva, Demostrativa, Diálogo-Discusión)
> - 3 técnicas grupales (Rompe Hielo, Energizante, Cierre)
> - Metodología activa con construcción de producto real

### 7 · Objetivo General

Recuadro destacado con el objetivo en formato Mager. (Transcrito literal de la Planeación.)

### 8 · Objetivos Particulares

4 recuadros:
- Módulo I
- Módulo II  
- Módulo III
- Saber Convivir (transversal)

### 9 · Análisis de Expectativas y Compromisos

4 tablas llenables por el participante:

**Tabla A · Mis expectativas iniciales**

| Lo que espero aprender | Lo que creo que no podré resolver |
|---|---|
|  |  |

**Tabla B · Mis compromisos con el grupo**

| Lo que aporto | Lo que pido | Lo que me comprometo a hacer |
|---|---|---|
|  |  |  |

**Tabla C · Mi bitácora inicial · procesos que quiero automatizar/resolver**

| Proceso | Tiempo/semana | ¿Es repetitivo? | Candidato a {solucion_curso}? |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |

**Tabla D · Mis reglas de convivencia (se llena en grupo)**

(Espacios en blanco para que el grupo las complete durante el encuadre.)

### 10 · Momentos de Evaluación

Tabla con:

| Factor | Porcentaje | Instrumento | Momento |
|---|---|---|---|
| Diagnóstica | Referencial | Cuestionario 5 preg | Inicio |
| Formativa | 50 % | Guía de observación | Fin M-II |
| Sumativa | 50 % | Proyecto + Teoría + Auto-auditoría | Cierre desarrollo |

**Aprobatoria: 80 %.**

### 11 · Módulo I · {M1_titulo}

Estructura interna de cada módulo:

- **Objetivo del módulo** (transcrito literal de Planeación)
- **Imagen sugerida** (placeholder: `[imagen_modulo_I]`)
- **Lección 1.1 · {titulo_leccion}** — contenido desarrollado en 1-2 páginas
- **Lección 1.2** — idem
- **Lección 1.3** — idem
- **Lección 1.4 (opcional)** — idem
- **Actividad del módulo** — descripción de la Bitácora de Procesos u otra actividad
- **Ejemplo canónico** — aplicación del {caso_ancla} al tema del módulo
- **Síntesis del módulo** (párrafo de 3-5 líneas)
- **Pregunta de autoevaluación por tema** (1 pregunta abierta)

### 12 · Módulo II · {M2_titulo}

Misma estructura. Enfatiza:
- Demostración paso a paso de la construcción del producto
- Plantilla rellenable del producto
- Caso ancla aplicado
- Primera práctica individual

### 13 · Módulo III · {M3_titulo}

Misma estructura. Enfatiza:
- Caso o dilema ético del dominio
- Preguntas para discusión grupal
- Espacio para conclusión personal

### 14 · Evaluación Diagnóstica

Embebe el template `03-eval-diagnostica.md`.

### 15 · Evaluación Formativa

Embebe la **Parte A** del template `04-eval-formativa-guia-observacion.md`. (La Parte B del instructor va al Manual Instructor.)

### 16 · Evaluación Final / Sumativa

Embebe las **Partes I, II, III** del template `05-eval-sumativa-proyecto-rubrica.md`. (La rúbrica y claves van al Manual Instructor.)

### 17 · Bibliografía (EC0301 E1025 P5)

Formato APA. Mínimo 5 referencias con 6 datos obligatorios:

```
{Autor, A.} ({Año}). {Título de la obra}. {Editorial / URL}.
  {País de origen}.   [Consultado {fecha}]
```

Composición obligatoria:
- ≥1 referencia CONOCER / estándar oficial
- ≥2 referencias vivas (bibliografía actualizada de T4, <24 meses)
- ≥2 referencias clásicas del dominio

### 18 · Pie legal y créditos

```
Documento diseñado por Osiel Alejandro Perales Jiménez
Desarrollos Elaborados · iAprende · {año}

Curso diseñado bajo estándar CONOCER EC0301
Certificación emitida a través del Entidad de Certificación y Evaluación
(ECE) B Smarter.

Contacto: osiel.perales@desarrolloselaborados.com · WhatsApp 866-116-0704
iaprende-desarrollos.web.app
```

---

## Estilo editorial

- **Tipografía:** Titulares Libre Baskerville Bold · Cuerpo Inter · Datos técnicos JetBrains Mono
- **Colores:** Cobalt `#2A4B7C` titulares · Burnt Orange `#E07A5F` acentos · Mint `#D4E5DF` chips · Lavender `#E6E1F0` chips alt
- **Márgenes:** generosos (2.5 cm)
- **Interlineado:** 1.5
- **Sin imágenes fotorrealistas de personas** · solo ilustraciones flat editorial
- **Sin errores ortográficos** (criterio EC0301 literal)

---

## Checklist EC0301 E1025 antes de declarar listo

Todos los productos del Elemento 3 referentes al Manual del Participante en [[../references/ec0301-criterios-evaluacion]]:

- [ ] Producto 1 — 11 items del Manual Participante
- [ ] Producto 2 — 3 items de la Presentación
- [ ] Producto 3 — 4 items de la Introducción
- [ ] Producto 4 — 7 items del desarrollo de temas
- [ ] Producto 5 — 6 items de las fuentes de información

---

*Template generado por la skill. Rellenado por `agent-manual-participante` en T6 usando la Planeación ya firmada como input.*
