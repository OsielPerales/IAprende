---
título: Template · Informe Final · EC0217.01
tipo: template
estandar: EC0217.01
artefacto: 9 de 12
tags: [template, informe-final, ec0217]
---

# Template · Informe Final de Impartición

Documento post-evento que el instructor entrega como evidencia de impartición bajo EC0217.01. Se produce **después** de cada sesión (no con el diseño del curso), usando los datos recolectados durante la impartición.

---

## Encabezado

```
INFORME FINAL DE IMPARTICIÓN · EC0217.01

Curso:            {curso_nombre}
Versión:          {version}
Instructor:       {instructor_nombre}
Lugar:            {lugar}
Fecha:            {fecha}
Horario:          {horario}
Duración real:    {duracion_real} (programada: 120 min)
```

---

## Sección 1 · Datos del evento

| Campo | Valor |
|---|---|
| Nombre del curso | {curso_nombre} |
| Modalidad | Presencial grupal |
| Sede | {sede} |
| Cliente / Institución (si aplica) | {cliente} |
| Tipo de grupo | {tipo_grupo — ej. abierto / in-company} |
| Certificación | EC0301 (diseño) + EC0217.01 (impartición) vía B Smarter |

---

## Sección 2 · Asistencia

| Campo | Valor |
|---|---|
| Participantes inscritos | {n_inscritos} |
| Participantes asistentes | {n_asistentes} |
| % asistencia | {pct_asistencia} % |
| Razones declaradas de inasistencias | {razones} |

Lista de asistencia firmada se anexa al informe.

---

## Sección 3 · Resultados de evaluaciones

### 3.1 Evaluación Diagnóstica (referencial)

| Métrica | Valor |
|---|---|
| Participantes que respondieron | {n} / {total} |
| Nivel inicial estimado | {bajo / medio / alto} |
| Ajustes aplicados al curso con base en diagnóstico | {lista_ajustes} |

### 3.2 Evaluación Formativa (50 %)

| Métrica | Valor |
|---|---|
| Promedio grupo | {promedio} / 60 pts |
| Promedio convertido | {pct} % |
| % con retroalimentación inmediata aplicada | {pct_rf} % |
| Participantes con calificación < 50 (refuerzo) | {n} |

### 3.3 Evaluación Sumativa (50 %)

| Métrica | Valor |
|---|---|
| Promedio grupo | {promedio} / 23 pts |
| Promedio convertido | {pct} % |
| Calificación final promedio del grupo (Form + Sum) | {pct_final} % |
| % de aprobados (≥80 %) | {pct_aprobados} % |
| Dominio Avanzado (18-20 pts) | {n} participantes |
| Competente (14-17 pts) | {n} participantes |
| Requiere refuerzo (<14 pts) | {n} participantes |

### 3.4 Evaluación de Satisfacción

| Sección | Promedio (1-5) |
|---|---|
| A · Evento | {prom_a} |
| B · Contenido | {prom_b} |
| C · Materiales | {prom_c} |
| D · Instructor | {prom_d} |
| **General** | **{prom_general}** |

% de respuestas ≥4 (Bueno o Excelente): {pct_altas} %

---

## Sección 4 · Observaciones del Instructor

### 4.1 Momentos que funcionaron bien

- Momento 1: {descripcion}
- Momento 2: {descripcion}
- Momento 3: {descripcion}

### 4.2 Momentos que requieren ajuste

- Momento 1: {descripcion} → Ajuste propuesto: {ajuste}
- Momento 2: {descripcion} → Ajuste propuesto: {ajuste}

### 4.3 Dudas recurrentes del grupo

- Duda 1: {descripcion} → Cómo se abordó: {respuesta_del_instructor}
- Duda 2: {descripcion}

### 4.4 Sugerencias para próximas ediciones

- Sugerencia 1: {descripcion}
- Sugerencia 2: {descripcion}

### 4.5 Comentarios libres destacados de participantes

**Lo más valioso (top 3 menciones):**
1. {mencion_1}
2. {mencion_2}
3. {mencion_3}

**Recomendaciones de mejora (top 3 menciones):**
1. {recomendacion_1}
2. {recomendacion_2}
3. {recomendacion_3}

**Temas solicitados para profundizar (top 3):**
1. {tema_1}
2. {tema_2}
3. {tema_3}

---

## Sección 5 · Decisiones post-evento

- [ ] Actualizar el Manual del Participante v{n+1} con los ajustes identificados
- [ ] Actualizar la Planeación v{n+1} si hay cambios estructurales
- [ ] Generar piezas de marketing con los testimonios más fuertes (con permiso)
- [ ] Solicitar testimonios grabados a los 2-3 participantes más enganchados
- [ ] Pre-inscribir al grupo en el curso siguiente del ecosistema iAprende
- [ ] Enviar WhatsApp de seguimiento a las 72 h (validar compromisos)

---

## Sección 6 · Anexos

- Anexo A — Lista de asistencia firmada (escaneada)
- Anexo B — Evaluaciones físicas aplicadas (diag + form + sum), en carpeta Drive
- Anexo C — Encuestas de satisfacción (todas, anónimas), en carpeta Drive
- Anexo D — Fotografías del evento (opcional)
- Anexo E — Constancias entregadas (en carpeta Drive)

---

## Sección 7 · Firmas

```
Instructor
Nombre: Osiel Alejandro Perales Jiménez
Firma:  __________________________________
Fecha:  __________

Coordinador Académico / ECE (si aplica)
Nombre: Iván Téllez López · B Smarter
Firma:  __________________________________
Fecha:  __________
```

---

## Metadata del documento

- **Título:** `Informe_Final_{slug}_{fecha}.docx`
- **Ubicación:** Drive > carpeta del curso > subcarpeta "Impartición {fecha}"
- **Se genera:** una vez por impartición
- **Entregable EC0217.01:** documento 7 de 7
- **Plazo de entrega:** 48 horas post-evento

---

*Template generado por la skill. Rellenado por `agent-planeacion` al producir el curso (estructura vacía); el instructor lo llena después de cada sesión.*
