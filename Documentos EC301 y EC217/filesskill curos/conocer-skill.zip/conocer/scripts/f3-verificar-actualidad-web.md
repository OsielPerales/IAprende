---
fase: 3
turno_del_flujo: T4
actor: Claude + web_search
output: bibliografía viva (≥3 fuentes citables) + notas de actualización temática
---

# Fase 3 · Verificación de actualidad en línea

**Activación:** estructura aprobada en T3. Toca verificar que el contenido propuesto sigue siendo vigente y encontrar fuentes citables recientes.

---

## Objetivo

Para cada uno de los 3 temas del curso, producir:

1. **Nota de vigencia** — ¿el tema sigue siendo relevante tal como está redactado en la propuesta? ¿Cambió algo en los últimos 6–12 meses?
2. **2 fuentes citables por tema** (mínimo 6 total, objetivo 8–10) — publicadas en los últimos 24 meses.
3. **Mínimo 1 fuente oficial** (gobierno, CONOCER, OCDE, UNESCO, institución académica) por curso.
4. **1 referencia obligatoria al estándar EC0301** del DOF o portal CONOCER.

---

## Protocolo de búsqueda por tema

Por cada tema, ejecutar:

```
web_search: "{tema}" {año actual}
web_search: "{tema}" últimas investigaciones
web_search: "{tema}" aplicación industrial México
```

Si el tema es técnico (IA, automatización, etc.), también:

```
web_search: "{tema}" paper arxiv
web_search: "{tema}" state of the art
```

### Criterios para aceptar una fuente

- Publicada en los últimos 24 meses (excepción: texto canónico del campo)
- Autor identificable
- Editorial, revista o institución identificable
- URL accesible públicamente (evitar paywalls estrictos)
- **Rechazar fuentes de baja calidad:** blogs de marketing sin autor, agregadores de contenido, sitios .info sin acreditación

---

## Formato de entrega al usuario (chat, T4)

```
## Verificación de actualidad · {curso}

**Estado de vigencia de los 3 temas:**

- Tema 1 · {TÍTULO}: {vigente / actualizar / cambio mayor}
  {nota breve sobre qué cambió, si cambió}
- Tema 2 · {TÍTULO}: {vigente / actualizar / cambio mayor}
- Tema 3 · {TÍTULO}: {vigente / actualizar / cambio mayor}

---

**Bibliografía viva propuesta (8–10 fuentes):**

1. Apellido, N. ({año}). {Título}. {Editorial/Revista}. {URL}. {País}.
   — Uso: {Manual Participante / Manual Instructor / slide de cierre}
2. …

---

**Fuentes oficiales obligatorias:**
- CONOCER ({año}). EC0301: Diseño de cursos de formación del capital humano.
  D.O.F. / https://conocer.gob.mx/. México.
- {otra oficial}

---

**Artículos de interés detectados que podrías considerar agregar como lectura adicional en el Manual del Participante:**
- …
```

---

## Reglas duras

- **Nunca inventar referencias.** Si web_search no devuelve resultados confiables, decirlo: *"No encontré fuentes de calidad publicadas en los últimos 24 meses para {tema}. Propongo usar {texto canónico del campo, aunque sea más viejo} + reconocer explícitamente al usuario que el campo no ha tenido publicaciones recientes."*
- **Quotation ≤ 15 palabras** por fuente. Preferir paráfrasis.
- **1 cita por fuente** como máximo en toda la producción posterior.
- **Respetar copyright** — no reproducir párrafos, solo extraer datos factuales.

---

## Handoff a f4

Una vez entregada la bibliografía al usuario, pasar a `scripts/f4-generar-objetivos-mager.md` SOLO tras confirmación explícita del usuario (*"aprobada la bibliografía"* o equivalente).

Si el usuario pide cambiar fuentes, iterar en este turno sin avanzar.
