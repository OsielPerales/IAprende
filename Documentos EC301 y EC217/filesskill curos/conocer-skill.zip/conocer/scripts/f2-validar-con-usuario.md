---
título: Script Fase 2 · Validar con Usuario
fase: T3
tipo: prompt_interno
tags: [script, fase2, validacion, ask_user_input]
---

# Script T3 · Validar con Usuario

Turno de interacción: Claude NO continúa sin aprobación o ajuste explícito.

---

## Herramienta a usar

`ask_user_input_v0` — máximo 3 preguntas, opciones cortas.

---

## Preguntas canónicas (hasta 3, elegir las relevantes)

### Pregunta 1 — Estructura general

```json
{
  "question": "¿La estructura de 3 módulos propuesta te funciona?",
  "options": [
    "Sí, procede",
    "Sí pero quiero ajustar el orden",
    "No, proponeme otra",
    "Quiero que Módulo X cubra algo distinto"
  ]
}
```

### Pregunta 2 — Caso ancla

```json
{
  "question": "¿Qué caso ancla prefieres?",
  "options": [
    "Opción A — {caso_A}",
    "Opción B — {caso_B}",
    "Otro (lo escribo en texto libre)"
  ]
}
```

### Pregunta 3 — Nivel técnico del grupo objetivo

```json
{
  "question": "¿Nivel del grupo al que va dirigido el curso?",
  "options": [
    "Principiantes absolutos (cero experiencia en el dominio)",
    "Usuarios casuales (han escuchado del tema pero no lo dominan)",
    "Profesionales con experiencia previa",
    "Mixto (4–12 personas de varios niveles)"
  ]
}
```

---

## Interpretación de respuestas

### Si responde "Sí, procede" a estructura

Pasar directo a T4 con la propuesta tal cual.

### Si responde "Sí pero quiero ajustar"

Preguntar específicamente qué ajuste y aplicar. No regenerar todo — solo la parte afectada.

### Si responde "No, proponeme otra"

Volver a T2 con reasignación diferente de los 3 temas a los 3 módulos. No preguntar otra vez input base, solo re-proponer.

### Caso ancla = "Otro"

Tomar el caso custom del usuario. Verificar que el caso:
- Tenga una persona protagonista concreta (no abstracta)
- Tenga una situación problemática reconocible
- Pueda conectarse con los 3 módulos

Si el caso custom no cumple, sugerir ajuste. No rechazar.

### Nivel "Mixto"

En el Manual Instructor incluir notas de diferenciación: cómo atender a los principiantes sin aburrir a los avanzados.

---

## Lo que NO se pregunta en T3

Estas cosas se mantienen fijas y la skill no las negocia:

- Duración (120 min)
- Distribución 35/65/25
- Peso de evaluaciones (Form 50 % + Sum 50 %)
- Aprobatoria 80 %
- Técnicas instruccionales canónicas por módulo
- Objetivo transversal Saber Convivir
- Estructura de los manuales
- Obligatoriedad de Hoja iAprende

Si el usuario pide cambiar alguna de estas, responder que está fuera del alcance de esta versión de la skill y ofrecer documento pre-formato para revisión fuera de flujo.

---

## Transición a T4

Una vez el usuario aprueba estructura + caso + nivel:

```
Claude responde:
"Perfecto. Estructura aprobada con:
- Caso ancla: {caso_elegido}
- Nivel: {nivel_elegido}
- Estructura modular: {resumen}

Ahora voy a verificar online actualizaciones de los temas y buscar
referencias vivas para la bibliografía. Esto toma unos segundos."

[Ejecutar scripts/f3-verificar-actualidad-web.md]
```

---

*Script ejecutado tras `f1-proponer-estructura.md`.*
