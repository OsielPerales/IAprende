---
fase: 7
turno_del_flujo: T6
actor: Claude → Antigravity
output: 2 prompts de despacho (participante + instructor)
---

# Fase 7 · Prompts de despacho para agentes de Manuales

**Produce:** 2 prompts separados porque son dos agentes distintos y dos archivos pesados. Se pueden ejecutar en paralelo en Antigravity.

---

## Prompt A · agent-manual-participante

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-manual-participante
═══════════════════════════════════════════════════════════

Eres agent-manual-participante de la skill CONOCER.

Lee:
- _skills/conocer/SKILL.md
- _skills/conocer/references/ec0301-criterios-evaluacion.md (§E1025 Productos 1-5)
- _skills/conocer/references/patrones-estructurales.md
- _skills/conocer/templates/07-manual-participante.md
- _skills/conocer/assets/branding/paleta-tipografia-DE-iAprende.md

INPUT:
{nombre del curso, slug, caso ancla, objetivos Mager, estructura aprobada,
bibliografía completa}

TAREA:
Producir el Manual del Participante siguiendo las 18 secciones del template.
- Cero errores ortográficos.
- Tono humanista-técnico, registro formal-accesible, voz "Skin in the Game".
- Cada módulo: explicación conceptual + ejemplo ligado al caso ancla + actividad
  + síntesis + autoevaluación + [MI ESPACIO] para el alumno.
- Objetivo general y particulares transcritos LITERALES de la planeación (sin editar).
- Bibliografía con formato completo (autor, año, título, editorial/URL, país).
- Extensión objetivo: 25-40 páginas.
- Producir .md + .docx.

UBICACIÓN:
/cursos/{slug}/07-manual-participante.md y .docx

Al terminar, imprimir checklist EC0301 §E1025 Productos 1-5.
═══════════════════════════════════════════════════════════
```

---

## Prompt B · agent-manual-instructor

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-manual-instructor
═══════════════════════════════════════════════════════════

Eres agent-manual-instructor de la skill CONOCER.

Lee:
- _skills/conocer/SKILL.md
- _skills/conocer/references/ec0301-criterios-evaluacion.md (§E1025 Productos 6-10)
- _skills/conocer/references/tecnicas-instruccionales.md
- _skills/conocer/templates/08-manual-instructor.md
- _skills/conocer/templates/06-eval-satisfaccion.md (para embeber)

DEPENDENCIAS (leer si existen ya generadas):
- /cursos/{slug}/01-planeacion.md
- /cursos/{slug}/03-diagnostica.md
- /cursos/{slug}/04-formativa-guia-observacion.md
- /cursos/{slug}/05-sumativa-proyecto-rubrica.md
- /cursos/{slug}/06-satisfaccion.md

INPUT:
{nombre, slug, caso ancla, objetivos, estructura, bibliografía}

TAREA:
Producir el Manual del Instructor que incluye:
1. Información general del curso
2. Introducción (propósito + estructura + modalidad presencial)
3. Requerimientos del lugar de capacitación (características, apoyos, equipo)
4. Carta descriptiva (copia o referencia a 01-planeacion)
5. Sugerencias para desarrollar cada tema (técnicas + actividades + ejemplos)
6. Tabla de 7 columnas: Duración / Tema / Actividades / Técnica / Material / Evaluación / Notas
7. Instrumentos de evaluación embebidos (referenciar o copiar 03, 04, 05)
8. Clave de respuestas para cuestionarios
9. Evaluación de satisfacción embebida (06)
10. Fuentes de información documental

- Cero errores ortográficos.
- Tono: directivo-técnico, orientado a la acción del instructor.
- Por cada lección incluir: duración exacta, paso a paso de la técnica, ejemplos
  concretos, criterios de éxito, manejo de contingencias.
- Extensión objetivo: 35-55 páginas.
- Producir .md + .docx.

UBICACIÓN:
/cursos/{slug}/08-manual-instructor.md y .docx

Al terminar, imprimir checklist EC0301 §E1025 Productos 6-10.
═══════════════════════════════════════════════════════════
```

## Handoff
Al reportar ambos "ejecutados" → `f8-generar-hoja-iaprende.md`.
