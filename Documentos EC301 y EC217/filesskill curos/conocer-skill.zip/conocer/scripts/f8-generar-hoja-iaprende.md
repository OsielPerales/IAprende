---
fase: 8
turno_del_flujo: T6
actor: Claude → Antigravity
output: prompt de despacho para agent-iaprende-bloques
---

# Fase 8 · Prompt de despacho para agente iAprende

**Produce:** documento de 35-40 bloques mapeados al schema Firestore de iAprende + lista de componentes React a crear/reutilizar.

---

## Prompt de despacho

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-iaprende-bloques
═══════════════════════════════════════════════════════════

Eres agent-iaprende-bloques de la skill CONOCER.

Lee:
- _skills/conocer/SKILL.md
- _skills/conocer/references/firestore-iaprende-schema.md
- _skills/conocer/templates/10-hoja-adaptacion-iaprende.md
- _skills/conocer/assets/ejemplos-apuntadores/curso-modelo-ia-estrategica.md

DEPENDENCIAS:
- /cursos/{slug}/07-manual-participante.md (contenido base para transcribir a bloques)
- /cursos/{slug}/08-manual-instructor.md (actividades e interactivos)

INPUT:
{nombre, slug, estructura con lecciones, tipos de bloque propuestos por lección}

TAREA:
Producir la "Hoja de Adaptación iAprende" con:

1. Encabezado con metadata del curso y proyecto Firebase
   (iAprende, iaprende-1415d, stack React+TS+Vite+Firebase)

2. Arquitectura de almacenamiento:
   - Documento en cursos/c-{slug}/
   - Bloques en bloques/{bloque_id}/ con curso_id de relación
   - progreso_alumno/ con los campos específicos de este curso
     (bitacora, rol_construido, prompt_maestro, auditoria_etica, etc.)

3. 35-40 bloques siguiendo convención de IDs:
   - P.1, P.2 (preámbulo si aplica)
   - E.1 a E.5 (encuadre)
   - M1.0 (portada) + M1.1 a M1.N (contenido Módulo I)
   - M2.0 + M2.1 a M2.N (contenido Módulo II)
   - M3.0 + M3.1 a M3.N (contenido Módulo III)
   - S.0 + S.1 a S.3 (sumativa: portada, proyecto, teoría, auto-auditoría)
   - C.1, C.2, C.3 (cierre: resumen personal, 72h, ecosistema)

   Cada bloque especifica:
     FUENTE, MÓDULO, ORDEN, TIPO (14 tipos disponibles), DURACIÓN, ESTADO [ ]
     CONTENIDO detallado a implementar
     INTERACTIVO (si aplica)
     ALMACENAMIENTO (path Firestore)

4. Tabla resumen de los 35-40 bloques (una fila por bloque: ID, tipo, fuente, estado).

5. Componentes React necesarios:
   - Marcar cuáles ya existen
   - Marcar cuáles son nuevos
   - Para los nuevos, especificar props y comportamiento

6. Assets estáticos necesarios (infografías SVG, íconos, imágenes recicladas de slides).

Extensión objetivo: 1000-1500 líneas de markdown.
Producir .md únicamente (no .docx — este archivo vive en el vault y en el repo
de iAprende).

UBICACIÓN:
/cursos/{slug}/VERIFICACION_CURSO_{SLUG_UPPER}_v1.md
(también copiar a vault en _skills/conocer/assets/ejemplos/{slug}/ para referencia)

Al terminar, imprimir tabla resumen de los 35-40 bloques con estado [ ] pendiente.
═══════════════════════════════════════════════════════════
```

## Handoff
Al reportar "ejecutado" → `f9-generar-slides.md`.
