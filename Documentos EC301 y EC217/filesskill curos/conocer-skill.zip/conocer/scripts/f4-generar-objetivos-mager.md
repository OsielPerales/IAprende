---
fase: 4
turno_del_flujo: T5 (primera parte)
actor: Claude
output: 1 objetivo general + 4 objetivos particulares en forma Mager completa
---

# Fase 4 · Generación de objetivos Mager completos

**Activación:** bibliografía aprobada en T4. Ahora refinamos los objetivos draft de T2 a forma Mager completa.

---

## Referencias obligatorias

- `references/redaccion-objetivos-mager.md` — patrón Sujeto + Acción + Condición + Límite.
- `references/ec0301-criterios-evaluacion.md` — criterios literales que el objetivo debe cumplir.

---

## Fórmula canónica

Cada objetivo debe contener los 4 componentes:

| Componente | Pregunta | Ejemplo |
|---|---|---|
| Sujeto | ¿Quién aprende? | El participante |
| Acción/Comportamiento | ¿Qué hace? (verbo fuerte Bloom) | aprenderá a diseñar, construirá, comparará |
| Condición de operación | ¿Cómo / dónde / con qué? | mediante la Estructura Maestra; en un taller práctico; con herramientas accesibles |
| Límite | ¿Cuándo / con qué calidad / hasta qué criterio? | al término del curso; con ≥80 % de aprobación; aplicable a su propia operación |

---

## Plantillas

### Objetivo general (1, siempre en 3ª persona singular)

```
El participante {ACCIÓN} {OBJETO DE APRENDIZAJE} aplicando {MARCO/MÉTODO},
para {BENEFICIO / PROPÓSITO}, al término del curso con un mínimo del 80 %
de aprobación.
```

Ejemplo del caso modelo:

> El participante aprenderá a diseñar y aplicar prompts estratégicos utilizando la
> Estructura Maestra (Rol, Contexto, Instrucción, Restricciones, Formato) para
> automatizar procesos personales y empresariales, al término del curso con un
> mínimo del 80 % de aprobación.

### Objetivo particular por módulo (3 obligatorios, uno por módulo)

```
El participante {ACCIÓN del verbo fuerte del dominio} {OBJETO} mediante
{TÉCNICA/MÉTODO del módulo}, para {APLICACIÓN CONCRETA}, en {DURACIÓN del
módulo} con {CRITERIO DE DESEMPEÑO}.
```

### Objetivo de Saber Convivir (4º, transversal)

```
El participante atenderá a los puntos de vista y experiencias expresados
por sus compañeros permitiendo la libre participación y expresión, a lo
largo del curso, para fomentar un ambiente de aprendizaje óptimo.
```

Este objetivo es **obligatorio** por EC0301 y siempre tiene la misma plantilla (adaptable solo en verbos de acción).

---

## Verbos Bloom recomendados (dominio cognitivo)

| Nivel | Verbos fuertes |
|---|---|
| Conocer | identificar, enumerar, definir, nombrar |
| Comprender | explicar, clasificar, distinguir, contrastar |
| Aplicar | aplicar, usar, ejecutar, implementar |
| Analizar | analizar, desglosar, comparar, diferenciar |
| Evaluar | evaluar, criticar, justificar, verificar |
| Crear | diseñar, construir, componer, formular |

**Prohibidos** (verbos débiles): conocer, saber, aprender, entender, familiarizarse, sensibilizarse. En su lugar usar los verbos de la tabla.

---

## Coherencia obligatoria

Cada objetivo particular debe:
- Corresponder con un tema/módulo de la estructura aprobada
- Ser medible con un instrumento de evaluación (no se puede evaluar "entender")
- Respetar los requisitos de ingreso del perfil del participante (no exigir lo que el grupo no trae)
- Ser coherente con el tiempo real del módulo (no prometer dominio avanzado en 15 min)

---

## Formato de entrega al usuario

```
## Objetivos Mager · {curso}

### Objetivo general
{REDACCIÓN COMPLETA}

### Objetivos particulares
1. **Módulo I · {tema}:** {redacción completa}
2. **Módulo II · {tema}:** {redacción completa}
3. **Módulo III · {tema}:** {redacción completa}
4. **Saber Convivir (transversal):** {redacción}

### Alineación objetivo ↔ evaluación
| Objetivo | Instrumento que lo mide |
|---|---|
| OG | Proyecto sumativo + Teoría + Auto-auditoría |
| OP1 | Evaluación diagnóstica + participación M-I |
| OP2 | Guía de observación formativa |
| OP3 | Caso ético + discusión grupal |
| SC  | Observación continua (Manual Instructor) |
```

---

## Handoff a f5

Este output alimenta directamente:
- `templates/01-planeacion-carta-descriptiva.md` (columnas de objetivos)
- `templates/07-manual-participante.md` (sección 6 y 7)
- `templates/08-manual-instructor.md` (sección "Objetivos")

Pasar a `f5-generar-planeacion.md`.
