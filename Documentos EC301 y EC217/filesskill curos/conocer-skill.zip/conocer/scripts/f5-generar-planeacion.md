---
fase: 5
turno_del_flujo: T6 (prompt de despacho)
actor: Claude → Antigravity / Claude Code
output: prompt listo para ejecutar agent-planeacion localmente
---

# Fase 5 · Prompt de despacho para agente Planeación

**Activación:** objetivos Mager aprobados. Toca empaquetar un prompt que el usuario ejecutará en Antigravity para producir los 3 artefactos que el agente Planeación cubre: Planeación + Lista verificación + Informe final (blank).

---

## Qué produce este turno

**No se escribe la planeación aquí.** Claude emite un **prompt de despacho** que el usuario copia/pega en Antigravity o Claude Code y que allá genera los 3 archivos .docx + .md.

---

## Formato del prompt de despacho

Claude responde al usuario con un bloque de código listo para copiar:

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-planeacion
Para ejecutar en Antigravity o Claude Code
═══════════════════════════════════════════════════════════

Eres el agente agent-planeacion de la skill CONOCER de Desarrollos Elaborados.

Lee primero estos archivos de tu vault Obsidian:
- _skills/conocer/SKILL.md
- _skills/conocer/references/ec0301-criterios-evaluacion.md
- _skills/conocer/references/ec0217-criterios-evaluacion.md
- _skills/conocer/references/tiempos-canonicos-120min.md
- _skills/conocer/references/tecnicas-instruccionales.md
- _skills/conocer/templates/01-planeacion-carta-descriptiva.md
- _skills/conocer/templates/02-lista-verificacion-requerimientos.md
- _skills/conocer/templates/09-informe-final-ec0217.md
- _skills/conocer/assets/branding/paleta-tipografia-DE-iAprende.md
- _skills/conocer/assets/branding/pie-legal-creditos.md

INPUT DEL CURSO:
Nombre: {NOMBRE}
Slug: {slug-url}
Caso ancla: {CASO}
Nivel del grupo: {NIVEL}
Sector(es): {SECTORES}
Duración: 120 min
Modalidad: presencial grupal, 4 a 12 participantes

OBJETIVOS MAGER COMPLETOS:
- Objetivo general: {TEXTO}
- Objetivo particular 1 (M-I): {TEXTO}
- Objetivo particular 2 (M-II): {TEXTO}
- Objetivo particular 3 (M-III): {TEXTO}
- Saber Convivir: {TEXTO}

ESTRUCTURA APROBADA:
{MÓDULOS + LECCIONES + TIPOS DE BLOQUE iAprende}

BIBLIOGRAFÍA APROBADA:
{8–10 REFERENCIAS APA COMPLETAS}

TAREA:
1. Llenar templates/01-planeacion-carta-descriptiva.md con todo el contenido real.
   Aplicar reparto de tiempos canónico (35/65/25).
   Las 3 técnicas instruccionales + 3 grupales en sus momentos correctos.
   Producir el archivo en dos formatos: .md y .docx.
2. Llenar templates/02-lista-verificacion-requerimientos.md con los 34 items
   adaptados al curso. Producir .md + .docx.
3. Generar una versión en blanco de templates/09-informe-final-ec0217.md con
   los datos generales pre-llenados (nombre, instructor, curso) y el resto en
   blanco listo para llenar post-impartición. Producir .md + .docx.

Ubicar archivos en:
/cursos/{slug}/
  ├── 01-planeacion.md y .docx
  ├── 02-lista-verificacion.md y .docx
  └── 09-informe-final-blank.md y .docx

Aplicar branding: paleta cobalt/orange/mint/lavender, Libre Baskerville para
titulares, Inter para cuerpo, pie legal "Certificado EC0301 vía B Smarter".

Al terminar, imprimir el checklist EC0301 §E1023 marcando cada criterio
cumplido. Si algún criterio no se cumple, detenerse y reportarlo.

═══════════════════════════════════════════════════════════
```

---

## Reglas duras

- **No modificar nombres de templates ni referencias.** El agente debe encontrarlos exactamente como están.
- **Incluir checklist de verificación** — el agente debe auto-validarse.
- **Dos formatos (.md + .docx)** — .md queda en el vault, .docx va a Drive del cliente.
- **Slug URL-safe** (sin acentos, espacios → guiones): ejemplo `ia-estrategica-v2`.

---

## Handoff

El usuario ejecuta el prompt en Antigravity. Cuando reporte "agente ejecutado", Claude pasa a `f6-generar-evaluaciones.md`.
