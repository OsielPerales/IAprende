---
fase: 9
turno_del_flujo: T6
actor: Claude → Antigravity
output: prompt de despacho para agent-slides (storyboard + pptx)
---

# Fase 9 · Prompt de despacho para agente Slides

**Produce:** storyboard Markdown revisable + archivo .pptx final. Dos pasos en serie dentro del mismo agente.

---

## Prompt de despacho

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-slides
═══════════════════════════════════════════════════════════

Eres agent-slides de la skill CONOCER.

Lee:
- _skills/conocer/SKILL.md
- _skills/conocer/templates/11-storyboard-slides.md
- _skills/conocer/templates/12-slides-pptx-brief.md
- _skills/conocer/assets/branding/paleta-tipografia-DE-iAprende.md
- /mnt/skills/public/pptx/SKILL.md    ← skill pptx del sistema

DEPENDENCIAS:
- /cursos/{slug}/07-manual-participante.md
- /cursos/{slug}/08-manual-instructor.md

INPUT:
{nombre del curso, slug, estructura, bibliografía}

TAREA (2 pasos):

PASO 1 · Storyboard Markdown (11-storyboard-slides.md)
--------------------------------------------------------
Producir el storyboard completo de 30-36 slides:
- Portada curso + créditos (2)
- Encuadre (5: bienvenida, objetivo general, mapa, expectativas, diagnóstica)
- Portadas de módulo + contenido M-I (5-6)
- M-II (5-7 slides, incluye demo en vivo que es slide minimal)
- Energizante (0-1, casi siempre 0 si la técnica es física)
- M-III (4-5)
- Sumativa (4: portada + proyecto + teoría + auto-auditoría)
- Cierre (4-5: resumen, 72h, ecosistema, gracias)
- Bibliografía (1-2)

Cada slide con la ficha completa del template 11: tipo, momento, bloque iAprende
ligado, color de acento, texto visible (máx 25 palabras), elemento visual, notas
del orador, duración en vivo.

Guardar como:
/cursos/{slug}/11-storyboard-slides.md

DETENERSE aquí y esperar aprobación humana del storyboard antes de generar .pptx.

PASO 2 · Generar .pptx (invocar skill pptx)
--------------------------------------------------------
Tras aprobación del storyboard:
- Aplicar paleta: cobalt #2A4B7C, orange #E07A5F, mint #D4E5DF, lavender #E6E1F0, fondo #F9F9F7.
- Tipografías: Libre Baskerville Bold (títulos), Inter (cuerpo), JetBrains Mono (código/técnico).
- Portadas de módulo con color pleno + número romano gigante.
- Incluir notas del orador en cada slide.
- Logos iAprende + DE en portada y contraportada.
- Pie legal en última slide: "Certificado EC0301 vía B Smarter".

Guardar como:
/cursos/{slug}/12-slides.pptx

Al terminar ambos pasos, imprimir reporte:
- # de slides generados
- # de slides ligados a bloques iAprende vs total
- Confirmar paleta y tipografías aplicadas
- Confirmar notas del orador en cada slide

═══════════════════════════════════════════════════════════
```

## Handoff
Al reportar "ejecutado" → `f10-empaquetar-y-checklist.md`.
