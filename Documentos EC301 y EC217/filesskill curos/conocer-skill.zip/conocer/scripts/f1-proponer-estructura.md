---
título: Script Fase 1 · Proponer Estructura
fase: T2
tipo: prompt_interno
tags: [script, fase1, estructura]
---

# Script T2 · Proponer Estructura

Este script se ejecuta en el turno 2 de la skill, inmediatamente después de recibir el input del usuario (nombre del curso + 3 temas).

**Objetivo:** producir una propuesta estructural completa que el usuario pueda validar o ajustar en T3.

---

## Input esperado

```
Nombre del curso: {texto}
3 temas:
  - Tema 1: {texto}
  - Tema 2: {texto}
  - Tema 3: {texto}
```

Opcionalmente: perfil del grupo, sector o dominio si el usuario lo menciona.

---

## Acciones a ejecutar por Claude

### 1. Inferir estructura modular

De los 3 temas, mapear:

- **Tema 1 → Módulo I** (fundamentos / cambio de paradigma / conceptos)
- **Tema 2 → Módulo II** (aplicación / construcción / estructura del producto)
- **Tema 3 → Módulo III** (reflexión / ética / análisis)

Si los 3 temas no encajan natural con este patrón, **proponer adaptación y explicar**.

### 2. Inferir el producto principal del curso

Un curso EC0301 bien diseñado siempre produce **un entregable concreto** que el participante construye y sale con él.

- Para cursos sobre IA/prompt → el producto es un prompt estructurado
- Para cursos sobre ventas → el producto es un guión de llamada
- Para cursos técnicos → el producto es un procedimiento documentado

Identificar el producto y su estructura (5-7 componentes típicos).

### 3. Proponer lecciones por módulo

Para cada módulo, proponer 3-4 lecciones que:

- Van de lo simple a lo complejo
- Se pueden cubrir en el tiempo del módulo (M-I 15′, M-II 22′, M-III 15′)
- Encajan con la técnica instruccional canónica del módulo

### 4. Proponer apoyos pedagógicos iAprende para cada lección

Para CADA lección, asignar un tipo de bloque iAprende (ver [[../references/firestore-iaprende-schema]]):

- `texto_rico` para contenido expositivo
- `comparador` para diferenciar dos conceptos
- `infografia` con zonas expandibles para mapas conceptuales
- `tarjetas_flip` para preguntas con respuesta
- `tabla_editable` para bitácoras o planillas del alumno
- `simulador_html` para demos dinámicas
- `simulador_prompt` para construcción del producto (M-II)
- `caso_etico` para dilemas (M-III)
- `checklist` para evaluaciones
- `cuestionario` para diagnóstica y teoría
- etc.

### 5. Proponer caso ancla

Un caso de negocio único que recorra los 3 módulos. El instructor escoge un caso concreto del dominio:

- Caso modelo IA: "Pan de Casa" (panadería artesanal)
- Caso modelo Estilos: colaboradores de una empresa con cargos gerenciales

Proponer **2 opciones** de caso y dejar que el usuario elija en T3.

### 6. Redactar objetivos draft en formato Mager

- **Objetivo general:** patrón Mager completo (ver [[../references/redaccion-objetivos-mager]])
- **Objetivo particular M-I:** verbo Comprender/Identificar + producto
- **Objetivo particular M-II:** verbo Aplicar/Construir + producto específico
- **Objetivo particular M-III:** verbo Analizar/Evaluar + criterio ético
- **Objetivo transversal Saber Convivir:** plantilla canónica

### 7. Mapear tiempos 35/65/25

Verificar que la estructura propuesta cabe en 120 min. Ver [[../references/tiempos-canonicos-120min]].

### 8. Identificar técnicas a emplear

- Expositiva dialogada → M-I
- Demostrativa en vivo → M-II
- Diálogo-Discusión → M-III
- Rompe Hielo "Mapa de Expectativas" → Encuadre
- Energizante derivado del tema → entre M-II y M-III
- Cierre grupal "Mi {producto} del futuro" → Cierre

---

## Formato de salida

Responder al usuario con una propuesta estructurada usando Markdown, con esta plantilla:

```markdown
## Propuesta estructural · {curso_nombre}

### Producto principal del curso
{nombre_producto}, con componentes: {lista_5_componentes}

### Caso ancla · 2 opciones
**Opción A:** {caso_A_nombre} · {descripción 1 línea}
**Opción B:** {caso_B_nombre} · {descripción 1 línea}

### Módulos

**Módulo I · {M1_titulo}** (15 min · técnica Expositiva)
Objetivo: {obj_M1}
Lecciones:
- M1.1 {leccion} · bloque `{tipo_iAprende}` · {descripción apoyo}
- M1.2 ...
- M1.3 ...

**Módulo II · {M2_titulo}** (22 min · técnica Demostrativa)
Objetivo: {obj_M2}
Lecciones:
- M2.1 ... (bloque infografia con componentes)
- M2.2 ... (bloque campo_libre)
- M2.3 ... (bloque simulador_prompt ★)
- M2.4 ... (bloque checklist formativa)

**Módulo III · {M3_titulo}** (15 min · técnica Diálogo-Discusión)
Objetivo: {obj_M3}
Lecciones:
- M3.1 ... (bloque caso_etico)
- M3.2 ...
- M3.3 ...

**Transversal — Saber Convivir**
Objetivo: {obj_transversal}

### Objetivo general (Mager)
{objetivo_general_completo}

### Tiempos
Apertura 35′ → Desarrollo 65′ → Cierre 25′ · Total 120′ ✓

### Técnicas CONOCER empleadas
Expositiva + Demostrativa + Diálogo-Discusión + Rompe Hielo + Energizante + Cierre ✓

### Bloques iAprende estimados
~{n} bloques (Preámbulo 1 + Encuadre 5 + M-I {x} + M-II {y} + M-III {z} + Sumativa 4 + Cierre 3)
```

---

## Transición a T3

Después de presentar la propuesta, ejecutar `scripts/f2-validar-con-usuario.md`.

---

*Script ejecutado automáticamente al invocar la skill con input mínimo.*
