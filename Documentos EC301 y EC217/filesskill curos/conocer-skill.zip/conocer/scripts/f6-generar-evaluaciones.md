---
fase: 6
turno_del_flujo: T6
actor: Claude → Antigravity
output: prompt de despacho para agent-evaluaciones (4 instrumentos)
---

# Fase 6 · Prompt de despacho para agente Evaluaciones

**Produce:** Diagnóstica + Formativa + Sumativa + Satisfacción (como doc suelto EC0217.01).

---

## Prompt de despacho (bloque copiable)

```
═══════════════════════════════════════════════════════════
PROMPT DE DESPACHO · agent-evaluaciones
═══════════════════════════════════════════════════════════

Eres agent-evaluaciones de la skill CONOCER de Desarrollos Elaborados.

Lee:
- _skills/conocer/SKILL.md
- _skills/conocer/references/ec0301-criterios-evaluacion.md (§E1024)
- _skills/conocer/references/evaluaciones-y-rubricas.md
- _skills/conocer/templates/03-eval-diagnostica.md
- _skills/conocer/templates/04-eval-formativa-guia-observacion.md
- _skills/conocer/templates/05-eval-sumativa-proyecto-rubrica.md
- _skills/conocer/templates/06-eval-satisfaccion.md

INPUT:
Curso: {NOMBRE / slug}
Caso ancla: {CASO}
Objetivos Mager: {TRANSCRIPCIÓN COMPLETA}
Producto sumativo: {DESCRIPCIÓN DEL PROYECTO}

TAREAS:

1. DIAGNÓSTICA (template 03):
   - 5 preguntas abiertas, referenciales, NO califican.
   - Cubren: concepto central, experiencia previa, comparación, vocabulario, aplicabilidad.
   - 5 min de aplicación.
   - Producir .md + .docx.

2. FORMATIVA · Guía de Observación (template 04):
   - Valor 50 % de la calificación.
   - 6 criterios × 10 pts = 60 pts max.
   - Alineada al producto construido en M-II.
   - Incluir Parte A (autoevaluación del participante) + Parte B (guía del instructor).
   - Retroalimentación inmediata + 2 min de corrección.

3. SUMATIVA (template 05):
   - Valor 50 % de la calificación. 18-20 = Dominio Avanzado; 14-17 = Competente.
   - Parte I · Proyecto aplicado al caso ancla personal del participante (20 pts).
   - Parte II · Teoría 3 preguntas de opción múltiple con clave (3 pts).
   - Parte III · Auto-auditoría ética 3-5 items.
   - Rúbrica 4 niveles × 5 criterios.
   - Incluir clave de respuestas para instructor.

4. SATISFACCIÓN (template 06):
   - 4 secciones Likert 1-5: Evento (4 items) + Contenido (4) + Materiales (4) + Instructor (5).
   - Espacio para comentarios libres.
   - Producir como documento independiente (EC0217.01 lo exige así).
   - También queda referenciada dentro del Manual Instructor (lo genera agent-manual-instructor).

CUBRIR CRITERIOS EC0301 §E1024 LITERALES:
- Cada instrumento incluye: nombre del curso, espacio instructor, espacio participante,
  fecha de aplicación, instrucciones de aplicación, reactivos, claves (si aplican),
  estrategia vinculada a carta descriptiva, sin errores ortográficos.
- Instrucciones de aplicación: condiciones, tiempos, indicaciones separadas para
  participante y evaluador.
- Reactivos: alineados a objetivos, congruentes con el tipo de instrumento, una
  sola evidencia por reactivo, medibles, valor indicado.

UBICACIÓN:
/cursos/{slug}/
  ├── 03-diagnostica.md y .docx
  ├── 04-formativa-guia-observacion.md y .docx
  ├── 05-sumativa-proyecto-rubrica.md y .docx
  └── 06-satisfaccion.md y .docx

Al terminar, imprimir checklist EC0301 §E1024 marcando cada criterio.

═══════════════════════════════════════════════════════════
```

## Handoff
Al reportar "ejecutado" → `f7-generar-manuales.md`.
