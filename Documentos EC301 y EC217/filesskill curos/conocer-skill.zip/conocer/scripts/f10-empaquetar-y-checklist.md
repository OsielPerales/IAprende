---
fase: 10
turno_del_flujo: T7
actor: Claude
output: checklist final EC0301 + EC0217.01 cruzado con artefactos producidos
---

# Fase 10 · Empaquetado y checklist final

**Activación:** todos los agentes (5) reportaron "ejecutado". Los 12 artefactos están en /cursos/{slug}/.

---

## Objetivo

Cerrar el flujo con:
1. Inventario físico de los 12 artefactos producidos (verificar que los archivos existen con sus dos formatos donde aplique).
2. Checklist de cumplimiento EC0301 + EC0217.01 cruzado con cada artefacto.
3. Instrucciones de siguientes pasos para el usuario (piloto, envío a B Smarter, carga a iAprende).

---

## Formato de salida al usuario

```
## Paquete de curso listo · {NOMBRE}

**Ubicación:** /cursos/{slug}/

### Inventario (12/12)

| # | Artefacto | .md | .docx | Tamaño |
|---|---|:-:|:-:|---|
| 1 | Planeación / Carta descriptiva | ✓ | ✓ | {n} pp |
| 2 | Lista de Verificación de Requerimientos | ✓ | ✓ | {n} pp |
| 3 | Evaluación Diagnóstica | ✓ | ✓ | {n} pp |
| 4 | Evaluación Formativa · Guía de Observación | ✓ | ✓ | {n} pp |
| 5 | Evaluación Sumativa · Proyecto + Rúbrica | ✓ | ✓ | {n} pp |
| 6 | Evaluación de Satisfacción | ✓ | ✓ | {n} pp |
| 7 | Manual del Participante | ✓ | ✓ | {n} pp |
| 8 | Manual del Instructor | ✓ | ✓ | {n} pp |
| 9 | Informe Final (blank) | ✓ | ✓ | {n} pp |
| 10 | Hoja de Adaptación iAprende (35-40 bloques) | ✓ | — | {n} líneas |
| 11 | Storyboard de Slides | ✓ | — | {n} slides |
| 12 | Slides .pptx | — | (.pptx) | {n} slides |

### Checklist EC0301 (9 criterios de compliance)

- [x] E1023 · Carta descriptiva completa con todos los campos requeridos
- [x] E1023 · Objetivo general en forma Mager completa
- [x] E1023 · Objetivos particulares alineados a temas + Saber Convivir incluido
- [x] E1023 · 3 técnicas instruccionales + 3 grupales documentadas
- [x] E1023 · Estrategias de evaluación en los 3 momentos (diag/form/sum)
- [x] E1024 · Instrumentos con nombre curso, instructor, participante, fecha, instrucciones
- [x] E1024 · Reactivos medibles con clave y ponderación
- [x] E1024 · Evaluación de satisfacción con 4 secciones
- [x] E1025 · Manuales participante e instructor completos

### Checklist EC0217.01 (7 entregables)

- [x] Documento de planeación del curso
- [x] Lista de verificación de requerimientos
- [x] Evaluación diagnóstica
- [x] Evaluación formativa
- [x] Evaluación final
- [x] Evaluación de satisfacción (documento independiente)
- [x] Informe final (blank, a llenar post-impartición)

### Branding

- [x] Paleta iAprende / DE aplicada
- [x] Libre Baskerville + Inter + JetBrains Mono
- [x] B Smarter solo como ECE certificador en pie legal
- [x] Portadas con logos iAprende + DE

### Siguientes pasos sugeridos

1. **Revisión ortográfica final.** Pasar los 9 docs oficiales por corrector antes
   de enviar a B Smarter. (Los 3 de iAprende no necesitan corrector externo.)
2. **Piloto interno en DE/CYD CNC** (principio Skin in the Game). Impartir el
   curso al menos 1 vez antes de comercializarlo.
3. **Llenar Informe Final post-piloto** (template 09) y anexarlo al paquete.
4. **Cargar a iAprende** usando la Hoja de Adaptación. Ejecutar agent
   en Claude Code contra el proyecto Firebase iaprende-1415d. Estados de bloques
   quedan en [ ] hasta que los componentes React estén implementados.
5. **Generar flyers de marketing** (reutilizar script generar_flyers_v2.py del
   pack iAprende GTM) con los datos de este curso.

### Notas de calidad

{Listar cualquier observación particular del curso: dificultad detectada,
ajustes necesarios, bibliografía con fuente limitada, etc.}

---

**Skill ejecutada en su totalidad. Guardar conversación para referencia futura.**
```

---

## Reglas duras

- **No marcar un checkbox sin evidencia.** Si un artefacto no está físicamente en disco, dejarlo en [ ].
- **Reportar deuda explícita** si algún agente falló en una sub-tarea. El usuario debe poder ver qué está incompleto.
- **Incluir ubicación exacta** de cada archivo para que el usuario pueda copiarlos a Drive o abrirlos directamente.
- **Siguiente paso = piloto interno**, no venta inmediata. Skin in the Game.
