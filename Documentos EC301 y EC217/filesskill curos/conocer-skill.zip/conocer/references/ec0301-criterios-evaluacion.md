---
título: EC0301 · Criterios de Evaluación
tipo: referencia_normativa
fuente: CONOCER · Diario Oficial de la Federación 28-nov-2012 · v6.0
tags: [conocer, ec0301, criterios]
---

# EC0301 · Criterios de Evaluación Literales

Transcripción operativa del Estándar EC0301 "Diseño de cursos de formación del capital humano de manera presencial grupal, sus instrumentos de evaluación y manuales del curso" de CONOCER. **Úsese como checklist de validación antes de entregar cualquier artefacto.**

---

## Elemento 1 de 3 · E1023 — Diseñar cursos

### Producto 1 · Carta descriptiva elaborada

- [ ] Se presenta en formato digital y/o impreso
- [ ] Indica el nombre del curso
- [ ] Contiene campo para registrar nombre de la persona que diseñó el curso
- [ ] Contiene campo para registrar fecha(s) de impartición
- [ ] Describe los requisitos de ingreso de los participantes
- [ ] Indica el número de participantes
- [ ] Contiene los objetivos de aprendizaje
- [ ] Especifica los momentos de capacitación
- [ ] Describe el contenido del curso
- [ ] Especifica las técnicas de instrucción
- [ ] Especifica las técnicas grupales
- [ ] Describe las actividades del proceso de instrucción-aprendizaje
- [ ] Describe las estrategias de evaluación de los aprendizajes
- [ ] Refiere los materiales didácticos a utilizar
- [ ] Establece los tiempos programados para el desarrollo de las actividades
- [ ] Se presenta sin errores ortográficos

### Producto 2 · Objetivo general del curso redactado

- [ ] Determina el sujeto de aprendizaje
- [ ] Indica la conducta, producto y/o actitud de aprendizaje a alcanzar por el participante
- [ ] Especifica las condiciones de operación
- [ ] Especifica los límites de tiempo, calidad, exactitud y/o criterio aceptable

### Producto 3 · Objetivos particulares / específicos elaborados

- [ ] Determinan el sujeto de aprendizaje
- [ ] Indican la conducta, producto y/o actitud de aprendizaje a alcanzar
- [ ] Especifican las condiciones de operación
- [ ] Especifican los límites de tiempo, calidad, exactitud y/o criterio aceptable
- [ ] Son congruentes con los temas del curso
- [ ] Son congruentes con las características de los participantes

### Producto 4 · Temas y subtemas definidos

- [ ] Son congruentes entre sí
- [ ] Corresponden con los objetivos de aprendizaje
- [ ] Se desarrollan en secuencia de lo simple a lo complejo

### Producto 5 · Técnicas de instrucción seleccionadas

- [ ] Corresponden con los objetivos de aprendizaje
- [ ] Corresponden con los requisitos de ingreso de los participantes
- [ ] Corresponden con el número de participantes

### Producto 6 · Técnicas grupales seleccionadas

- [ ] Están planeadas para favorecer la dinámica secuencial del proceso instrucción-aprendizaje
- [ ] Corresponden con el perfil del grupo
- [ ] Corresponden con el número de participantes

### Producto 7 · Actividades del proceso de instrucción-aprendizaje definidas

- [ ] Corresponden con el nivel de ejecución de los objetivos
- [ ] Son congruentes con los temas del curso
- [ ] Corresponden con el perfil del grupo
- [ ] Especifican el desarrollo de las técnicas empleadas

### Producto 8 · Estrategias de evaluación determinadas

- [ ] Corresponden con los objetivos de aprendizaje
- [ ] Contienen los criterios de evaluación a utilizar
- [ ] Contienen los instrumentos que se aplicarán en los tres momentos: Diagnóstica, Formativa y Sumativa
- [ ] Mencionan los instrumentos a utilizar
- [ ] Describen las evidencias que el participante deberá demostrar

### Producto 9 · Materiales didácticos seleccionados

- [ ] Corresponden con las actividades de la carta descriptiva
- [ ] Son congruentes con las características de los participantes
- [ ] Corresponden con los temas del curso

### Conocimientos exigidos al diseñador

1. **Teorías del aprendizaje** (nivel *comprensión*): Conductismo, Cognitivismo, Constructivismo, Humanismo
2. **Principios de educación de adultos** (nivel *conocimiento*): Necesidad de saber, Disposición para aprender, Motivación para aprender, Recuperación de la experiencia, Desaprendizaje, Aplicación práctica en la vida real
3. **Técnicas instruccionales** (nivel *conocimiento*): Expositiva, Diálogo-discusión, Demostración-ejecución
4. **Técnicas grupales** (nivel *conocimiento*): Rompehielo, Energetizante, Cierre

### Actitud exigida

**Orden:** La manera en que se presentan los temas y subtemas de lo simple a lo complejo.

---

## Elemento 2 de 3 · E1024 — Diseñar instrumentos de evaluación

### Producto 1 · Instrumentos de evaluación elaborados

- [ ] Indican el nombre del curso
- [ ] Contienen espacio para registrar el nombre del instructor
- [ ] Contienen espacio para registrar el nombre del participante
- [ ] Contienen espacio para registrar la fecha de aplicación
- [ ] Detallan las instrucciones de aplicación
- [ ] Contienen los reactivos de evaluación
- [ ] Incluyen las claves de respuestas para el evaluador y/o instructor
- [ ] Corresponden con las estrategias de evaluación mencionadas en la carta descriptiva
- [ ] Se presentan en formato digital y/o impreso
- [ ] Se presentan sin errores ortográficos

### Producto 2 · Instrucciones de aplicación

- [ ] Establecen las condiciones de aplicación
- [ ] Establecen los tiempos para la evaluación
- [ ] Contienen las indicaciones para el participante
- [ ] Contienen las indicaciones para el evaluador

### Producto 3 · Reactivos del instrumento de evaluación

- [ ] Corresponden con los objetivos de aprendizaje
- [ ] Son congruentes con el tipo de instrumento
- [ ] Verifican una sola evidencia y/o característica
- [ ] Son medibles
- [ ] Indican su valor

### Producto 4 · Claves de respuestas

- [ ] Contienen las respuestas definidas como correctas
- [ ] Indican la ponderación de cada reactivo
- [ ] Señalan el puntaje total esperado

### Producto 5 · Instrumento de satisfacción del curso

- [ ] Contiene espacio para registrar el nombre del curso
- [ ] Contiene espacio para registrar el nombre del instructor
- [ ] Enuncia las instrucciones generales de aplicación
- [ ] Señala la escala de estimación del nivel de satisfacción
- [ ] Incluye reactivos sobre las características del evento
- [ ] Incluye reactivos sobre el contenido del curso
- [ ] Incluye reactivos sobre los materiales didácticos empleados
- [ ] Incluye reactivos sobre el desempeño del instructor
- [ ] Contiene espacios para el registro de comentarios

### Conocimientos exigidos

1. Definición de validez y confiabilidad de los instrumentos de evaluación (nivel *conocimiento*)
2. Características de los instrumentos de evaluación: De habilidades y destrezas · De conocimiento (nivel *conocimiento*)

---

## Elemento 3 de 3 · E1025 — Diseñar manuales del curso

### Producto 1 · Manual del participante

- [ ] Incluye nombre del curso
- [ ] Menciona nombre de la persona que diseñó el curso
- [ ] Contiene índice del curso
- [ ] Contiene presentación del manual
- [ ] Contiene introducción
- [ ] Señala objetivo general acorde a la carta descriptiva
- [ ] Señala objetivos particulares/específicos acordes a la carta descriptiva
- [ ] Desglosa los temas
- [ ] Indica fuentes de información documental o de internet
- [ ] Se presenta en formato digital y/o impreso
- [ ] Se presenta sin errores ortográficos

### Producto 2 · Presentación del manual del participante

- [ ] Contiene bienvenida al participante
- [ ] Ofrece recomendaciones sobre forma de utilizar el manual
- [ ] Describe la organización del manual

### Producto 3 · Introducción del manual del participante

- [ ] Contiene resumen de los temas
- [ ] Señala el beneficio que el curso aportará
- [ ] Establece el enfoque didáctico del curso
- [ ] Es congruente con el objetivo de aprendizaje

### Producto 4 · Temas desarrollados en Manual Participante

- [ ] Corresponden con la carta descriptiva
- [ ] Son congruentes con los objetivos
- [ ] Mencionan los objetivos particulares/específicos
- [ ] Están desarrollados de lo simple a lo complejo
- [ ] Describen las actividades necesarias
- [ ] Contienen síntesis y/o conclusiones
- [ ] Incluyen una forma de evaluación por tema

### Producto 5 · Fuentes de información · Manual Participante

- [ ] Corresponden con los objetivos del curso
- [ ] Especifican nombre del autor
- [ ] Señalan año de publicación y/o fecha de acceso
- [ ] Indican título de la obra
- [ ] Refieren editorial y/o URL
- [ ] Señalan país de origen

### Producto 6 · Manual del Instructor

- [ ] Incluye nombre del curso
- [ ] Incluye nombre de la persona que diseñó el curso
- [ ] Contiene índice
- [ ] Cuenta con una introducción
- [ ] Incluye la carta descriptiva
- [ ] Describe los requerimientos del lugar de capacitación
- [ ] Contiene sugerencias para desarrollar los temas
- [ ] Incluye los instrumentos de evaluación
- [ ] Incluye clave de respuestas de los cuestionarios
- [ ] Señala fuentes de información documental y/o internet
- [ ] Se presenta digitalizado y/o impreso
- [ ] Se presenta sin errores ortográficos

### Producto 7 · Introducción del Manual del Instructor

- [ ] Explica el propósito del manual
- [ ] Expone la estructura del curso
- [ ] Expone la modalidad del curso (Presencial / en línea / tutorado / autodidacta / mixto)

### Producto 8 · Requerimientos del lugar de capacitación

- [ ] Señalan las características del lugar
- [ ] Mencionan el material de apoyo a utilizar
- [ ] Especifican el equipo necesario para desarrollar el curso
- [ ] Proporcionan recomendaciones de uso del material de apoyo

### Producto 9 · Temas del Manual del Instructor

- [ ] Corresponden con los mencionados en la carta descriptiva
- [ ] Ofrecen sugerencias de apoyos necesarios para la explicación
- [ ] Describen técnicas, actividades y/o ejemplos para el desarrollo
- [ ] Describen formas, criterios y tiempos de evaluación para cada tema

### Producto 10 · Fuentes de información · Manual Instructor

- [ ] Corresponden con los objetivos del curso
- [ ] Especifican nombre del autor
- [ ] Señalan año de publicación y/o fecha de acceso
- [ ] Indican título de la obra
- [ ] Refieren editorial y/o URL
- [ ] Señalan país de origen

---

## Datos operativos

- **Nivel en SNC:** Tres (actividades programadas, rutinarias e impredecibles; recibe orientaciones generales; supervisa subordinados)
- **Vigencia del certificado:** 4 años
- **Duración evaluación en campo:** 1 hora
- **Duración evaluación en gabinete:** 2 horas
- **Comité que lo desarrolló:** AMECAP A.C.
- **Aprobado por Comité Técnico CONOCER:** 3 oct 2012
- **Publicado DOF:** 28 nov 2012

---

*Toda modificación a este archivo solo se hace si CONOCER publica una revisión oficial del EC0301.*
