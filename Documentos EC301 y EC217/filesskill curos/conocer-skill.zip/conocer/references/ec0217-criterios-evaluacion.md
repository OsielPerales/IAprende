---
título: EC0217.01 · Criterios de Impartición
tipo: referencia_normativa
fuente: CONOCER · EC0217 v1 · alcance inferido del correo B Smarter
tags: [conocer, ec0217, imparticion, criterios]
---

# EC0217.01 · Criterios de Impartición

El estándar EC0217.01 "Impartición de cursos de formación del capital humano de manera presencial grupal" complementa el EC0301. Donde EC0301 certifica **diseñar** el curso, EC0217.01 certifica **impartirlo** correctamente.

---

## Entregables que el instructor debe presentar

Según correo INICIO 0217.01 de B Smarter:

1. Documento de planeación del curso
2. Lista de verificación de requerimientos
3. Evaluación diagnóstica
4. Evaluación formativa
5. Evaluación final
6. Evaluación de satisfacción
7. Informe final

---

## Foco de evaluación

EC0217.01 evalúa al instructor en tres momentos:

- **Antes (preparación):** lista de verificación de requerimientos, arreglo del lugar, materiales.
- **Durante (impartición):** aplicación de técnicas instruccionales + grupales, manejo del tiempo, aplicación de instrumentos de evaluación.
- **Después (reporte):** informe final, análisis de resultados de evaluaciones.

---

## Lista de verificación de requerimientos · criterios mínimos

El instrumento debe verificar, antes del curso:

- [ ] Existencia del lugar/sala conforme a requerimientos
- [ ] Mobiliario suficiente y dispuesto
- [ ] Equipo de apoyo (proyector, pantalla, bocinas, cables, extensiones)
- [ ] Conectividad (internet, corriente eléctrica)
- [ ] Material didáctico: impresos de Manual Participante, evaluaciones, lista de asistencia
- [ ] Material de salud/seguridad/protección civil
- [ ] Accesos a plataformas o herramientas específicas del curso
- [ ] Firma de quien verifica + fecha + hora (20–30 min antes)

---

## Informe final · contenido mínimo

El Informe Final cierra el ciclo de impartición:

1. **Datos del evento** (nombre curso, fecha, lugar, horario, duración real)
2. **Asistencia** (nº inscritos, asistentes reales, % asistencia)
3. **Resultados de evaluaciones**
   - Promedio Diagnóstica (referencial)
   - Promedio Formativa (50 %)
   - Promedio Sumativa (50 %)
   - Promedio Satisfacción (Likert)
   - % aprobados (≥80 %)
4. **Observaciones del instructor**
   - Momentos que funcionaron
   - Momentos que requieren ajuste
   - Dudas recurrentes del grupo
   - Sugerencias para próximas ediciones
5. **Anexos:** listas firmadas, fotografías (opcional), evaluaciones físicas (en Drive para B Smarter)

---

## Técnicas a dominar en impartición

EC0217.01 exige que el instructor demuestre dominio de:

- **Técnica expositiva** con apertura, desarrollo y síntesis
- **Técnica demostrativa** con pasos ordenados (preparación → demostración → práctica guiada → retroalimentación)
- **Técnica diálogo-discusión** con reglas, moderación neutral y conclusión grupal
- **Técnica rompe-hielo** alineada con el perfil del grupo
- **Técnica energizante** en el momento correcto (reactivación post-demostración)
- **Técnica de cierre** con verbalización de compromisos

Ver detalles en [[tecnicas-instruccionales]].

---

## Relación con EC0301

Para un instructor que es **también** diseñador (Osiel):

- Los documentos 1, 3, 4, 5 se producen UNA vez y cubren ambos estándares.
- El documento 2 (lista de verificación) es específico de 0217.01.
- El documento 6 (satisfacción) ya existía embebido en Manual del Instructor por EC0301, pero 0217.01 lo pide también como documento suelto.
- El documento 7 (informe final) se produce solo post-impartición.

Ver matriz en [[entregables-matriz]].

---

## Nota sobre fuente

El PDF oficial de EC0217.01 **no fue integrado en el corpus de referencia** de esta skill v1.0. El alcance se infirió del correo de entregables de B Smarter y de la estructura del caso modelo. Actualizar este archivo cuando se obtenga el estándar oficial.

---

*Actualizar cuando CONOCER publique el PDF oficial de EC0217.01 o cuando B Smarter modifique la lista de entregables.*
