---
título: Patrones Estructurales · Invariantes del Corpus Modelo
tipo: referencia_operativa
fuentes: [Manual Participante IA, Manual Instructor IA, Planeación v4, VERIFICACION N1 v2, Ejemplo BSmarter Estilos]
tags: [patrones, invariantes, estructura]
---

# Patrones Estructurales · Invariantes del Corpus Modelo

Esta referencia extrae **lo que no cambia** entre cursos CONOCER EC0301 bien hechos. Los agentes la consultan para saber qué estructura respetar.

---

## Patrón global del curso

```
120 minutos (caso modelo)
├── Apertura / Encuadre:      35 min
├── Desarrollo:               65 min
└── Cierre:                   25 min
```

Ver reparto fino en [[tiempos-canonicos-120min]].

---

## Estructura obligatoria del Manual del Participante

Orden canónico extraído del caso modelo:

1. **Portada** con imagen + título + "Diseñador Instruccional: <nombre>"
2. **Índice** (tabla con secciones y páginas)
3. **Presentación del taller** (bienvenida, recomendaciones de uso, organización del manual)
4. **Introducción** (contexto, motivación al lector)
5. **Beneficios del curso** (laborales + personales, en dos bloques)
6. **Enfoque didáctico** (modalidad + técnicas instruccionales empleadas)
7. **Objetivo General** (en tabla con marco)
8. **Objetivos Particulares** (uno por módulo + transversal Saber Convivir)
9. **Análisis de Expectativas y Compromisos** (4 tablas de llenado)
10. **Momentos de Evaluación** (tabla con factor, porcentaje, instrumento)
11. **Módulo I** (objetivo del módulo → imagen sugerida → lecciones → actividades → ejemplo canónico)
12. **Módulo II** (misma estructura)
13. **Módulo III** (misma estructura)
14. **Evaluación Diagnóstica** (formato con preguntas abiertas)
15. **Evaluación Formativa** (Parte A para participante + guía observación para instructor)
16. **Evaluación Final** (Parte I Proyecto + Parte II Teoría + Auto-auditoría ética + Rúbrica)
17. **Bibliografía** (mínimo 5 fuentes, APA, ≥1 CONOCER, ≥2 vivas/recientes)
18. **Pie legal** con firma institucional

---

## Estructura obligatoria del Manual del Instructor

1. **Portada** idéntica en branding al Manual Participante
2. **Índice**
3. **Introducción** (propósito del manual)
4. **Estructura del taller** (descripción narrativa 3 momentos)
5. **Modalidad del taller** (presencial + enfoque constructivista + técnicas)
6. **Requerimientos del taller** (tabla de 5 columnas: instalaciones / equipo / material didáctico / humanos / otros)
7. **Carta Descriptiva completa**
   - Información general
   - Objetivo general (Sujeto · Acción · Condición)
   - Objetivos particulares (tabla 5 columnas incluyendo Beneficios)
   - Formas, momentos y criterios de evaluación
8. **Comprobación de recursos** (20–30 min antes del inicio)
9. **Secuencia Instruccional**
   - Apertura / Encuadre (tabla 7 columnas: tiempo / tema / actividades / instructor / participantes / técnica / material)
   - Desarrollo (misma estructura)
   - Cierre (misma estructura)
10. **Sugerencias para el desarrollo de los temas** (por módulo, con técnica canónica)
11. **Cierre del curso** (conclusiones, logro de expectativas, logro de objetivos, continuidad)
12. **Instrumentos de evaluación con guía de respuestas y rúbrica**
13. **Encuesta de satisfacción embebida**
14. **Bibliografía**

### Tabla de secuencia instruccional · 7 columnas

| Tiempo | Tema | Actividades | Instructor (a–j) | Participantes | Técnica | Material y Equipo |

- Columna "Instructor" usa lista numerada a), b), c)… para describir acciones concretas.
- Columna "Técnica" usa nombres canónicos (TÉCNICA EXPOSITIVA, TÉCNICA DEMOSTRATIVA, etc.).

---

## Estructura obligatoria de la Planeación / Carta Descriptiva

Una sola tabla continua con estas secciones verticales:

1. **INFORMACIÓN GENERAL** (nombre curso, instructor, lugar, duración, perfil participante, nº participantes)
2. **PROPÓSITO/BENEFICIO** (párrafo narrativo único)
3. **Objetivo General** con columnas Sujeto · Acción · Condición
   - Condición se subdivide en "¿Cómo?" + "¿Para qué?"
4. **Objetivos Particulares** con 5 columnas: Sujeto · Acción · Condición · Temas · Beneficios
   - Una fila por módulo + una fila extra para el transversal Saber Convivir
5. **Requerimientos** (tabla 6 columnas: instalaciones / equipo / material didáctico / humanos / salud-seguridad / otros)
6. **Formas, momentos y criterios de evaluación** (tabla: aspecto / valor / instrumento / momento)
7. **Comprobación de la existencia y funcionamiento** (20 min antes)
8. **APERTURA O ENCUADRE** (tabla 5 columnas: duración / etapa / descripción / técnica / material)
9. **DESARROLLO** (tabla 5 columnas, con subdivisión por módulos)
10. **Resumen de técnicas aplicadas** (fila final de Desarrollo)
11. **CIERRE** (tabla 5 columnas)
12. **Duración total** declarada al final

---

## Estructura obligatoria de la Hoja de Adaptación iAprende

Patrón extraído del caso modelo (35 bloques):

1. **Metadata**: curso, plataforma, firebase project, stack, versión, autor, estándar
2. **Instrucciones de uso** (cómo leer las fichas de bloque)
3. **Arquitectura de almacenamiento** (colecciones Firestore + tipos de bloque + alojamiento de assets)
4. **Bloques** agrupados por módulo:
   - ▸ PREÁMBULO (bloques P.N)
   - ▸ ENCUADRE (bloques E.N)
   - ▸ MÓDULO I (bloques M1.N)
   - ▸ MÓDULO II (bloques M2.N)
   - ▸ MÓDULO III (bloques M3.N)
   - ▸ SUMATIVA (bloques S.N)
   - ▸ CIERRE (bloques C.N)
5. Cada bloque tiene ficha:
   ```
   FUENTE:     <origen del contenido>
   MÓDULO:     <id módulo>
   ORDEN:      <número secuencial>
   TIPO:       <BloqueType de schema Firestore>
   DURACIÓN:   <min>
   ESTADO:     [ ] / [x]
   ```
   Más: contenido a transcribir, interactivo, almacenamiento.
6. **Resumen de estado** (tabla con todos los bloques + estado)
7. **Componentes React a crear/registrar**

Ver tipos de bloque en [[firestore-iaprende-schema]].

---

## Caso ancla transversal

Todo curso debe elegir **un caso de negocio único** que recorra los 3 módulos:

- Caso modelo IA: "Pan de Casa" (panadería artesanal Tlalpan) — aparece en M-I (identificación procesos), M-II (construcción prompt), M-III (análisis ético).
- Caso modelo Estilos: perfiles de colaboradores con cargos gerenciales.

El caso ancla se elige en el turno T3 de la skill y se inyecta en todos los artefactos.

---

## Módulos y sus técnicas instruccionales canónicas

| Módulo | Técnica instruccional canónica | Tipo de contenido |
|---|---|---|
| M-I (Fundamentos / Encuadre) | Expositiva dialogada | Conceptual: cambio de paradigma, fundamentos |
| M-II (Aplicación / Demostración) | Demostrativa en vivo | Procedimental: construcción, aplicación |
| M-III (Reflexión / Ética / Análisis) | Diálogo-Discusión | Actitudinal: sesgos, ética, convivencia |

Ver reglas de elección en [[tecnicas-instruccionales]].

---

## Evaluación canónica

| Momento | Peso | Instrumento | Cuándo |
|---|---|---|---|
| Diagnóstica | Referencial (0 %) | Cuestionario 5 preguntas abiertas | Inicio (5 min) |
| Formativa | 50 % | Guía de observación (6 criterios × 10 pts) | Fin Módulo II |
| Sumativa | 50 % | Proyecto aplicado + 3 preguntas teoría + rúbrica 5 criterios × 4 niveles + auto-auditoría ética 3 ítems | Cierre del Desarrollo |

**Aprobatoria:** 80 % mínimo.

---

## Objetivos transversales obligatorios

El EC0301 exige que el curso desarrolle **los tres dominios de aprendizaje**:

- **Cognitivo (Saber):** cubierto por M-I + teoría M-II
- **Psicomotor (Saber Hacer):** cubierto por práctica demostrativa M-II
- **Afectivo (Saber Ser + Saber Convivir):** cubierto por M-III + objetivo transversal Saber Convivir

El objetivo transversal "Saber Convivir" aparece como última fila de la tabla de Objetivos Particulares de la Planeación.

---

## Pies de página y créditos

- **Portadas:** `Desarrollos Elaborados · iAprende` (sin B Smarter)
- **Pie legal interior (página 2 o 3):** `Curso diseñado bajo estándar CONOCER EC0301 · Certificación emitida a través del ECE B Smarter`
- **Pie de documentos:** `— Desarrollos Elaborados · iAprende —` o `— Manual del <rol> · <nombre del curso> —`
- **Fuente primaria del diseñador:** `Osiel Alejandro Perales Jiménez`

Ver detalles en [[../assets/branding/portadas-firmas]].

---

*Actualizar si se detecta un patrón nuevo al producir un curso adicional. Documento vivo.*
