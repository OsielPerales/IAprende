---
título: Schema Firestore iAprende · Adaptación de Cursos
tipo: referencia_tecnica
fuente: VERIFICACION_CURSO_IAPRENDE_N1_v2.md · caso modelo
tags: [firestore, iaprende, bloques, schema, react]
---

# Schema Firestore iAprende · Adaptación de Cursos

Esta referencia documenta la arquitectura de datos y tipos de bloque que todo curso adaptado a iAprende debe respetar.

**Firebase project:** `iaprende-1415d`  
**Hosting:** `iaprende-desarrollos.web.app`  
**Stack:** React + TypeScript + Vite + Firebase (Auth + Firestore + Hosting)

---

## Colecciones Firestore

```
cursos/
  └── {curso_id}/
        titulo:        string
        version:       string
        duracion_min:  number
        modulos:       string[]      ← ["preambulo", "encuadre", "modulo-1", ...]
        activo:        boolean
        created_at:    timestamp

bloques/
  └── {bloque_id}/
        curso_id:      string
        orden:         number        ← secuencia global
        modulo:        string        ← "preambulo" | "encuadre" | "modulo-1" | ...
        tipo:          BloqueType    ← ver más abajo
        titulo:        string
        contenido:     object        ← estructura variable según tipo
        duracion_min:  number
        created_at:    timestamp

progreso_alumno/
  └── {userId}_{cursoId}/
        bloques_completados:    string[]
        bitacora:               [{proceso, tiempo, repetitivo, candidato}]
        rol_construido:         string
        contexto_construido:    string
        prompt_maestro:         string
        calificacion_formativa: number
        calificacion_sumativa:  number
        respuestas_diagnostica: object
        compromisos_encuadre:   object
        auditoria_etica:        boolean[]
        compromisos_72h:        {h24, h48, h72}
        updated_at:             timestamp

grupos/
  └── {grupo_id}/
        curso_id:      string
        alumnos:       string[]
        instructor_id: string
        fecha:         timestamp
        activo:        boolean
```

---

## Tipos de Bloque · BloqueType

14 tipos definidos en el schema. Todo bloque de cualquier curso adaptado debe usar uno de estos:

```typescript
type BloqueType =
  | "portada"           // slide de apertura de módulo
  | "texto_rico"        // contenido expositivo con Markdown
  | "comparador"        // dos columnas comparativas (estático)
  | "infografia"        // imagen con zonas expandibles
  | "tarjetas_flip"     // cards con frente y reverso interactivo
  | "tabla_editable"    // tabla con campos guardados en Firestore
  | "checklist"         // lista de criterios con toggle
  | "cuestionario"      // preguntas opción múltiple con calificación auto
  | "campo_libre"       // área de texto guardada en progreso_alumno
  | "simulador_html"    // HTML embebido en iframe sandbox
  | "simulador_prompt"  // editor de prompt con evaluación via Claude API
  | "caso_etico"        // narrativa + preguntas colaborativas
  | "resumen_personal"  // resumen dinámico con datos del alumno
  | "mapa_ecosistema";  // mapa interactivo de cursos siguientes
```

### Uso recomendado por módulo

| Módulo | Tipos de bloque típicos |
|---|---|
| Preámbulo | `infografia` (3 Pilares Economía Cognitiva), `portada` |
| Encuadre | `texto_rico` (bienvenida, objetivos), `infografia` (mapa curso), `tabla_editable` (expectativas), `cuestionario` (diagnóstica) |
| Módulo I | `portada`, `comparador`, `simulador_html`, `tarjetas_flip`, `checklist`, `tabla_editable` (bitácora) |
| Módulo II | `portada`, `infografia` (componentes), `campo_libre` (ROL, CONTEXTO), `simulador_html`, `texto_rico`, `simulador_prompt` ★, `checklist` (formativa) |
| Módulo III | `portada`, `simulador_html` (alucinaciones), `texto_rico`, `checklist`, `caso_etico` |
| Sumativa | `portada`, `simulador_prompt`, `cuestionario`, `checklist` (auto-auditoría) |
| Cierre | `resumen_personal`, `checklist` (72h), `mapa_ecosistema` |

---

## Convención de IDs de bloque

Patrón del caso modelo:

```
{modulo_prefix}.{orden_dentro_modulo}

P.1        Preámbulo bloque 1
E.1 a E.5  Encuadre
M1.0       Portada Módulo I
M1.1 a M1.N Lecciones Módulo I
M2.0       Portada Módulo II
...
S.0 a S.3  Sumativa
C.1 a C.3  Cierre
```

El `orden` global en Firestore es un número entero secuencial (1, 2, 3, …, 35) que determina el recorrido del alumno.

---

## Tamaño típico de un curso Nivel 1

- 35–40 bloques
- Distribución: 1 preámbulo + 5 encuadre + 7 M-I + 9 M-II + 5 M-III + 4 sumativa + 3 cierre
- 9 tipos distintos usados como mínimo
- 3–4 bloques nuevos (no reciclados del material fuente) por curso
- Duración suma ~135 min (120 base + 15 de margen de interactivos)

---

## Alojamiento de recursos estáticos

```
Firebase Hosting (iaprende-desarrollos.web.app)
  └── /assets/
        └── /curso-{slug}/
              ├── infografias/        ← SVG editables
              ├── iconos/             ← SVG de módulos
              ├── imagenes/           ← PNG exportados de slides
              └── slides-recicladas/  ← screenshots del PDF original
```

Por cada curso nuevo se crea una carpeta `/assets/curso-{slug}/`.

---

## Componentes React · catálogo

Ruta en el monorepo iAprende: `src/components/bloques/`

```typescript
// Ya existentes (reutilizables)
├── BloquePortada.tsx
├── BloqueTextoRico.tsx
├── BloqueComparador.tsx
├── BloqueChecklist.tsx
├── BloqueCuestionario.tsx
├── BloqueCampoLibre.tsx
├── BloqueSimuladorHtml.tsx

// A crear si el curso los requiere
├── BloqueInfografia.tsx      // zonas expandibles
├── BloqueTarjetasFlip.tsx    // flip cards
├── BloqueTablaEditable.tsx   // tabla con Firestore write
├── BloqueSimuladorPrompt.tsx // editor + Claude API
├── BloqueCasoEtico.tsx       // respuestas colaborativas
├── BloqueResumenPersonal.tsx // resumen dinámico del alumno
├── BloqueMapaEcosistema.tsx  // mapa de cursos siguientes
```

Si el curso usa tipos ya cubiertos por componentes existentes → adaptación trivial. Si introduce tipos nuevos → extender componentes en el repo.

---

## Integración con Claude API (simulador_prompt)

El tipo `simulador_prompt` llama a la API de Claude directamente desde el cliente con rúbrica enviada en el prompt. Formato de request:

```javascript
{
  model: "claude-opus-4-7",
  max_tokens: 1000,
  system: "Eres evaluador formativo del curso <nombre>. Evalúa el prompt del alumno contra la rúbrica de 5 criterios. Devuelve JSON con {criterio_1, criterio_2, criterio_3, criterio_4, criterio_5, puntuacion_total, retroalimentacion_constructiva}.",
  messages: [
    { role: "user", content: "<prompt_del_alumno>" }
  ]
}
```

API key vía variable de entorno `VITE_CLAUDE_API_KEY` con proxy para no exponerla en el cliente.

---

## Role-based auth

```
roles:
  alumno   → lee su progreso, edita sus bloques interactivos
  maestro  → crea grupos, ve progreso de su grupo, impartir vista
  admin    → gestión completa del curso y usuarios
```

Actualmente `admin@iaprende.com` confirmado como admin. El rol de instructor (`maestro`) se asigna manualmente en Firestore.

---

## Proceso para añadir un curso nuevo

1. Crear documento en `cursos/` con ID slug (ej. `c-automatizacion-contable-v1`)
2. Crear bloques en `bloques/` con ese `curso_id`
3. Crear assets en `/assets/curso-{slug}/` en Hosting
4. Si se requieren componentes nuevos, añadirlos a `src/components/bloques/` y registrarlos en el resolver de tipos
5. Probar el flujo de alumno end-to-end con una cuenta test
6. Documentar el curso en `VERIFICACION_CURSO_{slug}_v1.md` en el vault Obsidian

---

*Schema canónico extraído del VERIFICACION_CURSO_IAPRENDE_N1_v2.md · abril 2026.*
