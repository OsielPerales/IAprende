---
título: Evaluaciones y Rúbricas · Patrones Canónicos
tipo: referencia_operativa
fuente: EC0301 E1024 + caso modelo IA + ejemplo BSmarter
tags: [evaluacion, rubrica, diagnostica, formativa, sumativa, satisfaccion]
---

# Evaluaciones y Rúbricas · Patrones Canónicos

Esta referencia documenta los 4 instrumentos de evaluación y cómo deben construirse. Los criterios EC0301 E1024 están en [[ec0301-criterios-evaluacion]].

---

## Regla general · distribución canónica

| Instrumento | Valor | Momento | Duración |
|---|---|---|---|
| Diagnóstica | Referencial (0 %) | Apertura | 5 min |
| Formativa | 50 % | Fin Módulo II | 20 min (incluye construcción + observación) |
| Sumativa | 50 % | Cierre del Desarrollo | 10 min |
| Satisfacción | — | Cierre | 2–5 min |

**Aprobatoria:** 80 % mínimo (≥14 puntos sobre la escala de 17.5 puntos posibles tras conversión).

---

## Plantilla de Evaluación Diagnóstica

### Estructura

```
ENCABEZADO
- Nombre del curso
- Instructor
- Lugar de impartición
- Duración · Horario · Fecha
- Nombre del participante
- Fecha de aplicación

INSTRUCCIONES
"Responde las siguientes preguntas con honestidad. No hay respuestas
correctas o incorrectas. Su propósito es conocer tu punto de partida.
Condiciones: aplicación individual. Materiales: lápiz o pluma.
Tiempo de ejecución: 5:00 min."

NOTA DESTACADA
"Esta evaluación es solo referencial. No cuenta para tu calificación
final. El instructor la utiliza para ajustar el nivel de profundidad
del curso a las necesidades del grupo."

REACTIVOS — 5 preguntas abiertas (no opción múltiple)

GUÍA DE RESPUESTAS (solo en Manual Instructor)
"Solo referencial. No se contabilizan las respuestas de forma correcta
o incorrecta.
Valor: Referencial, sin peso para la aprobación del curso.
Indicaciones al instructor: proporcionar los materiales y hoja de
evaluación, leer las instrucciones con los participantes, aclarar
dudas, tomar tiempo e indicar el término."
```

### Patrón de las 5 preguntas diagnósticas

1. **Qué es X para ti en este momento** (concepto central del curso)
2. **Has usado X? ¿Con qué frecuencia?** (experiencia previa)
3. **Qué diferencia encuentras entre Y y Z?** (comparación de alternativas)
4. **Qué es <término clave> para ti?** (vocabulario inicial)
5. **Nombra al menos un caso real donde aplicarías X** (aplicabilidad)

La skill las adapta al tema del curso automáticamente.

---

## Plantilla de Evaluación Formativa · Guía de Observación

La formativa usa **guía de observación** (lista de cotejo) aplicada por el instructor mientras el participante ejecuta una práctica.

### Estructura canónica · 6 criterios

Cada criterio vale 10 puntos (Sí/No). Máximo 60 puntos = 50 % del curso.

| # | Criterio de observación | Sí | No | Puntos | Observaciones |
|---|---|:-:|:-:|---|---|
| 1 | [Criterio 1: componente mínimo del producto] | ☐ | ☐ |  |  |
| 2 | [Criterio 2: componente estructural 2] | ☐ | ☐ |  |  |
| 3 | [Criterio 3: componente de forma/lenguaje] | ☐ | ☐ |  |  |
| 4 | [Criterio 4: restricciones correctas] | ☐ | ☐ |  |  |
| 5 | [Criterio 5: formato de salida] | ☐ | ☐ |  |  |
| 6 | [Criterio 6: integración coherente del producto final] | ☐ | ☐ |  |  |

**Regla:** los 5 primeros son partes + el 6° es integración del producto.

### Parte A · Participante (lo que el participante llena)

- Espacio para construcción del producto
- Autoevaluación con ☐ "marca los componentes incluidos antes de entregar"

### Parte B · Instructor (guía de observación que el instructor rellena mientras observa)

Descrita arriba. Con campo de **retroalimentación inmediata** antes de otorgar calificación.

### Nota operativa

El instructor retroalimenta antes de la calificación final y da 2 minutos adicionales al participante para corregir si falta algún componente. La calificación se cierra después del ajuste.

---

## Plantilla de Evaluación Sumativa · Proyecto + Teoría + Auto-auditoría Ética

### Estructura general

```
Parte I  — Proyecto práctico aplicado al contexto real del participante (20 pts)
Parte II — Teoría · 3 preguntas de opción múltiple (3 pts)
Parte III — Auto-auditoría ética · 3 ítems Sí/No (obligatoria)
TOTAL: 23 pts · convertidos a escala del 50 %
```

### Parte I · Proyecto

- Título del proceso a automatizar/resolver
- Desglose del producto por componente (siguiendo la estructura enseñada en M-II)
- Aplicabilidad inmediata al contexto del participante (no teórico)

### Parte II · Teoría

Exactamente **3 preguntas de opción múltiple** con 3 opciones cada una. Una respuesta correcta por pregunta.

Patrón de preguntas:

1. **Pregunta sobre mecanismo interno** (por qué funciona)
2. **Pregunta sobre error/fallo** (cómo se llama cuando sale mal)
3. **Pregunta sobre responsabilidad** (quién responde por la salida)

### Parte III · Auto-auditoría ética

3 preguntas Sí/No:

1. ¿Este producto/prompt pide o genera información falsa/engañosa?
2. ¿Incluí datos confidenciales reales?
3. ¿El uso que daré respeta los derechos de terceros?

Con instrucción: "Si alguna respuesta te alerta, corrige antes de entregar."

### Rúbrica · 5 criterios × 4 niveles

| Criterio | Excelente (4) | Satisfactorio (3) | En Desarrollo (2) | Requiere Apoyo (1) |
|---|---|---|---|---|
| Criterio 1 (componente estructural) | Específico y matizado | Claro pero genérico | Confuso | Ausente |
| Criterio 2 (calidad del contexto/datos) | Rico en detalles, sin datos sensibles | Contexto básico suficiente | Muy vago | Ausente o con datos privados |
| Criterio 3 (acción/verbo principal) | Imperativa y clara, medible | Comprensible | Pasiva o ambigua | No hay instrucción clara |
| Criterio 4 (restricciones/control) | Define longitud, tono, exclusiones | Al menos una restricción básica | Irrelevantes o contradictorias | Ausente |
| Criterio 5 (aplicabilidad real) | Lista para usar mañana en su negocio | Requiere edición menor | Ejercicio teórico difícil de aplicar | No resuelve el problema |

### Escala de calificación final

- 18–20 pts: **Dominio Avanzado** (Certificado con Mención)
- 14–17 pts: **Competente** (Aprobado — 80 % mínimo)
- < 14 pts: **Requiere refuerzo** en el Módulo donde el diagnóstico lo indique

### Clave de respuestas

Obligatoria en Manual Instructor. Para la Parte II, indicar letra correcta de cada pregunta. Para la Parte I, la rúbrica es la clave. Para la Parte III, no hay clave — el objetivo es reflexión del participante.

---

## Plantilla de Evaluación de Satisfacción

### Estructura canónica (según criterio EC0301 E1024 Producto 5)

```
ENCABEZADO
- Nombre del curso
- Nombre del instructor
- Lugar · Fecha
- (No pide nombre del participante: es anónima)

INSTRUCCIONES GENERALES
"Responda con honestidad. Sus respuestas son anónimas y se utilizarán
para mejorar futuras ediciones del curso. Tiempo: 3–5 minutos."

ESCALA DE ESTIMACIÓN
Likert 1–5:
  5 = Excelente
  4 = Bueno
  3 = Regular
  2 = Deficiente
  1 = Muy deficiente

SECCIONES DE REACTIVOS (4 obligatorias por EC0301)
A) Características del evento
   - Puntualidad y duración
   - Espacio / aula / mobiliario
   - Materiales entregados a tiempo
B) Contenido del curso
   - Pertinencia con mis necesidades
   - Profundidad adecuada
   - Ejemplos aplicables a mi contexto
C) Materiales didácticos
   - Manual del Participante claro y útil
   - Ejercicios y hojas de trabajo
   - Calidad visual de las diapositivas
D) Desempeño del instructor
   - Claridad al explicar
   - Manejo del tiempo
   - Apertura a preguntas y dudas
   - Ejemplos relevantes al grupo

COMENTARIOS LIBRES (obligatorio por EC0301)
- "¿Qué fue lo más valioso del curso?"
- "¿Qué recomendarías mejorar?"
- "¿Qué tema te gustaría profundizar en otro curso?"

CIERRE
"Gracias por su retroalimentación. Sus respuestas nos permiten mejorar."
```

### Nota EC0301

El instrumento cubre las 4 secciones obligatorias:
- [x] Características del evento
- [x] Contenido
- [x] Materiales didácticos
- [x] Desempeño del instructor
- [x] Espacio para comentarios

---

## Alineación con objetivos

Cada reactivo (en Diag/Form/Sum) debe corresponder con al menos un objetivo particular de la Planeación. La skill valida esto en T7.

Ejemplo de mapeo:

| Reactivo | Objetivo que evalúa |
|---|---|
| Diag #1 "¿Qué es X?" | Diagnóstico inicial → input para ajustar profundidad |
| Form criterio 1 | Obj. Particular M-II parte 1 |
| Form criterio 6 | Integración de todos los obj. particulares |
| Sum Parte I | Obj. General del curso |
| Sum Parte II preg 1 | Obj. Particular M-I |
| Sum Parte II preg 2 | Obj. Particular M-III |
| Sum Parte II preg 3 | Obj. Transversal (responsabilidad ética) |

---

*Fuente: EC0301 E1024 criterios + Planeación v4 caso modelo + validación B Smarter abril 2026.*
