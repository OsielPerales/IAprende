---
título: Tiempos Canónicos · Curso de 120 min
tipo: referencia_operativa
tags: [tiempos, canonicos, 2horas]
---

# Tiempos Canónicos · Curso de 120 minutos

La duración del curso es **fija en 120 minutos** en esta versión de la skill. La distribución respeta el reparto validado en la Planeación v4 del caso modelo IA Estratégica y en el ejemplo BSmarter de Estilos de Aprendizaje.

---

## Gran reparto

```
Total:           120 min
├── Apertura:     35 min    (29 %)
├── Desarrollo:   65 min    (54 %)
└── Cierre:       25 min    (21 %)
```

**Suma: 125 min** — el margen de 5 min es colchón para transiciones reales.

**Pre-evento:** 20–30 min antes del inicio para comprobación de recursos por parte del instructor (no cuenta en los 120).

---

## Apertura / Encuadre · 35 min detallados

| # | Etapa | Duración | Técnica |
|---|---|---|---|
| 1 | Presentación del instructor | 3 min | Exposición dialogada |
| 2 | Presentación de participantes · Rompe Hielo "Mapa de Expectativas" | 5 min | Rompe Hielo |
| 3 | Presentación del curso · Objetivo general | 3 min | Exposición |
| 4 | Objetivos particulares | 2–3 min | Exposición |
| 5 | Descripción general del desarrollo | 3 min | Exposición |
| 6 | Temario del curso | 2 min | Exposición |
| 7 | Beneficios del curso | 3 min | Discusión grupal |
| 8 | Tipos de evaluación, instrumentos y momentos | 2 min | Exposición |
| 9 | Acuerdos y compromisos · expectativas | 3 min | Lluvia de ideas |
| 10 | Reglas de operación | 2 min | Discusión grupal |
| 11 | Contrato de aprendizaje | 2 min | Técnica grupal |
| 12 | Evaluación Diagnóstica | 5 min | Cuestionario |
| **Total Apertura** | | **35 min** | |

---

## Desarrollo · 65 min detallados

| # | Etapa | Duración | Técnica |
|---|---|---|---|
| 1 | Módulo I (tema fundacional) | 15 min | Expositiva dialogada |
| 2 | Módulo II (estructura/aplicación) | 22 min | Demostrativa en vivo + práctica en parejas |
| 3 | Técnica Energizante | 3 min | Energizante |
| 4 | Módulo III (reflexión/ética) | 15 min | Diálogo-Discusión |
| 5 | Evaluación Sumativa / Final | 10 min | Cuestionario + Proyecto |
| **Total Desarrollo** | | **65 min** | |

### Notas sobre M-II

Los 22 min se reparten así internamente:

- Exposición breve (4 min) + Demostración paso a paso (8 min) + Práctica individual en parejas (8 min) + Evaluación Formativa in situ (2 min en paralelo al final de la práctica).

### Notas sobre M-III

Los 15 min incluyen: apertura del tema (2 min) + trabajo en subgrupos de 3–4 personas (8 min) + presentación de conclusiones + síntesis grupal (5 min).

---

## Cierre · 25 min detallados

| # | Etapa | Duración | Técnica |
|---|---|---|---|
| 1 | Conclusiones · Técnica grupal "Mi Asistente del Futuro" o equivalente | 4 min | Técnica grupal de cierre |
| 2 | Resumen ejecutivo de módulos | 4 min | Exposición participativa |
| 3 | Logro de expectativas | 2 min | Discusión grupal |
| 4 | Logro de objetivos (autoevaluación 1–5 por objetivo) | 3 min | Autoevaluación |
| 5 | Sugerencias de continuidad de aprendizaje | 3 min | Exposición |
| 6 | Referencias bibliográficas | 2 min | Exposición |
| 7 | Compromisos de aplicación del aprendizaje | 2 min | Técnica individual |
| 8 | Evaluación de satisfacción | 2–5 min | Encuesta |
| 9 | Cierre motivacional · entrega de constancias · foto | 3 min | Cierre |
| **Total Cierre** | | **25 min** (o 28 si satisfacción extiende) | |

---

## Reglas duras para respetar el presupuesto

1. **Ningún módulo del Desarrollo supera 25 min.** M-II es el más largo a 22 min por su componente práctico.
2. **La Sumativa va dentro del Desarrollo**, no del Cierre. Esto libera el Cierre para consolidación.
3. **El Energizante es obligatorio** como transición M-II → M-III. Si se omite, el grupo llega cansado a la discusión.
4. **La Evaluación Diagnóstica no suma calificación.** Solo 5 preguntas abiertas, 5 min.
5. **La Satisfacción cierra el curso.** Nunca se aplica antes porque contaminaría el resultado.
6. **Constancias se entregan después de Satisfacción**, nunca antes.

---

## Adaptaciones futuras (fuera de alcance v1)

Cuando la skill se amplíe a otras duraciones, los ratios base a preservar serán:

- Apertura: 25–30 % del total
- Desarrollo: 50–60 % del total
- Cierre: 15–20 % del total

Para 8 h (480 min): Apertura ~120, Desarrollo ~280, Cierre ~80 — con múltiples secuencias M-II–Energizante–Reflexión intercaladas.

---

*Alineado con Planeación v4 del caso modelo IA Estratégica (27 feb 2026) y validado en piloto 16 abr 2026.*
