---
título: Matriz de Entregables · EC0301 + EC0217.01
tipo: referencia_normativa
tags: [conocer, ec0301, ec0217, entregables, matriz]
---

# Matriz de Entregables · EC0301 + EC0217.01

Esta matriz es el **alcance cerrado** de la skill. Todo curso producido genera estos 12 artefactos.

---

## Origen normativo

**EC0301 · Diseño de cursos de formación del capital humano** (correo B Smarter INICIO 0301):

1. Documento de planeación del curso / carta descriptiva
2. Evaluación diagnóstica
3. Evaluación formativa
4. Evaluación final
5. Manual del participante
6. Manual del instructor

**EC0217.01 · Impartición de cursos de formación del capital humano** (correo B Smarter INICIO 0217.01):

1. Documento de planeación del curso
2. Lista de verificación de requerimientos
3. Evaluación diagnóstica
4. Evaluación formativa
5. Evaluación final
6. Evaluación de satisfacción
7. Informe final

**Unión = 9 documentos únicos** (los compartidos se producen una sola vez y sirven para ambos estándares).

**Adicionales no-normativos pero obligatorios del sistema iAprende/DE:**

- Hoja de adaptación a la plataforma iAprende (bloques Firestore)
- Storyboard de slides en Markdown
- Presentación final .pptx

**Total: 12 artefactos.**

---

## Matriz cruzada

| # | Artefacto | EC0301 | EC0217.01 | iAprende/DE | Template |
|:-:|---|:-:|:-:|:-:|---|
| 1 | Planeación / Carta descriptiva | ✓ | ✓ | — | `01-planeacion-carta-descriptiva.md` |
| 2 | Lista de verificación de requerimientos | — | ✓ | — | `02-lista-verificacion-requerimientos.md` |
| 3 | Evaluación diagnóstica | ✓ | ✓ | — | `03-eval-diagnostica.md` |
| 4 | Evaluación formativa | ✓ | ✓ | — | `04-eval-formativa-guia-observacion.md` |
| 5 | Evaluación sumativa / final | ✓ | ✓ | — | `05-eval-sumativa-proyecto-rubrica.md` |
| 6 | Evaluación de satisfacción | embebida en Manual Inst. | ✓ doc suelto | — | `06-eval-satisfaccion.md` |
| 7 | Manual del Participante | ✓ | — | — | `07-manual-participante.md` |
| 8 | Manual del Instructor | ✓ | — | — | `08-manual-instructor.md` |
| 9 | Informe Final | — | ✓ | — | `09-informe-final-ec0217.md` |
| 10 | Hoja de Adaptación iAprende | — | — | ✓ | `10-hoja-adaptacion-iaprende.md` |
| 11 | Storyboard de slides (Markdown) | — | — | ✓ | `11-storyboard-slides.md` |
| 12 | Slides finales (.pptx) | — | — | ✓ | `12-slides-pptx-brief.md` |

---

## Sobre la encuesta de satisfacción

EC0301 exige que el Manual del Instructor **incluya** un instrumento de satisfacción, pero no lo pide como documento suelto. EC0217.01 exige la encuesta como **documento entregable independiente**. 

**Resolución en esta skill:** El contenido se escribe UNA vez en `06-eval-satisfaccion.md`. El Manual del Instructor lo embebe como sección. Para EC0217.01 se exporta también como documento suelto con el mismo contenido pero portada propia.

---

## Criterios de evaluación del EC0301 cubiertos por cada artefacto

Ver detalles en [[ec0301-criterios-evaluacion]].

### Elemento 1 (E1023) — Diseñar cursos
- Cubierto principalmente por artefacto **1 (Planeación)**
- Validado contra criterios 1–9 de E1023

### Elemento 2 (E1024) — Diseñar instrumentos de evaluación
- Cubierto por artefactos **3, 4, 5, 6**
- Validado contra criterios 1–5 de E1024

### Elemento 3 (E1025) — Diseñar manuales
- Cubierto por artefactos **7 y 8**
- Validado contra criterios 1–10 de E1025

---

## Formatos de salida

| Artefacto | Formato primario | Formato secundario |
|---|---|---|
| 1–9 | `.docx` (B Smarter revisa en Word) | `.md` (vault Obsidian) |
| 10 | `.md` con frontmatter YAML + tablas Firestore | — |
| 11 | `.md` (revisable) | — |
| 12 | `.pptx` | `.pdf` para entrega |

Las versiones `.docx` se producen con la skill `pptx`/`docx` de Claude llamada desde los agentes correspondientes.

---

## Orden de producción

La skill respeta este orden por dependencias:

1. **Planeación** primero — de ella derivan objetivos, temas, técnicas y tiempos.
2. **Evaluaciones** segundo — deben alinearse con los objetivos de la planeación.
3. **Manuales** tercero — citan objetivos + integran evaluaciones.
4. **Hoja iAprende** cuarto — traduce planeación + manuales a bloques Firestore.
5. **Slides** quinto — condensan el manual del participante visualmente.
6. **Lista verificación + Informe final** al final — dependen del resto.

---

*Actualizar esta matriz si CONOCER publica una revisión del estándar o si B Smarter cambia los entregables.*
