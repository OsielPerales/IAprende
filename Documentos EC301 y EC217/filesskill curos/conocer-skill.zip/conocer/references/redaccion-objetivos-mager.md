---
título: Redacción de Objetivos · Patrón Mager
tipo: referencia_operativa
fuente: Glosario EC0301 + Mager 1962
tags: [objetivos, mager, bloom, redaccion]
---

# Redacción de Objetivos · Patrón Mager

EC0301 exige que los objetivos (general y particulares) sean redactados con 4 componentes Mager. Esta referencia da los patrones y verbos para hacerlo correctamente.

---

## Los 4 componentes Mager

Todo objetivo (general o particular) debe contener:

| Componente | Pregunta | Ejemplo |
|---|---|---|
| **Sujeto** | ¿Quién? | El participante |
| **Conducta / producto / actitud** | ¿Qué hará? | Diseñará y aplicará prompts estratégicos |
| **Condición de operación** | ¿Cómo? + ¿Para qué? | Mediante ejercicios prácticos · para optimizar procesos |
| **Límite / criterio aceptable** | ¿Con qué nivel? | Con los 5 componentes de la Estructura Maestra correctamente incluidos |

El límite se traduce luego a criterios medibles en la rúbrica sumativa.

---

## Plantilla canónica del Objetivo General

```
El participante, 
<sujeto>

<condición temporal — cuándo>, 
Ej: "desde el inicio y durante el taller, de manera asistida por el instructor, así como en su interacción diaria con <objeto>"

<acción principal>
Ej: "diseñará y aplicará <producto/conducta>"

<utilizando / mediante qué>
Ej: "utilizando <metodología> para <propósito>"

<condición de cómo>
Ej: "Mediante <técnicas/recursos>, retroalimentación y evaluaciones formativas"

<propósito final — para qué>
Ej: "para optimizar <métrica> reduciendo <dolor> y fomentando <valor ético>"
```

**Ejemplo literal del caso modelo:**

> "El participante, desde el inicio y durante el taller de manera asistida por el instructor así como en su interacción diaria con la IA, diseñará y aplicará prompts estratégicos utilizando la Estructura Maestra (Rol, Contexto, Instrucción, Restricciones, Formato) para automatizar procesos personales y empresariales, mediante ejercicios prácticos, retroalimentación por pares y evaluaciones formativas, optimizando su productividad, reduciendo tiempos en tareas mecánicas y fomentando un uso responsable y ético de la Inteligencia Artificial en su entorno profesional."

---

## Plantilla canónica de Objetivo Particular

```
Módulo N — El participante
<verbo Bloom en futuro imperfecto>
<conducta/producto/actitud específica al módulo>,
<condición — cómo / con qué técnica>,
<propósito — para qué en su contexto>.
```

**Ejemplo literal del caso modelo, M-I:**

> "Módulo I — Comprenderá el cambio de paradigma de buscadores a motores de razonamiento e identificará procesos repetitivos en su negocio o entorno susceptibles de automatización mediante IA, a través de un taller práctico con herramientas accesibles y guía ética."

---

## Objetivo transversal "Saber Convivir" (obligatorio)

Todo curso CONOCER debe incluir un objetivo transversal afectivo. Plantilla:

> "A lo largo del curso desarrollará actitudes de colaboración activa, intercambio de [objeto del curso] y retroalimentación entre pares, fortaleciendo habilidades sociales y profesionales, creando redes de contacto y promoviendo el aprendizaje mutuo."

---

## Verbos por dominio de aprendizaje

### Dominio Cognitivo (Saber) — Taxonomía de Bloom

| Nivel | Verbos recomendados |
|---|---|
| Recordar | Identificar · Listar · Definir · Reconocer · Nombrar |
| Comprender | Explicar · Describir · Resumir · Interpretar · Comparar |
| Aplicar | Aplicar · Utilizar · Ejecutar · Implementar · Resolver |
| Analizar | Analizar · Distinguir · Diferenciar · Contrastar · Examinar |
| Evaluar | Evaluar · Juzgar · Criticar · Justificar · Fundamentar |
| Crear | Diseñar · Construir · Generar · Formular · Planear · Producir |

**Regla:** Módulo I suele aterrizar en Comprender/Aplicar. Módulo II en Aplicar/Crear. Módulo III en Analizar/Evaluar.

### Dominio Psicomotor (Saber Hacer)

Verbos: construir, operar, manipular, ejecutar, ensamblar, demostrar.

### Dominio Afectivo (Saber Ser / Saber Convivir)

Verbos: desarrollará (actitudes), compartirá, colaborará, respetará, valorará, se comprometerá, internalizará.

---

## Verbos débiles PROHIBIDOS

Estos verbos NO cumplen criterio Mager porque no describen una conducta observable:

- conocer · saber · entender · aprender (reemplazar por comprender + acción específica)
- familiarizarse · acercarse · explorar (reemplazar por identificar, describir)
- apreciar · disfrutar (reemplazar por valorará + evidencia concreta)

---

## Criterios de validación (de EC0301)

Un objetivo bien redactado cumple:

- [ ] Determina el sujeto de aprendizaje
- [ ] Indica conducta, producto o actitud a alcanzar
- [ ] Especifica condiciones de operación
- [ ] Especifica límites de tiempo, calidad, exactitud o criterio aceptable
- [ ] Es congruente con los temas del curso (solo particulares)
- [ ] Es congruente con las características de los participantes (solo particulares)
- [ ] Usa verbos observables (no débiles)

---

## Alineación objetivos → evaluación → actividades

Regla de oro EC0301: cada objetivo particular debe tener

1. **Una actividad de aprendizaje** en el Desarrollo que lo trabaje (técnica instruccional asociada).
2. **Un criterio de evaluación** en al menos una de las evaluaciones (formativa o sumativa) que mida su logro.

Si un objetivo no tiene actividad ni evaluación, se elimina. Si una actividad no conecta con ningún objetivo, se reconsidera. Esta alineación se verifica en T7 (checklist final).

---

## Ejemplo de set completo para un curso hipotético

Curso hipotético: "Automatización básica de reportes con IA para contadores" (3 temas: IA en contabilidad · Prompt para reportes financieros · Verificación de alucinaciones contables).

### Objetivo General
> "El participante, al concluir el taller, diseñará un asistente de IA aplicado a la generación y revisión de reportes financieros básicos utilizando la Estructura Maestra del Prompt, mediante ejercicios prácticos con casos de su propia operación contable, para reducir el tiempo de elaboración de reportes recurrentes y minimizar errores por fatiga, manteniendo un criterio ético de verificación humana de los datos generados."

### Objetivos Particulares
- M-I — Identificará los puntos de dolor en su proceso actual de generación de reportes y reconocerá las diferencias entre un buscador y un motor de razonamiento, mediante la Bitácora de Procesos, para diagnosticar oportunidades concretas de automatización.
- M-II — Aplicará la Estructura Maestra del Prompt a un caso real de reporte financiero mensual, mediante demostración guiada + práctica individual, generando un prompt reutilizable con los 5 componentes.
- M-III — Analizará y corregirá alucinaciones numéricas en salidas de IA, mediante diálogo-discusión sobre 3 casos reales, desarrollando criterio ético de verificación antes de publicar cualquier cifra.
- Transversal (Saber Convivir) — Compartirá prompts y hallazgos con compañeros del grupo, fortaleciendo una red profesional de contadores usuarios de IA.

---

*Fuente: EC0301 glosario puntos 16, 17, 18 + Mager, R.F. (1962) "Preparing Instructional Objectives".*
