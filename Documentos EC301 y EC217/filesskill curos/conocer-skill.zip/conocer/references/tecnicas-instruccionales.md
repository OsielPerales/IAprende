---
título: Técnicas Instruccionales y Grupales · CONOCER
tipo: referencia_normativa
fuente: EC0301 · Glosario y Conocimientos requeridos
tags: [tecnicas, instruccional, grupal, conocer]
---

# Técnicas Instruccionales y Grupales · CONOCER

EC0301 exige conocimiento (nivel "Conocimiento") de **3 técnicas instruccionales** y **3 técnicas grupales**. Todo curso bien diseñado las emplea de forma alineada al tipo de contenido.

---

## Técnicas Instruccionales (3)

### 1. Técnica Expositiva (dialogada)

**Propósito:** transmitir contenido conceptual/teórico con recuperación de experiencia previa.

**Secuencia de aplicación:**

```
a) Presentar el objetivo del tema.
b) Introducir el tema con analogías o contexto.
c) Recuperar experiencia previa con 2–3 preguntas abiertas.
d) Desarrollar el contenido principal con apoyo de diapositivas.
e) Usar ejemplos del sector/perfil del grupo.
f) Realizar síntesis de puntos clave.
g) Plantear 2 preguntas de verificación.
h) Promover comentarios y aplicación a contextos reales.
i) Mencionar referencias bibliográficas.
```

**Cuándo usarla:** Módulo I (fundamentos), apertura de cualquier módulo para contexto.

**Señales de que se está aplicando mal:** monólogo sin preguntas, sin recuperación de experiencia, sin ejemplos del sector del grupo.

---

### 2. Técnica Demostrativa (ejecución)

**Propósito:** enseñar procedimientos paso a paso con modelado en vivo + práctica guiada.

**Secuencia de aplicación:**

```
a) Presentar el objetivo de la demostración.
b) Recuperar experiencia previa del grupo.
c) Ejemplificar la construcción paso a paso, proyectando en vivo.
   — Partir de un caso real del sector.
   — Construir componente por componente, verbalizando cada decisión.
   — Invitar al grupo a identificar cada paso.
d) Resolver dudas sobre la demostración.
e) Los participantes realizan la práctica (individual o en parejas).
f) Circular para resolver dudas durante la práctica.
g) Retroalimentar usando lista de cotejo o guía de observación.
h) Usar ejemplos del sector/perfil del grupo.
i) Aplicar evaluación formativa al final de la práctica.
```

**Cuándo usarla:** Módulo II (aplicación/construcción), siempre que haya un producto a construir.

**Requiere:** acceso a la herramienta en vivo (computadora + proyector + conectividad).

---

### 3. Técnica Diálogo-Discusión

**Propósito:** reflexionar, analizar casos, construir conclusiones colectivas sobre temas actitudinales o controvertidos.

**Secuencia de aplicación:**

```
a) Mencionar el tema a discutir y mostrarlo en pantalla.
b) Dividir al grupo en subgrupos de 3–4 personas (por sector si aplica).
c) Establecer reglas de operación:
   — Escucha activa
   — Respetar turnos
   — Construir sobre ideas de otros
   — Argumentar las opiniones
d) Abrir la discusión con un caso provocador pero realista.
e) Propiciar que los participantes compartan casos propios.
f) Moderar sin tomar partido.
g) Usar ejemplos de sectores distintos al del grupo para ampliar perspectiva.
h) Cada subgrupo presenta conclusiones.
i) Llegar a una conclusión grupal consensuada.
```

**Cuándo usarla:** Módulo III (reflexión/ética), cualquier tema con múltiples posturas válidas.

**Requiere:** un caso de análisis preparado de antemano.

---

## Técnicas Grupales (3)

### 1. Rompe Hielo

**Propósito:** eliminar la tensión inicial, conocer al grupo, establecer expectativas iniciales.

**Duración:** 5–10 min al inicio del Encuadre.

**Ejemplos canónicos de la skill:**

- **"Mapa de Expectativas":** cada participante comparte nombre, rol y un reto que espera que el curso le resuelva + un reto que cree que el curso NO puede resolver. El instructor anota en pizarra creando un mapa visual.
- **"El juego de las posibilidades":** un participante describe un objeto sin mencionarlo ni hablar (gestos), el resto adivina. Ejemplo del ejemplo BSmarter.

**Elegir uno según perfil del grupo:** Mapa de Expectativas para grupos profesionales, Juego de Posibilidades para grupos más cohesionados o con actitud lúdica.

---

### 2. Energizante (Energetizante)

**Propósito:** reactivar energía del grupo a mitad del curso + consolidar un aprendizaje recién visto + transicionar al siguiente tema.

**Duración:** 3–5 min después del Módulo II.

**Ejemplos canónicos:**

- **"El Prompt Rápido"** (caso IA): participantes de pie, el instructor lanza 3 temas al azar, cada persona tiene 15 s para decir el ROL que asignaría a la IA.
- **"Estiramientos"** (caso BSmarter): participantes de pie siguen movimientos guiados del instructor para relajar/activar.

Adaptar al contenido del curso: el energizante debe tocar el tema recién aprendido, no ser meramente físico si es posible.

---

### 3. Cierre (técnica grupal)

**Propósito:** consolidar aprendizajes, comprometerlos a una acción inmediata, cerrar emocionalmente.

**Duración:** 4–5 min al inicio del Cierre.

**Ejemplos canónicos:**

- **"Mi Asistente del Futuro"** (caso IA): círculo al centro, cada persona completa la frase "Esta semana voy a automatizar [proceso] usando IA en mi [negocio]."
- **"Balance del día · Lo que me llevo del grupo"** (caso BSmarter): cada persona verbaliza el aprendizaje más relevante del día.

La frase de compromiso siempre apunta a **acción en ≤7 días** con un objeto concreto.

---

## Reglas de elección para la skill

Al construir la Planeación, la skill asigna técnicas así:

| Contenido del módulo | Técnica instruccional principal |
|---|---|
| Conceptual / teórico (qué, por qué) | Expositiva dialogada |
| Procedimental / aplicado (cómo hacer) | Demostrativa |
| Actitudinal / ético / reflexivo | Diálogo-Discusión |

Las 3 técnicas grupales son **obligatorias** y aparecen en este orden:

1. Rompe Hielo → al inicio (Apertura)
2. Energizante → entre Desarrollo y reflexión (transición M-II → M-III)
3. Cierre grupal → al inicio del Cierre

---

## Checklist de técnicas por planeación

Antes de declarar cerrada una planeación, verificar:

- [ ] Al menos 1 técnica instruccional por módulo
- [ ] Las 3 técnicas instruccionales distintas aparecen en el curso (Expositiva + Demostrativa + Diálogo-Discusión)
- [ ] Las 3 técnicas grupales están (Rompe Hielo + Energizante + Cierre)
- [ ] Cada técnica incluye su secuencia de pasos en la carta descriptiva
- [ ] Las técnicas grupales tienen nombre propio (no solo "dinámica")
- [ ] Duración de cada técnica está declarada

---

## Glosario

- **Técnicas de instrucción:** Conjunto de acciones organizadas y sistematizadas que propician el logro de objetivos de aprendizaje. (EC0301 glosario #19)
- **Técnicas grupales:** Conjunto de acciones organizadas y sistematizadas que educan para la convivencia y propician un ambiente favorable dentro del grupo. (EC0301 glosario #20)

---

*Fuente canónica: EC0301 CONOCER · Conocimientos requeridos puntos 3 y 4 · Glosario puntos 19 y 20.*
