---
título: Glosario CONOCER · EC0301 + EC0217.01
tipo: referencia_normativa
fuente: EC0301 PDF oficial CONOCER
tags: [glosario, conocer, definiciones]
---

# Glosario CONOCER · Definiciones Operativas

Términos canónicos del estándar EC0301. Toda redacción en los artefactos debe alinearse con estas definiciones.

---

## Términos de diseño de cursos (EC0301 E1023)

**Carta Descriptiva** — Documento que contiene todos los elementos básicos para desarrollar un curso estructurado y organizado para un determinado tiempo, de manera que se cumplan los objetivos de enseñanza-aprendizaje. Anteriormente conocida como "guía instruccional". Está integrada en el Manual del Instructor.

**Condiciones de operación** — En la redacción de los objetivos de aprendizaje, se refiere a la manera en que se desarrollará una conducta, producto de aprendizaje, actitud y/o valor a alcanzar por el participante.

**Criterios de evaluación** — Definen los resultados, características o atributos que se espera cumpla el participante.

**Dominio de aprendizaje afectivo** — Se refiere a la interiorización de una actitud o valor.

**Dominio de aprendizaje cognitivo** — Conductas en las que predominan los procesos mentales o intelectuales que abarcan desde la memorización hasta la aplicación de criterios y elaboración de juicios de actividad intelectual compleja.

**Dominio de aprendizaje psicomotriz** — Conductas que se realizan con precisión, exactitud, facilidad, economía del tiempo y esfuerzo.

**Dominios de aprendizaje** — Clasificación de diversas conductas del individuo que permiten identificar la organización y jerarquización de los procesos para la adquisición de conocimientos.

**Estrategia de evaluación** — Plan de acción que permite identificar los momentos, criterios, instrumentos y evidencias que se espera cumpla el participante de acuerdo a los objetivos del curso.

**Evaluación diagnóstica** — Actividad que permite obtener información respecto de las condiciones iniciales del aprendizaje, los conocimientos previos con relación a una determinada competencia, y favorece la toma de decisiones para mejorar el proceso de instrucción-aprendizaje. Se realiza al inicio del curso.

**Evaluación formativa** — Actividad que permite proporcionar una ayuda ajustada a los procesos de construcción que realizan los participantes. Se realiza de forma concurrente con el proceso de instrucción-aprendizaje.

**Evaluación sumativa** — Actividad que consiste en valorar si el proceso de instrucción-aprendizaje fue eficaz para que los participantes logren los objetivos planeados previamente.

**Instrumento de evaluación** — Herramienta empleada para obtener datos cuantitativos y/o cualitativos que permitan conocer el grado de acercamiento entre el objetivo del curso y el resultado. Están integrados en el Manual del Instructor.

**Materiales didácticos** — Cualquier material elaborado con la intención de facilitar los procesos de instrucción-aprendizaje.

**Momentos de capacitación** — Etapas (Encuadre, Inicio, Desarrollo y Cierre) que estructuran el curso.

**Necesidades de capacitación** — Se traducen en conocimientos, habilidades o actitudes que deben ser adoptados, desarrollados o modificados para mejorar la calidad del trabajo y la preparación integral del individuo.

**Objetivo específico de aprendizaje** — Descripción de la conducta, producto y/o actitud final esperada del participante al término de un **subtema**. Dependiendo del curso diseñado puede desarrollarse o no. Se compone de: sujeto de aprendizaje + conducta/producto/actitud + condiciones de operación + límites de tiempo, calidad, exactitud y/o criterio aceptable.

**Objetivo general de aprendizaje** — Descripción de la conducta, producto y/o actitud final esperada del participante al término de un **curso**. Mismos 4 componentes.

**Objetivo particular de aprendizaje** — Descripción de la conducta, producto y/o actitud final esperada del participante al término de un **tema** (módulo). Mismos 4 componentes.

**Técnicas de instrucción** — Conjunto de acciones organizadas y sistematizadas que propician el logro de objetivos de aprendizaje.

**Técnicas grupales** — Conjunto de acciones organizadas y sistematizadas que educan para la convivencia y propician un ambiente favorable dentro del grupo.

---

## Términos de manuales (EC0301 E1025)

**Clave de respuestas** — Documento con las respuestas correctas, del cual se apoyará el instructor para revisar los instrumentos de evaluación.

**Enfoque didáctico** — Modelo de instrucción que genera estrategias de formación y evaluación al servicio del logro de aprendizajes significativos en espacios de formación del capital humano.

**Manual del instructor** — Documento que le permitirá a la persona que se encuentra frente a grupo contar con los requerimientos necesarios para desarrollar su curso. Comprende recursos materiales y de equipo, así como el diseño de su curso contenido en una carta descriptiva y el desarrollo temático, además de los instrumentos de evaluación y de satisfacción del curso.

**Manual del participante** — Documento que contiene los temas de un curso con una introducción, desarrollo de temas, ejemplos, ejercicios y conclusiones.

**URL** — Localizador de recursos uniforme; cadena de caracteres con la cual se asigna una dirección única a cada uno de los recursos de información disponibles en Internet.

---

## Términos no oficiales pero operativos en la skill

**Caso ancla** — Caso de negocio único que atraviesa los 3 módulos del curso dando continuidad narrativa.

**Bibliografía viva** — Conjunto de referencias actualizadas (≤24 meses) detectadas en T4 vía web_search, complementarias a las referencias clásicas.

**Bloque (iAprende)** — Unidad mínima de contenido didáctico en el schema Firestore, con tipo, duración y orden específicos.

**Hoja de Adaptación iAprende** — Documento vivo que describe la traducción del curso a 35–40 bloques implementables en la plataforma.

**Skin in the Game** — Principio operativo de DE: no se enseña ni se vende nada que no haya sido validado antes en operación propia.

---

## Nivel en el Sistema Nacional de Competencias · Tres

EC0301 es Nivel Tres SNC. Esto significa que el diseñador:

- Desempeña actividades tanto programadas, rutinarias como impredecibles.
- Recibe orientaciones generales e instrucciones específicas de un superior.
- Requiere supervisar y orientar a otros trabajadores jerárquicamente subordinados.

Operativamente: un diseñador EC0301 puede responder por cursos nuevos que no habían sido diseñados antes, siempre bajo guías metodológicas (como esta skill) y supervisión de un coordinador académico (Iván Téllez en el caso DE).

---

*Fuente: Estándar EC0301 · DOF 28-nov-2012 · v6.0 CONOCER.*
